<?php

define("JIEQI_MODULE_NAME", "system");
require_once ("../global.php");
include_once (JIEQI_ROOT_PATH . "/admin/header.php");
$jieqiTset["jieqi_contents_template"] = JIEQI_ROOT_PATH . "/templates/admin/faq.html";
include_once (JIEQI_ROOT_PATH . "/admin/footer.php");

?>
