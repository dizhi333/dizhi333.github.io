<?php

define("JIEQI_MODULE_NAME", "system");
require_once ("../global.php");
jieqi_getconfigs(JIEQI_MODULE_NAME, "power");
jieqi_checkpower($jieqiPower["system"]["manageallparlor"], $jieqiUsersStatus, $jieqiUsersGroup, false, true);
jieqi_getconfigs(JIEQI_MODULE_NAME, "configs");
include_once (JIEQI_ROOT_PATH . "/class/ptopics.php");
$ptopics_handler = &JieqiPtopicsHandler::getInstance("JieqiPtopicsHandler");
$query = JieqiQueryHandler::getInstance("JieqiQueryHandler");
if (isset($_REQUEST["action"]) && !empty($_REQUEST["tid"])) {
	$actptopic = $ptopics_handler->get($_REQUEST["tid"]);

	if (is_object($actptopic)) {
		$criteria = new CriteriaCompo(new Criteria("topicid", $_REQUEST["tid"]));

		switch ($_REQUEST["action"]) {
		case "top":
			$ptopics_handler->updatefields(array("istop" => 1), $criteria);
			break;

		case "untop":
			$ptopics_handler->updatefields(array("istop" => 0), $criteria);
			break;

		case "good":
			$ptopics_handler->updatefields(array("isgood" => 1), $criteria);
			break;

		case "normal":
			$ptopics_handler->updatefields(array("isgood" => 0), $criteria);
		case "del":
			$ptopics_handler->delete($criteria);
			$query->execute("DELETE FROM " . jieqi_dbprefix("system_pposts") . " WHERE topicid=" . intval($_REQUEST["tid"]));
			break;
		}

		unset($criteria);
	}
}
else {
	if (isset($_REQUEST["batchdel"]) && ($_REQUEST["batchdel"] == 1) && is_array($_REQUEST["checkid"]) && (0 < count($_REQUEST["checkid"]))) {
		$where = "";

		foreach ($_REQUEST["checkid"] as $v ) {
			if (is_numeric($v)) {
				$v = intval($v);

				if (!empty($where)) {
					$where .= ", ";
				}

				$where .= $v;
			}
		}

		if (!empty($where)) {
			$sql = "DELETE FROM " . jieqi_dbprefix("system_ptopics") . " WHERE topicid IN (" . $where . ")";
			$query->execute($sql);
			$sql = "DELETE FROM " . jieqi_dbprefix("system_pposts") . " WHERE topicid IN (" . $where . ")";
			$query->execute($sql);
		}
	}
}

$jieqiTset["jieqi_contents_template"] = JIEQI_ROOT_PATH . "/templates/admin/ptopiclist.html";
include_once (JIEQI_ROOT_PATH . "/admin/header.php");
$jieqiPset = jieqi_get_pageset();
include_once (JIEQI_ROOT_PATH . "/lib/text/textfunction.php");
include_once (JIEQI_ROOT_PATH . "/class/users.php");
$criteria = new CriteriaCompo();
$criteria->setFields("t.*,u.uname,u.name");
$criteria->setTables(jieqi_dbprefix("system_ptopics") . " AS t LEFT JOIN " . jieqi_dbprefix("system_users") . " AS u ON t.ownerid=u.uid");

if (!empty($_REQUEST["keyword"])) {
	$_REQUEST["keyword"] = trim($_REQUEST["keyword"]);

	if ($_REQUEST["keytype"] == 1) {
		$criteria->add(new Criteria("t.poster", $_REQUEST["keyword"], "="));
	}
	else if ($_REQUEST["keytype"] == 2) {
		$criteria->add(new Criteria("t.title", "%" . $_REQUEST["keyword"] . "%", "like"));
	}
	else {
		$criteria->add(new Criteria("u.uname", $_REQUEST["keyword"], "="));
	}
}

if (isset($_REQUEST["type"]) && ($_REQUEST["type"] == "good")) {
	$criteria->add(new Criteria("isgood", 1));
}
else {
	$_REQUEST["type"] = "all";
}

$criteria->setSort("topicid");
$criteria->setOrder("DESC");
$criteria->setLimit($jieqiPset["rows"]);
$criteria->setStart($jieqiPset["start"]);
$query->queryObjects($criteria);
$ptopicrows = array();
$k = 0;

while ($v = $query->getObject()) {
	$ptopicrows[$k] = jieqi_query_rowvars($v);
	$start = 3;

	if ($v->getVar("istop") == 1) {
		$ptopicrows[$k]["istop"] = 1;
		$start += 4;
	}
	else {
		$ptopicrows[$k]["istop"] = 0;
	}

	if ($v->getVar("isgood") == 1) {
		$ptopicrows[$k]["isgood"] = 1;
		$start += 4;
	}
	else {
		$ptopicrows[$k]["isgood"] = 0;
	}

	$ptopicrows[$k]["url_top"] = jieqi_addurlvars(array("action" => "top", "rid" => $v->getVar("topicid")));
	$ptopicrows[$k]["url_untop"] = jieqi_addurlvars(array("action" => "untop", "rid" => $v->getVar("topicid")));
	$ptopicrows[$k]["url_good"] = jieqi_addurlvars(array("action" => "good", "rid" => $v->getVar("topicid")));
	$ptopicrows[$k]["url_normal"] = jieqi_addurlvars(array("action" => "normal", "rid" => $v->getVar("topicid")));
	$ptopicrows[$k]["url_delete"] = jieqi_addurlvars(array("action" => "del", "rid" => $v->getVar("topicid")));
	$ptopicrows[$k]["owner"] = (strlen($v->getVar("name")) == 0 ? $v->getVar("uname") : $v->getVar("name"));
	$k++;
}

$jieqiTpl->assign_by_ref("ptopicrows", $ptopicrows);
include_once (JIEQI_ROOT_PATH . "/lib/html/page.php");
$jieqiPset["count"] = $query->getCount($criteria);
$jumppage = new JieqiPage($jieqiPset);
$jumppage->setlink("", true, true);
$jieqiTpl->assign("url_jumppage", $jumppage->whole_bar());
$jieqiTpl->setCaching(0);
include_once (JIEQI_ROOT_PATH . "/admin/footer.php");

?>
