<?php

$apiOrder = 1;
$apiName = "qq";
$apiTitle = "QQ";
$apiConfigs[$apiName] = array();
$apiConfigs[$apiName]["appid"] = "";
$apiConfigs[$apiName]["appkey"] = "";
$apiConfigs[$apiName]["callback"] = JIEQI_LOCAL_URL . "/api/qq/loginback.php";
$apiConfigs[$apiName]["scope"] = "get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo";

?>
