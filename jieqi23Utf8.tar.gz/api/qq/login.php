<?php

define("JIEQI_MODULE_NAME", "system");
define("JIEQI_NEED_SESSION", 1);
require_once ("../../global.php");
include_once ("./config.inc.php");
include_once ("./lang_api.php");
set_include_path(JIEQI_ROOT_PATH . "/lib/");
include_once (JIEQI_ROOT_PATH . "/lib/OpenSDK/Tencent/SNS2.php");
$_SESSION["jieqiUserApi"][$apiName] = $apiConfigs[$apiName];
$_SESSION["jieqiUserApi"][$apiName]["state"] = md5(uniqid(rand(), true));
OpenSDK_Tencent_SNS2::init($apiConfigs[$apiName]["appid"], $apiConfigs[$apiName]["appkey"]);
$url = OpenSDK_Tencent_SNS2::getAuthorizeURL($apiConfigs[$apiName]["callback"], "code", $_SESSION["jieqiUserApi"][$apiName]["state"], $apiConfigs[$apiName]["scope"]);
header("Location: " . jieqi_headstr($url));

?>
