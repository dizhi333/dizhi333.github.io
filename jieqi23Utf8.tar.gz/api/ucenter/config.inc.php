<?php

define("UC_CONNECT", "");
define("UC_DBHOST", "localhost");
define("UC_DBUSER", "root");
define("UC_DBPW", "root");
define("UC_DBNAME", "ucenter");
define("UC_DBCHARSET", "gbk");
define("UC_DBTABLEPRE", "ucenter.pre_ucenter_");
define("UC_KEY", uniqid(rand()));
define("UC_API", "http://www.domain.com/uc_server");
define("UC_CHARSET", "gbk");
define("UC_IP", "");
define("UC_APPID", 3);

?>
