<?php

$_CACHE["apps"] = array(
				s => array("appid" => "1", "type" => "DISCUZX", "name" => "Discuz! Board", "url" => "http://www.dx2.com", "ip" => "127.0.0.1", "viewprourl" => "", "apifilename" => "uc.php", "charset" => "", "synlogin" => "1", "extra" => "", "recvnote" => "1"),
				s => array(
					s => "2",
					s => "OTHER",
					s => "JIEQI CMS",
					s => "http://www.jieqicms.com",
					s => "",
					s => "/userinfo.php?id=%s",
					s => "uc.php",
					s => "",
					s => "1",
					s => array("apppath" => ""),
					s => "1"
		),
				s => array(
					s => "3",
					s => "OTHER",
					s => "jieqinet",
					s => "http://www.jieqi.net",
					s => "",
					s => "/userinfo.php?id=%s",
					s => "uc.php",
					s => "",
					s => "1",
					s => array("apppath" => ""),
					s => "1"
		)
	);

?>
