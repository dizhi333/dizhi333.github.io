<?php

$apiOrder = 4;
$apiName = "weibo";
$apiTitle = "新浪微博";
$apiConfigs[$apiName] = array();
$apiConfigs[$apiName]["appid"] = "";
$apiConfigs[$apiName]["appkey"] = "";
$apiConfigs[$apiName]["callback"] = JIEQI_LOCAL_URL . "/api/" . $apiName . "/loginback.php";
$apiConfigs[$apiName]["scope"] = "";

?>
