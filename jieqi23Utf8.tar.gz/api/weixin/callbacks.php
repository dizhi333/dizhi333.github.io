<?php

function charsetToGBK($mixed)
{
	if (is_array($mixed)) {
		foreach ($mixed as $k => $v ) {
			if (is_array($v)) {
				$mixed[$k] = charsetToGBK($v);
			}
			else {
				$encode = mb_detect_encoding($v, array("ASCII", "UTF-8", "GB2312", "GBK", "BIG5"));

				if ($encode == "UTF-8") {
					$mixed[$k] = iconv("UTF-8", "GBK", $v);
				}
			}
		}
	}
	else {
		$encode = mb_detect_encoding($mixed, array("ASCII", "UTF-8", "GB2312", "GBK", "BIG5"));

		if ($encode == "UTF-8") {
			$mixed = iconv("UTF-8", "GBK", $mixed);
		}
	}

	return $mixed;
}

function accessToken()
{
	global $AppID;
	global $AppSecret;
	$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" . $AppID . "&secret=" . $AppSecret . "&code=" . $_GET["code"] . "&grant_type=authorization_code";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_URL, $url);
	$json = curl_exec($ch);
	curl_close($ch);
	$arr = json_decode($json, 1);
	return $arr;
}

define("JIEQI_MODULE_NAME", "system");
define("JIEQI_NEED_SESSION", 1);
require_once ("../../global.php");
include_once ("./config.inc.php");
@$code = $_GET["code"];
@$state = $_GET["state"];
if (empty($code) || empty($state)) {
	exit("授权失败");
}

$accessToken = accesstoken();
$url = "https://api.weixin.qq.com/sns/userinfo?access_token=" . $accessToken["access_token"] . "&openid=" . $accessToken["openid"] . "&lang=zh_CN";
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $url);
$json = curl_exec($ch);
curl_close($ch);
$user = json_decode($json, 1);
jieqi_includedb();
$query = JieqiQueryHandler::getInstance("JieqiQueryHandler");
$sql = "SELECT * FROM wechat WHERE openid = '" . $user["openid"] . "' LIMIT 0, 1";
$query->execute($sql);
$row = $query->getRow();

if (is_array($row)) {
	$sql = "UPDATE wechat SET token = '" . $state . "' WHERE openid = '" . $user["openid"] . "';";
}
else {
	$sql = "INSERT INTO wechat (`openid` ,`nickname`, `sex` ,`headimgurl` ,`token`) VALUES ('" . $user["openid"] . "', '" . charsettogbk($user["nickname"]) . "', '" . $user["sex"] . "', '" . $user["headimgurl"] . "', '" . $state . "');";
}

$ret = $query->execute($sql);
echo "<script>document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {\r\r\nWeixinJSBridge.call('closeWindow');}, false);</script>";

?>
