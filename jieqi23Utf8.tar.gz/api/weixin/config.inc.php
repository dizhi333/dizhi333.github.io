
Parse error: syntax error, unexpected T_VARIABLE in H:\网站\小说\杰奇\杰奇23lock\api\weixin\config.inc.php on line 19
