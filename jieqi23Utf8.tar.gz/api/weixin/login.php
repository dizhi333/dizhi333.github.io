<?php

session_start();
header("Content-type: text/html; charset=utf8");
include_once ("./config.inc.php");
$ip = $_SERVER["REMOTE_ADDR"];
$time = time();
$token = md5($time . $ip);
$qrcode = "qrcode.png";

if (!empty($_SERVER["HTTP_REFERER"])) {
	@session_start();
	$_SESSION[$apiName]["jumpurl"] = $_SERVER["HTTP_REFERER"];
}

$url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" . $AppID . "&redirect_uri=" . $callback . "&response_type=code&scope=snsapi_userinfo&state=" . $token . "&connect_redirect=1#wechat_redirect";
$_SESSION["jieqiUserApi"]["weixin"]["state"] = $token;

if (is_weixin()) {
	header("Location:" . $url);
	exit();
}

@unlink($qrcode);
include ("./phpqrcode/phpqrcode.php");
$errorCorrectionLevel = "L";
$matrixPointSize = "5";
QRcode::png($url, "qrcode.png", $errorCorrectionLevel, $matrixPointSize);
echo "\r\n\r\r\n<!DOCTYPE html>\r\r\n<html>\r\r\n<head>\r\r\n<title>微信登录</title>\r\r\n<meta charset=\"gbk\">\r\r\n<link rel=\"stylesheet\" href=\"js/impowerApp29579a.css\">\r\r\n<link href=\"https://res.wx.qq.com/connect/zh_CN/htmledition/images/favicon16cb56.ico\" rel=\"Shortcut Icon\">\r\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\" />\r\r\n<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\r\r\n<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">\r\r\n<meta http-equiv=\"Cache-Control\" content=\"no-cache\">\r\r\n<meta http-equiv=\"Pragma\" content=\"no-cache\">\r\r\n<script src=\"js/jquery.min29f55f.js\"></script>\r\r\n<style>\r\r\n@font-face {\r\r\n\tfont-family: uc-nexus-iconfont;\r\r\n\tsrc: url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_kcuuxxyze2hjjor.woff) format('woff'), url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_kcuuxxyze2hjjor.ttf) format('truetype')\r\r\n}\r\r\n</style>\r\r\n</head>\r\r\n<body style=\"padding: 50px; background-color: rgb(51, 51, 51);\">\r\r\n<div class=\"main impowerBox\">\r\r\n  <div class=\"loginPanel normalPanel\">\r\r\n    <div class=\"title\">微信登录</div>\r\r\n    <div class=\"waiting panelContent\">\r\r\n      <div class=\"wrp_code\"><img class=\"qrcode lightBorder\" src=\"";
echo $qrcode . "?code=" . time();
echo "\"></div>\r\r\n      <div class=\"info\">\r\r\n        <div class=\"status status_browser js_status normal\" id=\"wx_default_tip\">\r\r\n          <p>请使用微信扫描二维码登录</p>\r\r\n          <!-- <p>“书橱小说”</p> -->\r\r\n        </div>\r\r\n        <div class=\"status status_succ js_status normal\" style=\"display:none\" id=\"wx_after_scan\"> <i class=\"status_icon icon38_msg succ\"></i>\r\r\n          <div class=\"status_txt\">\r\r\n            <h4>扫描成功</h4>\r\r\n            <p>请在微信中点击确认即可登录</p>\r\r\n          </div>\r\r\n        </div>\r\r\n        <!-- <div class=\"status status_fail js_status normal\" style=\"display:none\" id=\"wx_after_cancel\"> <i class=\"status_icon icon38_msg warn\"></i>\r\r\n          <div class=\"status_txt\">\r\r\n            <h4>您已取消此次登录</h4>\r\r\n            <p>您可再次扫描登录，或关闭窗口</p>\r\r\n          </div>\r\r\n        </div> -->\r\r\n      </div>\r\r\n    </div>\r\r\n  </div>\r\r\n</div>\r\r\n</body>\r\r\n <script src=\"/sink/js/jquery.min.js\"></script>\r\r\n <script src=\"layer/layer.js\"></script>\r\r\n <script>\r\r\n\tfunction ajaxstatus(){\r\r\n\t\t$.post('/api/weixin/testing.php',{'token':\"";
echo $token;
echo "\"},function(data){\r\r\n\t\t\tif( data == 'true' ){\r\r\n\t\t\t\tlayer.msg('扫码成功');\r\r\n\t\t\t\twindow.location.href=\"loginback.php?token=";
echo $token;
echo "\";\r\r\n\t\t\t}\r\r\n\t\t});\r\r\n\t}\r\r\n\tsetInterval(ajaxstatus,3000);\r\r\n </script>\r\r\n</html>\r\r\n";

?>
