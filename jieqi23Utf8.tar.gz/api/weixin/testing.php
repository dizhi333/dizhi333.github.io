<?php

define("JIEQI_MODULE_NAME", "system");
define("JIEQI_NEED_SESSION", 1);
require_once ("../../global.php");
@$token = $_POST["token"];

if (empty($token)) {
	echo "false";
	exit();
}

jieqi_includedb();
$query = JieqiQueryHandler::getInstance("JieqiQueryHandler");
$sql = "SELECT * FROM wechat WHERE token = '" . $token . "' LIMIT 0, 1";
$query->execute($sql);
$row = $query->getRow();
if (empty($row) || ($row == false)) {
	echo "false";
	exit();
}
else if (!empty($row["openid"])) {
	echo "true";
	exit();
}

?>
