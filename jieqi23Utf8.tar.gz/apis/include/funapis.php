<?php

function jieqi_apis_xmltext($text)
{
	$entities = array("&" => "&amp;", "<" => "&lt;", ">" => "&gt;", "'" => "&apos;", "\"" => "&quot;");
	$text = strtr($text, $entities);
	$text = preg_replace("/[\\x00-\\x08\\x0b-\\x0c\\x0e-\\x1f]/", "", $text);
	return $text;
}

function jieqi_apis_isshare($article, $sid = 0)
{
	global $query;

	if (!is_a($query, "JieqiQueryHandler")) {
		jieqi_includedb();
		$query = JieqiQueryHandler::getInstance("JieqiQueryHandler");
	}

	$sharemode = (defined("JIEQI_SHARE_MODE") ? JIEQI_SHARE_MODE : 1);

	switch ($sharemode) {
	case 2:
		if (is_array($article)) {
			if (0 < $article["isshare"]) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (is_numeric($article)) {
			$sql = "SELECT isshare FROM " . jieqi_dbprefix("article_article") . " WHERE articleid = " . intval($article) . " LIMIT 0, 1";
			$query->execute($sql);
			$row = $query->getRow();

			if (!$row) {
				return false;
			}
			else if (0 < $row["isshare"]) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

		break;

	case 3:
		if (is_array($article)) {
			if (0 < $article["isshare"]) {
				return false;
			}
			else {
				return true;
			}
		}
		else if (is_numeric($article)) {
			$sql = "SELECT isshare FROM " . jieqi_dbprefix("article_article") . " WHERE articleid = " . intval($article) . " LIMIT 0, 1";
			$query->execute($sql);
			$row = $query->getRow();

			if (!$row) {
				return false;
			}
			else if (0 < $row["isshare"]) {
				return false;
			}
			else {
				return true;
			}
		}
		else {
			return false;
		}

		break;

	case 4:
		if (is_array($article)) {
			$aid = intval($article["articleid"]);
		}
		else if (is_numeric($article)) {
			$aid = intval($article);
		}
		else {
			return false;
		}

		$sql = "SELECT articleid FROM " . jieqi_dbprefix("article_share") . " WHERE articleid = " . $aid . " AND ssid = " . intval($sid) . " LIMIT 0, 1";
		$query->execute($sql);
		$row = $query->getRow();

		if (!$row) {
			return false;
		}
		else {
			return true;
		}

		break;

	case 1:
	default:
		return true;
		break;
	}
}

function jieqi_apis_dehtmlentities($str, $encode = "GBK")
{
	$codes = preg_split("/(&#\d+;)/", $str, -1, PREG_SPLIT_DELIM_CAPTURE);
	$cnum = count($codes);
	$str = "";

	for ($i = 0; $i < $cnum; $i++) {
		$str .= $codes[$i];
		$i++;
		$str .= iconv("UCS-2BE", $encode . "//IGNORE", pack("n", substr($codes[$i], 2, -1)));
	}

	return $str;
}

if (isset($jieqiShares[$_GET["sid"]]["sharemode"])) {
	define("JIEQI_SHARE_MODE", $jieqiShares[$_GET["sid"]]["sharemode"]);
}
else if (isset($apisConfigs["sharemode"])) {
	define("JIEQI_SHARE_MODE", $apisConfigs["sharemode"]);
}
else {
	define("JIEQI_SHARE_MODE", 1);
}

?>
