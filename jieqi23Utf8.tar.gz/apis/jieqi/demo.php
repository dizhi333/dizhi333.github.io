<?php

function apis_makesign($params)
{
	ksort($params);
	$sign = "";

	foreach ($params as $k => $v ) {
		if (($k != "sign") && (0 < strlen($v))) {
			$sign .= $k . "=" . $v . "&";
		}
	}

	$sign = md5($sign . "key=" . $_POST["apikey"]);
	$params["sign"] = $sign;
	return $params;
}

define("JIEQI_MODULE_NAME", "article");
require_once ("../../global.php");
jieqi_getconfigs("system", "shares", "jieqiShares");
include_once (JIEQI_ROOT_PATH . "/include/apicommon.php");
include_once (JIEQI_ROOT_PATH . "/apis/include/funapis.php");
include_once ("common.inc.php");

switch ($_POST["act"]) {
case "articlelist":
case "infolist":
case "articlecount":
	$params = array("sid" => $_POST["apiid"], "uptime" => $_POST["uptime"], "endtime" => $_POST["endtime"]);
	$params = apis_makesign($params);
	$url = "";

	foreach ($params as $k => $v ) {
		$url .= ($url == "" ? "?" : "&");
		$url .= urlencode($k) . "=" . urlencode($v);
	}

	$url = $_POST["apiurl"] . "/" . $_POST["act"] . ".php" . $url;
	echo "<a href=\"" . $url . "\" target=\"_blank\">" . jieqi_htmlstr($url) . "</a><hr />" . jieqi_htmlstr(file_get_contents($url));
	break;

case "articleinfo":
	$params = array("sid" => $_POST["apiid"], "aid" => $_POST["aid"]);
	$params = apis_makesign($params);
	$url = "";

	foreach ($params as $k => $v ) {
		$url .= ($url == "" ? "?" : "&");
		$url .= urlencode($k) . "=" . urlencode($v);
	}

	$url = $_POST["apiurl"] . "/articleinfo.php" . $url;
	echo "<a href=\"" . $url . "\" target=\"_blank\">" . jieqi_htmlstr($url) . "</a><hr />" . jieqi_htmlstr(file_get_contents($url));
	break;

case "articlechapter":
	$params = array("sid" => $_POST["apiid"], "aid" => $_POST["aid"]);
	$params = apis_makesign($params);
	$url = "";

	foreach ($params as $k => $v ) {
		$url .= ($url == "" ? "?" : "&");
		$url .= urlencode($k) . "=" . urlencode($v);
	}

	$url = $_POST["apiurl"] . "/articlechapter.php" . $url;
	echo "<a href=\"" . $url . "\" target=\"_blank\">" . jieqi_htmlstr($url) . "</a><hr />" . jieqi_htmlstr(file_get_contents($url));
	break;

case "chaptercontent":
	$params = array("sid" => $_POST["apiid"], "aid" => $_POST["aid"], "cid" => $_POST["cid"]);
	$params = apis_makesign($params);
	$url = "";

	foreach ($params as $k => $v ) {
		$url .= ($url == "" ? "?" : "&");
		$url .= urlencode($k) . "=" . urlencode($v);
	}

	$url = $_POST["apiurl"] . "/chaptercontent.php" . $url;
	echo "<a href=\"" . $url . "\" target=\"_blank\">" . jieqi_htmlstr($url) . "</a><hr />" . jieqi_htmlstr(file_get_contents($url));
	break;

default:
	echo file_get_contents("demo.html");
	break;
}

?>
