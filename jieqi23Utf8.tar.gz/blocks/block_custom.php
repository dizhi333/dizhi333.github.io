<?php

class BlockSystemCustom extends JieqiBlock
{
	public $module = "system";

	public function updateContent($isreturn = false)
	{
		global $jieqiTpl;
		$ret = "";
		include_once (JIEQI_ROOT_PATH . "/class/blocks.php");
		$blocks_handler = &JieqiBlocksHandler::getInstance("JieqiBlocksHandler");

		if (!empty($this->blockvars["bid"])) {
			$block = $blocks_handler->get($this->blockvars["bid"]);

			if (is_object($block)) {
				switch ($block->getVar("contenttype")) {
				case JIEQI_CONTENT_TXT:
					$ret = $block->getVar("content", "s");
					break;

				case JIEQI_CONTENT_HTML:
					$ret = $block->getVar("content", "n");
					break;

				case JIEQI_CONTENT_JS:
					$ret = "<script type=\"text/javascript\">" . $block->getVar("content", "n") . "</script>";
					break;

				case JIEQI_CONTENT_MIX:
					$ret = $block->getVar("content", "n");
					break;

				case JIEQI_CONTENT_PHP:
					break;
				}

				$blocks_handler->saveContent($block->getVar("bid"), $block->getVar("modname"), $block->getVar("contenttype"), $ret);
			}
			else {
				$ret = "block not exists! (id:" . $this->blockvars["bid"] . ")";
			}
		}
		else {
			if (!empty($this->blockvars["filename"]) && preg_match("/^\w+$/", $this->blockvars["filename"])) {
				$blockpath = ($this->blockvars["module"] == "system" ? JIEQI_ROOT_PATH : $GLOBALS["jieqiModules"][$this->blockvars["module"]]["path"]);
				$blockpath .= "/templates/blocks/" . $this->blockvars["filename"] . ".html";
				$ret = (isset($jieqiTpl) ? $jieqiTpl->fetch($blockpath) : jieqi_readfile($blockpath));
				$blocks_handler->saveContent($this->blockvars["filename"], $this->blockvars["module"], JIEQI_CONTENT_HTML, $ret);
			}
			else {
				$ret = "empty block id!";
			}
		}

		if ($isreturn) {
			return $ret;
		}
	}
}


?>
