<?php

class BlockSystemMessage extends JieqiBlock
{
	public $module = "system";
	public $template = "block_message.html";
}


?>
