<?php

class BlockSystemSearchuser extends JieqiBlock
{
	public $module = "system";
	public $template = "block_searchuser.html";
}


?>
