<?php

class BlockSystemTopuser extends JieqiBlock
{
	public $module = "system";
	public $template = "block_topuser.html";
}


?>
