<?php

class BlockSystemUserbox extends JieqiBlock
{
	public $module = "system";
	public $template = "block_userbox.html";
}


?>
