<?php

class BlockSystemUserset extends JieqiBlock
{
	public $module = "system";
	public $template = "block_userset.html";
}


?>
