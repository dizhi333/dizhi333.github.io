<?php

$jieqiArticleuplog = array("articleuptime" => 1503027354, "vipuptime" => 1503027354, "chapteruptime" => 1503027354);

?>
