<?php

$jieqiNewsuplog = array("t1" => 1514800552, "t2" => 0);

?>
