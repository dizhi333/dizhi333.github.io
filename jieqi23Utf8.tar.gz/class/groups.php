<?php

jieqi_includedb();

class JieqiGroups extends JieqiObjectData
{
	public function JieqiGroups()
	{
		$this->JieqiObject();
		$this->initVar("groupid", JIEQI_TYPE_INT, 0, "序号", false, 5);
		$this->initVar("name", JIEQI_TYPE_TXTBOX, "", "用户组名称", true, 50);
		$this->initVar("description", JIEQI_TYPE_TXTAREA, "", "描述", false, NULL);
		$this->initVar("grouptype", JIEQI_TYPE_INT, 0, "类型", false, 1);
	}
}

class JieqiGroupsHandler extends JieqiObjectHandler
{
	public function JieqiGroupsHandler($db = "")
	{
		$this->JieqiObjectHandler($db);
		$this->basename = "groups";
		$this->autoid = "groupid";
		$this->dbname = "system_groups";
	}
}


?>
