<?php

jieqi_includedb();
include_once (JIEQI_ROOT_PATH . "/class/topics.php");

class JieqiPtopics extends JieqiTopics
{
	public function JieqiPtopics()
	{
		$this->JieqiTopics();
	}
}

class JieqiPtopicsHandler extends JieqiObjectHandler
{
	public function JieqiPtopicsHandler($db = "")
	{
		$this->JieqiObjectHandler($db);
		$this->basename = "ptopics";
		$this->autoid = "topicid";
		$this->dbname = "system_ptopics";
	}
}

?>
