<?php

jieqi_includedb();

class JieqiUserlink extends JieqiObjectData
{
	public function JieqiUserlink()
	{
		$this->JieqiObjectData();
		$this->initVar("ulid", JIEQI_TYPE_INT, 0, "序号", false, 11);
		$this->initVar("ultitle", JIEQI_TYPE_TXTBOX, "", "网址标题", false, 60);
		$this->initVar("ulurl", JIEQI_TYPE_TXTBOX, "", "网址", false, 100);
		$this->initVar("ulinfo", JIEQI_TYPE_TXTAREA, "", "网址说明", false, NULL);
		$this->initVar("userid", JIEQI_TYPE_INT, 0, "用户ID", false, 11);
		$this->initVar("username", JIEQI_TYPE_TXTBOX, "", "用户名", false, 30);
		$this->initVar("score", JIEQI_TYPE_INT, 0, "评分", false, 1);
		$this->initVar("weight", JIEQI_TYPE_INT, 0, "等级", false, 6);
		$this->initVar("toptime", JIEQI_TYPE_INT, 0, "置顶时间", false, 11);
		$this->initVar("addtime", JIEQI_TYPE_INT, 0, "加入时间", false, 11);
		$this->initVar("allvisit", JIEQI_TYPE_INT, 0, "点击数", false, 11);
	}
}

class JieqiUserlinkHandler extends JieqiObjectHandler
{
	public function JieqiUserlinkHandler($db = "")
	{
		$this->JieqiObjectHandler($db);
		$this->basename = "userlink";
		$this->autoid = "ulid";
		$this->dbname = "system_userlink";
	}
}


?>
