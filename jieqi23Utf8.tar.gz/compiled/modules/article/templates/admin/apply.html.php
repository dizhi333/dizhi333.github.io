<?php
echo '
<div class="gridtop">作者申请记录&nbsp;&nbsp;&nbsp; <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php">全部记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=1">申请VIP记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=2">申请包月记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=3">申请签约记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=4">申请精品记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=5">申请封面推荐记录</a> | <a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?type=6">申请VIP免费阅读记录</a></div>
<form id="form1" name="form1" method="post" action="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?action=batchdel" onSubmit="javascript:if(confirm(\'确实要删除选中记录么？\')) return true; else return false;">
<table class="grid" width="100%" align="center">
  <tr align="center">
    <th width="4%"><input type="checkbox" id="checkall" name="checkall" value="checkall" onclick="javascript: for (var i=0;i<this.form.elements.length;i++){ if (this.form.elements[i].name != \'checkkall\') this.form.elements[i].checked = this.form.checkall.checked; }"></th>
    <th width="5%">作品序号</th>
    <th width="20%">作品名称</th>
    <th width="12%">申请作者</th>
    <th width="14%">申请时间</th>
	<th width="10%">申请类型</th>
    <th width="10%">审核状态</th>
    <th width="15%">联系方式</th>
    <th width="14%">操作</th>
  </tr>
  ';
if (empty($this->_tpl_vars['applyrows'])) $this->_tpl_vars['applyrows'] = array();
elseif (!is_array($this->_tpl_vars['applyrows'])) $this->_tpl_vars['applyrows'] = (array)$this->_tpl_vars['applyrows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['applyrows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['applyrows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['applyrows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['applyrows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['applyrows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
  <tr>
    <td align="center"><input name="id[]" type="checkbox" id="id[]" value="'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['id'].'" /></td>
    <td align="center">'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['articleid'].'</td>
    <td align="center"><a href="'.jieqi_geturl('article','article',$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['articleid'],'info').'" target="_blank">'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['articlename'].'</a></td>
    <td align="center"><a href="'.jieqi_geturl('system','user',$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['userid']).'" target="_blank">'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['username'].'</a></td>
    <td align="center">'.date('Y-m-d H:i:s',$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['date']).'</td>
	<td align="center">'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['types'].'</td>
    <td align="center">';
if($this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['typeid'] == 0){
echo '处理中';
}elseif($this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['typeid'] == 1){
echo '已失败';
}elseif($this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['typeid'] == 2){
echo '通过';
}
echo '</td>
    <td align="center">'.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['pc'].'</td>
    <td align="center">';
if($this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['typeid'] == 0){
echo '<a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/applyaudit.php?id='.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['id'].'">审核</a>   ';
}
echo '<a href="javascript:if(confirm(\'确实要删除该申请记录么？\')) document.location=\''.$this->_tpl_vars['jieqi_modules']['article']['url'].'/admin/apply.php?action=delete&id='.$this->_tpl_vars['applyrows'][$this->_tpl_vars['i']['key']]['id'].'\'">删除</a></td>
  </tr>
  ';
}
echo '
  <tr>
    <td colspan="9" align="left"><input type="submit" name="Submit" value="批量删除" class="button" /></td>
    </tr>  
</table>
</form>

<div class="pages">'.$this->_tpl_vars['url_jumppage'].'</div>';
?>