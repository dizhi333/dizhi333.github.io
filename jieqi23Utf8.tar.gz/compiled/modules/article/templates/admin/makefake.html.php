<?php
echo '<br>
<table class="grid" width="80%" align="center">
  <caption>生成伪静态/静态页面</caption>
<form name="form1" method="post" action="'.$this->_tpl_vars['article_dynamic_url'].'/admin/createfake.php" target="_blank">
  <tr>
    <td width="29%" align="right">文件格式：</td>
    <td width="71%">
      <input name="filetype" type="radio" value="fake" checked="checked" />
      伪静态 &nbsp;&nbsp;
      <input type="radio" name="filetype" value="static" />
      静态</td>
  </tr>
  <tr>
    <td width="29%" align="right">起始序号：</td>
    <td width="71%"><input name="startid" type="text" id="startid" size="10" maxlength="11" class="text"> 
    <span class="hottext">起始和终止序号都留空的话，系统自动从当前数据库的最小需要生成到最大序号。</span></td>
  </tr>
  <tr>
    <td align="right">终止序号：</td>
    <td><input name="stopid" type="text" id="stopid" size="10" maxlength="11" class="text"></td>
  </tr>
  <tr>
    <td align="right">生成的页面类别：</td>
    <td>
	<input name="action" type="radio" value="makeinfo" checked> 小说信息页面（每篇小说一个文件，按序号生成）<br>
	<input type="radio" name="action" value="makesort"> 小说分类列表（每页一个文件，按页码生成）<br>
	<input type="radio" name="action" value="makeinitial"> 小说按字母分类页面（每页一个文件，按页面生成）<br>
	<input type="radio" name="action" value="maketoplist"> 排行榜页面（每页一个文件，按页面生成）<br>
	</td>
  </tr>
  <tr>
    <td colspan="2">提示：起始序号最小为1，终止序号应该比实际最大序号设置更大一些，这样即使增加新小说也不会出现文件找不到。</td>
    </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td><input type="submit" name="make1" value="开始生成" class="button"></td>
  </tr>
  <tr>
    <td colspan="2" align="right" class="foot">&nbsp;</td>
  </tr>
  </form>
</table>

<br>
<br>
';
?>