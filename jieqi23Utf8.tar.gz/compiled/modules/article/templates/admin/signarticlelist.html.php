<?php

echo "<script type=\"text/javascript\" src=\"/author/scripts/DatePiker.js\"></script>\r\n<script type=\"text/javascript\">\r\nfunction showupdate(id) {\r\n\tif(id==0) {\r\n\t\tdocument.getElementById('showupdate0').style.display='inline';\r\n\t\tdocument.getElementById('showupdate1').style.display='none';\r\n\t} else {\r\n\t\tdocument.getElementById('showupdate0').style.display='none';\r\n\t\tdocument.getElementById('showupdate1').style.display='inline';\r\n\t}\r\n}\r\n</script>\r\n<form name=\"frmsearch\" method=\"get\" action=\"signarticle.php\">\r\n<table width=\"100%\" align=\"center\" cellpadding=\"0\" cellspacing=\"1\" class=\"grid\">\r\n    <tr>\r\n        <td class=\"odd\">关键字：\r\n            <input name=\"keyword\" type=\"text\" id=\"keyword\" class=\"text\" size=\"0\" maxlength=\"50\" value=\"" . $this->_tpl_vars["keyword"] . "\"> \r\n            <select name=\"keytype\" id=\"keytype\">\r\n            \t<option value=\"0\"";

if (0 < $this->_tpl_vars["keytype"]) {
	echo " selected=\"selected\"";
}

echo ">书名</option>\r\n\t\t\t\t<option value=\"3\"";

if ($this->_tpl_vars["keytype"] == 3) {
	echo " selected=\"selected\"";
}

echo ">书号</option>\r\n                <option value=\"1\"";

if ($this->_tpl_vars["keytype"] == 1) {
	echo " selected=\"selected\"";
}

echo ">作者</option>\r\n            </select>\r\n            &nbsp;&nbsp;\r\n            字数：从<input type='text' class=\"text\" name='beginsize' id='beginsize' size='10' maxlength='10' value='" . $this->_tpl_vars["beginsize"] . "' />到<input type='text' class=\"text\" name='endsize' id='endsize' size='10' maxlength='10' value='" . $this->_tpl_vars["endsize"] . "' />\r\n\t\t\t<select name=\"signtype\" id=\"signtype\">\r\n            \t<option value=\"\"";

if ($this->_tpl_vars["signtype"] == "") {
	echo " selected=\"selected\"";
}

echo ">签约</option>\r\n\t\t\t\t<option value=\"0\"";

if ($this->_tpl_vars["signtype"] == "0") {
	echo " selected=\"selected\"";
}

echo ">未签</option>\r\n            \t<option value=\"1\"";

if ($this->_tpl_vars["signtype"] == "1") {
	echo " selected=\"selected\"";
}

echo ">已签</option>\r\n                <option value=\"2\"";

if ($this->_tpl_vars["signtype"] == "2") {
	echo " selected=\"selected\"";
}

echo ">B 签</option>\r\n\t\t\t\t<option value=\"3\"";

if ($this->_tpl_vars["signtype"] == "10") {
	echo " selected=\"selected\"";
}

echo ">A 签</option>\r\n            </select>\r\n            <select name=\"isvip\" id=\"isvip\">\r\n            \t<option value=\"\"";

if ($this->_tpl_vars["isvip"] == "") {
	echo " selected=\"selected\"";
}

echo ">上架</option>\r\n\t\t\t\t<option value=\"0\"";

if ($this->_tpl_vars["isvip"] == "0") {
	echo " selected=\"selected\"";
}

echo ">免费</option>\r\n            \t<option value=\"1\"";

if ($this->_tpl_vars["isvip"] == "1") {
	echo " selected=\"selected\"";
}

echo ">VIP</option>\r\n\t\t\t\t<option value=\"1\"";

if ($this->_tpl_vars["isvip"] == "3") {
	echo " selected=\"selected\"";
}

echo ">包月</option>\r\n\t\t\t\t<option value=\"1\"";

if ($this->_tpl_vars["isvip"] == "4") {
	echo " selected=\"selected\"";
}

echo ">签约</option>\r\n            </select>\r\n            <select name=\"isupdate\" id=\"isupdate\" onchange=\"showupdate(this.options[this.selectedIndex].value)\">\r\n            \t<option value=\"1\"";

if ($this->_tpl_vars["isupdate"] == 1) {
	echo " selected=\"selected\"";
}

echo ">已更</option>\r\n                <option value=\"0\"";

if ($this->_tpl_vars["isupdate"] == 0) {
	echo " selected=\"selected\"";
}

echo ">未更</option>\r\n\t\t\t\t<option value=\"2\"";

if ($this->_tpl_vars["isupdate"] == 2) {
	echo " selected=\"selected\"";
}

echo ">新签</option>\r\n            </select>\r\n            <select name=\"sortid\" id=\"srotid\">\r\n            \t<option value=\"\">分类</option>\r\n                ";

if (empty($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = array();
}
else if (!is_array($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = (array) $this->_tpl_vars["sortrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["sortrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["sortrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["sortrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n                <option value=\"" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["sortid"] . "\">" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["sortname"] . "</option>\r\n                ";
}

echo "\r\n            </select>\r\n            <span id=\"showupdate1\" style=\"display:";

if ($this->_tpl_vars["isupdate"] != 0) {
	echo "inline";
}
else {
	echo "none";
}

echo ";\">\r\n            时间：从<input type='text' class=\"text\" name='begindate' id='begindate' size='13' maxlength='50' value='" . $this->_tpl_vars["begindate"] . "' onfocus=\"HS_setDate(this)\"/>到<input type='text' class=\"text\" name='enddate' id='enddate' size='13' maxlength='50' value='" . $this->_tpl_vars["enddate"] . "' onfocus=\"HS_setDate(this)\"/> \r\n            </span>\r\n            <span id=\"showupdate0\" style=\"display:";

if ($this->_tpl_vars["isupdate"] == 0) {
	echo "inline";
}
else {
	echo "none";
}

echo ";\">\r\n            超过<input type='text' class=\"text\" name='day' id='day' size='5' maxlength='50' value='" . $this->_tpl_vars["day"] . "'/>天未更新\r\n            </span>\r\n            &nbsp;&nbsp;\r\n            <input type=\"submit\" name=\"btnsearch\" class=\"button\" value=\"搜 索\">\r\n        </td>\r\n    </tr>\r\n</table>\r\n</form>\r\n<br />\r\n<div class=\"gridtop\">小说批量导出成EXCEL</div>\r\n<table width=\"100%\" cellpadding=\"0\" cellspacing=\"1\" class=\"grid\">\r\n  <tr align=\"center\">\r\n  \t<td class=\"head\">书号</td>\r\n    <td class=\"head\">文章名称</td>\r\n    <td class=\"head\">文章分类</td>\r\n    <td class=\"head\">作者ID</td>\r\n    <td class=\"head\">作者</td>\r\n    <td class=\"head\">鲜花</td>\r\n\t<td class=\"head\">月票</td>\r\n\t<td class=\"head\">字数</td>\r\n    <td class=\"head\">收藏/推荐</td>\r\n    <td class=\"head\" style=\"cursor:pointer;\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&orderby=lastupdate'\"> 更新时间</td>\r\n    <td class=\"head\" style=\"cursor:pointer;\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&orderby=fullflag'\">完本</td>\r\n    <td class=\"head\" style=\"cursor:pointer;\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&orderby=isvip'\">上架</td>\r\n\t<td class=\"head\" style=\"cursor:pointer;\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&orderby=signdate'\">签约</td>\r\n  </tr>\r\n  ";

if (empty($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = array();
}
else if (!is_array($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = (array) $this->_tpl_vars["articlerows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["articlerows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["articlerows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["articlerows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n  <tr>\r\n  \t<td class=\"odd\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "</td>\r\n    <td class=\"even\"><a href=\"chapter.php?keyword=" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "&keytype=0&begindate=" . $this->_tpl_vars["begindate"] . "&enddate=" . $this->_tpl_vars["enddate"] . "\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</a></td>\r\n    <td class=\"even\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["sort"] . "</td>\r\n    <td class=\"even\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["authorid"] . "</td>\r\n    <td class=\"even\">";

	if ($this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["authorid"] == 0) {
		echo $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["author"];
	}
	else {
		echo "<a href=\"/userinfo.php?id=" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["authorid"] . "\" target=\"_blank\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["author"] . "</a>";
	}

	echo "</td>\r\n    <td class=\"odd\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["allflower"] . "</td>\r\n    <td class=\"odd\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["allvipvote"] . "</td>\r\n    <td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["size_c"] . "</td>\r\n    <td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["goodnumt"] . "/" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["allvote"] . "</td>\r\n    <td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["lastupdate"] . "</td>\r\n   \t<td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["fullflag"] . "</td>\r\n    <td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["isvip"] . "</td>\r\n\t<td class=\"even\" align=\"center\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["issign"];
	if (($this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["signdate"] != 0) && ($this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["issign"] != "否")) {
		echo "<br />" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["signdate"];
	}

	echo "</td>\r\n  </tr>\r\n  ";
}

echo "\r\n  <tr>\r\n    <td width=\"5%\" class=\"odd\" align=\"center\"></td>\r\n    <td colspan=\"15\" align=\"left\" class=\"odd\"> <input type=\"button\" name=\"Submit\" value=\"本页导出excel\" class=\"button\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&action=excel'\"> <input type=\"button\" name=\"Submit\" value=\"全部导出excel\" class=\"button\" onclick=\"location.href='" . $this->_tpl_vars["pagelink"] . $this->_tpl_vars["page"] . "&action=excel&actiontype=all'\"></td>\r\n  </tr>\r\n</table>\r\n</form>\r\n<div class=\"pages\">" . $this->_tpl_vars["url_jumppage"] . "</div>\r\n<script type=\"text/javascript\" src=\"/scripts/popup.js\"></script>";

?>
