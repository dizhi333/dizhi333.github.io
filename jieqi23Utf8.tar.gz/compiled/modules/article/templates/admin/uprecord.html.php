<?php
echo '﻿';
echo '

<table class="grid" width="100%" align="center">
    <tr>
        <td>
        <button type="a" name="btnsearch" class="button"><a href="'.$this->_tpl_vars['article_static_url'].'/admin/uprecord.php?id='.$this->_tpl_vars['articleid'].'"><font color="white">全部记录</font></a></button>
		<button type="a" name="btnsearch" class="button"><a href="'.$this->_tpl_vars['article_static_url'].'/admin/uprecord.php?id='.$this->_tpl_vars['articleid'].'&month=1"><font color="white">1个月前记录</font></a></button>
		<button type="a" name="btnsearch" class="button"><a href="'.$this->_tpl_vars['article_static_url'].'/admin/uprecord.php?id='.$this->_tpl_vars['articleid'].'&month=2"><font color="white">2个月前记录</font></a></button>
		<button type="a" name="btnsearch" class="button"><a href="'.$this->_tpl_vars['article_static_url'].'/admin/uprecord.php?id='.$this->_tpl_vars['articleid'].'&month=3"><font color="white">3个月前记录</font></a></button>
		<button type="a" name="btnsearch" class="button"><a href="'.$this->_tpl_vars['article_static_url'].'/admin/article.php"><font color="white">返回小说管理</font></a></button>
        </td>
    </tr>
</table>
<table class="grid" width="100%" align="center">
<caption>'.$this->_tpl_vars['articlename'].'更新记录</caption>
  <tr align="center">
    <th width="4%">书号</th>
    <th width="18%">小说名称</th>
    <th width="24%">最新章节</th>
    <th width="8%">作者</th>
    <th width="6%">字数</th>
    <th width="16%">更新时间</th>
    <th width="6%">状态</th>
  </tr>
  '.$this->_tpl_vars['start'].'
  ';
if (empty($this->_tpl_vars['uprecordrows'])) $this->_tpl_vars['uprecordrows'] = array();
elseif (!is_array($this->_tpl_vars['uprecordrows'])) $this->_tpl_vars['uprecordrows'] = (array)$this->_tpl_vars['uprecordrows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['uprecordrows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['uprecordrows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['uprecordrows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['uprecordrows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['uprecordrows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
  <tr>
    <td align="center">'.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['articleid'].'</td>
    <td><a href="'.jieqi_geturl('article','article',$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['articleid'],'info').'" target="_blank">'.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['articlename'].'</a></td>
    <td>';
if($this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['isvip'] > 0){
echo '<span class="hottext">vip</span>';
}
echo $this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</td>
    <td><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/authorpage.php?id='.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['posterid'].'" target="_blank">'.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['poster'].'</a></td>
    <td>'.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['size'].'</td>
    <td align="center">'.date('Y-m-d H:i:s',$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['lastupdate']).'</td>
    <td align="center">'.$this->_tpl_vars['uprecordrows'][$this->_tpl_vars['i']['key']]['power'].'</td>
  </tr>
  ';
}
echo '
</table>
<div class="pages">'.$this->_tpl_vars['url_jumppage'].'</div>';
?>