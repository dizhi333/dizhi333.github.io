<?php
echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>章节列表-'.$this->_tpl_vars['jieqi_sitename'].'</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/bootstrap.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/theme.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/font-awesome.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/ionicons.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/_all-skins.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/blue.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/style.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article-create.css" rel="stylesheet">
<style type="text/css">
body,td,th {
	font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
</style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="/" class="navbar-brand">'.$this->_tpl_vars['jieqi_sitename'].'&middot;<span>作家中心</span></a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/author">作品管理 <span class="sr-only">(current)</span></a></li>
                        <li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?id=3">申请签约</a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/mreport">作品收入</a></li>
						
                    </ul>
                </div>
                
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="'.$this->_tpl_vars['jieqi_url'].'/authornotice" class="dropdown">
                                <i class="fa fa-bell-o"></i>&nbsp;&nbsp;&nbsp;通知
                                                            </a>
                        </li>
                        <li class="dropdown user user-menu">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'" class="user-image" alt="'.$this->_tpl_vars['jieqi_username'].'">
                                <span class="hidden-xs">'.$this->_tpl_vars['jieqi_username'].'</span>
                            </a>
                                                        <ul class="dropdown-menu">
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php"><i class="fa fa-edit"></i>我的资料</a>
                                </li>
                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php" id="modifyPwdBtn"><i class="fa fa-lock"></i>更改密码</a>
                                </li>
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'"><i class="fa fa-sign-out"></i>退出登录</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="box box-default chapter">
    <div class="box-header with-border">
        <h3 class="box-title">申请上架</h3>
    </div>
    <div class="box-body">
        <div class="chapter-content">

		
		<form id="register-form" class="form-horizontal" action="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?do=submit" method="post" enctype="multipart/form-data">
            <div class="form-input-box">
			<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="article-name">申请说明：</label>
<div class="col-sm-9">
'.$this->_tpl_vars['gfuname'].'
</div>
</div>
<div class="form-group">
                    <label class="col-sm-3 control-label" for="registerform-card_type">书籍名称</label>
                    <div class="col-sm-3">
                        <div class="form-group field-article-channel required">
<select id="article-channel" class="form-control" name="articleid" aria-required="true">
<option value=\'0\'>--请选择--</option>
							';
if($this->_tpl_vars['tid'] == 3){
echo '
							';
if (empty($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = array();
elseif (!is_array($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = (array)$this->_tpl_vars['articlerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['articlerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['articlerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['articlerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
							';
if($this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['issign_n'] == 0){
echo '
                           <option value=\''.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articleid'].'\'>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</option>';
}
echo '
				            ';
}
echo '
							';
}elseif($this->_tpl_vars['tid'] == 1){
echo '
							';
if (empty($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = array();
elseif (!is_array($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = (array)$this->_tpl_vars['articlerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['articlerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['articlerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['articlerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
							';
if($this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['isvip_n'] == 0 && $this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['issign_n'] > 0){
echo '
                           <option value=\''.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articleid'].'\'>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</option>';
}
echo '
				            ';
}
echo '
							';
}else{
echo '
							';
if (empty($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = array();
elseif (!is_array($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = (array)$this->_tpl_vars['articlerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['articlerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['articlerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['articlerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
							';
if($this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['isvip'] > 0 || $this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['issign_n'] > 0){
echo '
                           <option value=\''.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articleid'].'\'>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</option>';
}
echo '
				            ';
}
echo '
							';
}
echo '
</select>
</div>                    </div>
                    
                </div>
                <div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="article-name">联系方式</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" name="pc" placeholder="输入你的手机号码或者是固定电话" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

                <div class="form-group field-article-intro">
<label class="col-sm-3 control-label" for="article-intro">作者留言</label>
<div class="col-sm-9"><textarea id="article-intro" class="form-control" name="text" rows="5" placeholder="输入你想对编辑说的话，作品申请的理由等"></textarea>
<p class="help-block help-block-error">
</p>
</div>
</div>
                <div class="row">
                    <div class="col-sm-offset-4 col-sm-4">
					<input type="hidden" name="action" id="action" value="post" />
                    <input type="submit" value=" 确定申请 " name="submit" class="btn btn-warning btn-block" />
					</div>
                </div>
            </div>
            </form>
		
		
        </div>
    </div>
</div>
          </section>
        </div>
    </div>

    <footer class="main-footer">
        <div class="container">
            <div class="pull-right hidden-xs">
                Copyright &copy; '.date('Y',$this->_tpl_vars['jieqi_time']).' All Rights Reserved '.$this->_tpl_vars['jieqi_sitename'].' 版权所有
            </div>
        </div>
    </footer>
</div>
<div id="msgModal" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">消息提示</h4>
</div>
<div class="modal-body">

</div>
<div class="modal-footer">
<a href="#" class="btn btn-primary" data-dismiss="modal">确定</a>
</div>
</div>
</div>
</div>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.activeForm.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/app.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.slimscroll.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/icheck.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/vue.js"></script>
<!--[if lt IE 9]>
<script src="/js/html5shiv.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">jQuery(document).ready(function () {
var content = new Vue({
  el: \'#editChapter\',
  data: {
      \'chapter\' : {},
  }
});

$(function() {
    $("#publishBtn").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
    $("#publishBtnLeft").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
    
    $("#publishOkBtn").click(function() {
        var $form = $("#edit-form");
        $.ajax({
            url: $form.attr(\'publishUrl\'),
            type: \'post\',
            data: $form.serialize(),
            dataType: \'json\',
            success: function (data) {
                if(data.state == \'error\'){
                    $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+data.msg+\'</p>\');
                    $(\'#msgModal\').modal(\'show\');
                    return;
                }
                if($("#id").val() == \'\'){
                    location.href = \'/chapter/draft?article_id=1518\';
                }else{
                    location.reload();
                }
            }
        });
    });
    
    $("#publishType input").click(function () {
        if($(this).val() == 1){
            $("#dateTimePickerBox").show();
        }else{
            $("#dateTimePickerBox").hide();
        }
    });
});
;jQuery(\'#w0\').parent().datetimepicker({"autoclose":true,"format":"yyyy-mm-dd hh:ii:ss","todayBtn":true,"language":"zh-CN"});
jQuery(\'#publishModal\').modal({"show":false});
});</script></body>
</html>
';
?>