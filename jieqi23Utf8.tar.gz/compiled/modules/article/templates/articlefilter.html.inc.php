<?php
$this->_tpl_vars['jieqi_pagetitle'] = "小说书库-{$this->_tpl_vars['jieqi_sitename']}";
$GLOBALS['jieqiTset']['jieqi_page_rows'] = '10';

?>