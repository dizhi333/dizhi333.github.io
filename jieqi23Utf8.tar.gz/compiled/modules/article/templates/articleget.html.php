<?php
echo '

<!DOCTYPE html>
<html>
<head>
<meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>作品设置-'.$this->_tpl_vars['jieqi_sitename'].'</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/bootstrap.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/theme.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/font-awesome.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/ionicons.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/_all-skins.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/blue.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/style.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article.css" rel="stylesheet">
<style type="text/css">
body,td,th {
	font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
</style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="/" class="navbar-brand">'.$this->_tpl_vars['jieqi_sitename'].'&middot;<span>作家中心</span></a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/author">作品管理 <span class="sr-only">(current)</span></a></li>
						<li><a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?id=3">申请签约</a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/mreport">作品收入</a></li>
						
                    </ul>
                </div>
                
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="'.$this->_tpl_vars['jieqi_url'].'/authornotice" class="dropdown">
                                <i class="fa fa-bell-o"></i>&nbsp;&nbsp;&nbsp;通知
                                                            </a>
                        </li>
                        <li class="dropdown user user-menu">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'" class="user-image" alt="'.$this->_tpl_vars['jieqi_username'].'">
                                <span class="hidden-xs">'.$this->_tpl_vars['jieqi_username'].'</span>
                            </a>
                                                        <ul class="dropdown-menu">
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php"><i class="fa fa-edit"></i>我的资料</a>
                                </li>
                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php" id="modifyPwdBtn"><i class="fa fa-lock"></i>更改密码</a>
                                </li>
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'"><i class="fa fa-sign-out"></i>退出登录</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="box box-default chapter">
    <div class="box-header with-border">
        <h3 class="box-title">作品设置</h3>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/newchapter.php?aid='.$this->_tpl_vars['articleid'].'" class="btn btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> 新建章节</a>
      <!--   <a href="#" article-id="1518" id="createVolumeBtn" class="btn btn-sm btn-default pull-right margin-r-5">新建分卷</a> -->
    </div>
    <div class="box-body">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="/modules/article/articleget.php?id='.$this->_tpl_vars['articleid'].'">作品设置</a></li>
                <li><a href="/modules/article/articlemanage.php?id='.$this->_tpl_vars['articleid'].'">已发布章节</a></li>
				<li><a href="/modules/article/reviewsget.php?aid='.$this->_tpl_vars['articleid'].'">管理书评</a></li>
            </ul>
        </div>
        <div class="article-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-lg-2">
                        <div class="thumbnail">
                                                        <img src="'.$this->_tpl_vars['url_limage'].'" alt="'.$this->_tpl_vars['author'].'">
                                                        <div class="caption">
                                <b>'.$this->_tpl_vars['articlename'].'</b>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-9 col-md-10">
                        <table id="w0" class="table table-striped table-bordered detail-view"><tr><th style="width:120px">小说名称</th><td>'.$this->_tpl_vars['articlename'].'</td></tr>
<tr><th>创建者</th><td>'.$this->_tpl_vars['author'].'</td></tr>
<tr><th>标签</th><td>'.$this->_tpl_vars['articlevals']['keywords'].'</td></tr>
<tr><th>签约状态</th><td>'.$this->_tpl_vars['issign'].'</td></tr>
<tr><th>字数</th><td>'.$this->_tpl_vars['size_c'].'</td></tr>
<tr><th>简介</th><td>'.htmlclickable($this->_tpl_vars['intro']).'</td></tr>
<tr><th>本书公告</th><td></td></tr>
<tr><th>最近更新</th><td>'.date('Y-m-d H:i:s',$this->_tpl_vars['lastupdate']).'</td></tr>
<tr><th>连载状态</th><td>'.$this->_tpl_vars['fullflag'].'</td></tr></table>                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-offset-2 col-sm-4">
                        <a class="btn btn-primary" name="edit-button" href="/modules/article/articleedit.php?id='.$this->_tpl_vars['articleid'].'">编辑</a>                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
         </section>
        </div>
    </div>

    <footer class="main-footer">
        <div class="container">
            <div class="pull-right hidden-xs">
                Copyright &copy; 2017 All Rights Reserved 盛世阅读 版权所有
            </div>
        </div>
    </footer>
</div>

<div id="msgModal" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">消息提示</h4>
</div>
<div class="modal-body">

</div>
<div class="modal-footer">
<a href="#" class="btn btn-primary" data-dismiss="modal">确定</a>
</div>
</div>
</div>
</div>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/app.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.slimscroll.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/icheck.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/vue.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.activeForm.js"></script>
<!--[if lt IE 9]>
<script src="/js/html5shiv.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">jQuery(document).ready(function () {

$(function() {
    $("#createVolumeBtn").click(function() {
        $("#createVolumeForm #createVolumeModalArticleId").val($(this).attr(\'article-id\'));
        $("#createVolumeModal").modal("show");
        return false;
    });
    $("#saveVolumeModalBtn").click(function() {
        var form = $("#createVolumeForm");
        $.ajax({
            url: form.attr(\'action\'),
            type: \'post\',
            data: form.serialize(),
            dataType: \'json\',
            success: function (data) {
                location.reload();
            }
        });
    });
});
jQuery(\'#createVolumeForm\').yiiActiveForm([], []);
jQuery(\'#createVolumeModal\').modal({"show":false});
$("#modifyPwdBtn").click(function() {
    $("#modifyPwdModal").modal(\'show\');
});
});</script></body>
</html>
';
?>