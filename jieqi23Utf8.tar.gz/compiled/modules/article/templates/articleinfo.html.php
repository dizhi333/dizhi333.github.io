<?php
echo '
<script type="text/javascript">
	function CheckPost(){
	if (frmnewreviews.ptitle.value=="")
	{
		alert("评论标题不能为空");
		return false;
	}
	if (frmnewreviews.pcontent.value=="")
	{
		alert("请输入您的评论内容");
		frmnewreviews.pcontent.focus();
		return false;
	}
    if (frmnewreviews.checkcode.value=="")
	{
		alert("请输入验证码");
		frmnewreviews.checkcode.focus();
		return false;
	}
}
</script>
<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="wrap">
    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/666.jpg" alt=""></a>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="/">官网首页</a>
    <span>></span>
    <a href="/books">书库</a>
    <span>></span>
    <a class="active" href="">'.$this->_tpl_vars['articlename'].'</a>
</div>

<div class="c15"></div>

<div class="wrap">
    <div class="detail">
        <div class="left">
            <div class="jianjie">
                <div class="pic-box">
                    <img src="'.$this->_tpl_vars['url_limage'].'" alt="'.$this->_tpl_vars['articlename'].'">
                    <div class="btns">
                        <div class="read">
                            <a href="'.$this->_tpl_vars['url_read'].'">点击阅读</a>
                        </div>

                        <div class="both">
							';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
                            <a href="javascript:;" onclick="showLoginLayer()">加入书架</a>
							';
}else{
echo '
							<a href="'.$this->_tpl_vars['jieqi_url'].'/addbookcase?bid='.$this->_tpl_vars['articleid'].'" class="addToBookcaseBtn" data-id="'.$this->_tpl_vars['articleid'].'">加入书架</a>
							';
}
echo '
                            <a href="javascript:;" onclick="showVoteBox(2)">打赏作品</a>
                        </div>

                        <div class="both outline">
							';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
                            <a href="javascript:;" onclick="showLoginLayer()">月票</a>
                            <a href="javascript:;" onclick="showLoginLayer()">推荐</a>
							';
}else{
echo '
							<a href="'.$this->_tpl_vars['jieqi_url'].'/vipvote?do=submit&num=1&action=post&id='.$this->_tpl_vars['articleid'].'">月票</a>
                            <a href="'.$this->_tpl_vars['url_uservote'].'">推荐</a>
							';
}
echo '
                        </div>
<!--					<div class="read">
							';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
							<a href="javascript:;" onclick="javascript:alert(\'登录后才可以下载哦！\');">全文下载</a>
							';
}else{
echo '
                            <a target="_blank" href="'.$this->_tpl_vars['article_static_url'].'/packdown.php?id='.$this->_tpl_vars['articleid'].'&type=txt&fname='.urlencode($this->_tpl_vars['articlename']).'">全文下载</a>
							';
}
echo '
                        </div>
-->
                    </div>
                </div>

                <div class="info">
                    <div class="tit">'.$this->_tpl_vars['articlename'].'</div>

                    <div class="detail-tab">
                        <div class="hd">
							';
if($this->_tpl_vars['issign'] == 'VIP签约'){
echo '
                            <span><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/qy.png" alt=""></span>
							';
}
echo '
                            <ul>
                                <li>内容介绍</li>
                                <li>作品信息</li>
                            </ul>
                        </div>
                        <div class="bd">
                            <div>'.htmlclickable($this->_tpl_vars['intro']).'</div>
                            <div>
                                <ul class="detail-info">
                                    <li>总点击：'.$this->_tpl_vars['articlevals']['allvisit'].'</li>
                                    <li>总人气：'.$this->_tpl_vars['articlevals']['allvipvote'].'</li>
                                    <li>总推荐：'.$this->_tpl_vars['articlevals']['allvote'].'</li>

                                    <li>月点击：'.$this->_tpl_vars['articlevals']['monthvisit'].'</li>
                                    <li>月人气：'.$this->_tpl_vars['articlevals']['monthvipvote'].'</li>
                                    <li>月推荐：'.$this->_tpl_vars['articlevals']['monthvote'].'</li>

                                    <li>周点击：'.$this->_tpl_vars['articlevals']['weekvisit'].'</li>
                                    <li>周人气：'.$this->_tpl_vars['articlevals']['weekvipvote'].'</li>
                                    <li>周推荐：'.$this->_tpl_vars['articlevals']['weekvote'].'</li>

                                    <li>总字数：'.$this->_tpl_vars['size_c'].'</li>
                                    <li>评论数：'.$this->_tpl_vars['reviewsnum'].'</li>
                                    <li>连载状态：'.$this->_tpl_vars['fullflag'].'</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="action">
                        《'.$this->_tpl_vars['articlename'].'》为'.$this->_tpl_vars['jieqi_sitename'].'作者“'.$this->_tpl_vars['author'].'”所着虚构作品，不涉及任何真实人物、事件等，请勿将杜撰作品与现实挂钩。
                    </div>

                    <div class="bdsharebuttonbox"><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间">QQ空间</a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博">新浪微博</a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信">微信</a><a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧">百度贴吧</a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友">QQ好友</a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"1","bdMiniList":["thx","mogujie","huaban","hx"],"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{"bdSize":16}};with(document)0[(getElementsByTagName(\'head\')[0]||body).appendChild(createElement(\'script\')).src=\'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=\'+~(-new Date()/36e5)];</script>

                </div>
            </div>

                        <div class="c15"></div>

            <div class="ftit">
                <i class="iconfont icon-star1"></i> 最新章节
            </div>
            <div class="c15"></div>
			';
if($this->_tpl_vars['isvip_n'] > 0 && $this->_tpl_vars['vipsize'] > 0){
echo '
            <div class="latest">
                <h3><a href="'.$this->_tpl_vars['url_vipchapter'].'">'.$this->_tpl_vars['vipchapter'].'</a><span style="color: red;">VIP</span><span>(更新时间：'.date('Y-m-d H:i:s',$this->_tpl_vars['lastupdate']).')</span></h3>
					'.$this->_tpl_vars['vipsummary'].'...
                　　<div>
                    <a href="'.$this->_tpl_vars['url_vipchapter'].'" class="active">阅读此章节</a>
                    <a href="'.$this->_tpl_vars['url_read'].'">目录</a>
                </div>
            </div>
			';
}else{
echo '
            <div class="latest">
                <h3><a href="'.$this->_tpl_vars['url_lastchapter'].'">'.$this->_tpl_vars['lastchapter'].'</a><span>(更新时间：'.date('Y-m-d H:i:s',$this->_tpl_vars['lastupdate']).')</span></h3>
                　　'.$this->_tpl_vars['lastsummary'].'...
                <div>
                    <a href="'.$this->_tpl_vars['url_lastchapter'].'" class="active">阅读此章节</a>
                    <a href="'.$this->_tpl_vars['url_read'].'">目录</a>
                </div>
            </div>
			';
}
echo '
            <div class="c15"></div>


            <div class="ftit">
                <i class="iconfont icon-iconfontduihua"></i> 互动中心
            </div>
            <div class="c15"></div>

            <div class="data-cell">
                <div class="tit">
                    <span><i class="iconfont c1 icon-yuepiao"></i> 本书月票</span>
                    <em>今日已投<i>'.$this->_tpl_vars['articlevals']['dayvipvote'].'</i>票</em>
                </div>

                <div class="dc">
                    <div class="dl">
                        <p>本月票数: <span>'.$this->_tpl_vars['articlevals']['monthvipvote'].'</span>票<!-- 排名: <span>38</span>名--></p>
                        <p>本周票数: <span>'.$this->_tpl_vars['articlevals']['weekvipvote'].'</span>票</p>
                    </div>
                    <div class="dr">
						';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
                        <a href="javascript:;" onclick="showLoginLayer()"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/btn2.png" alt=""></a>
						';
}else{
echo '
						<a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/vipvote.php?do=submit&num=1&action=post&id='.$this->_tpl_vars['articleid'].'"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/btn2.png" alt=""></a>
						';
}
echo '
                    </div>
                </div>
            </div>

            <div class="data-cell">
                <div class="tit">
                    <span><i class="iconfont c2 icon-dianzan"></i> 本书推荐票</span>
                    <em>今日已投<i>'.$this->_tpl_vars['articlevals']['dayvote'].'</i>票</em>
                </div>

                <div class="dc">
                    <div class="dl">
                        <p>本月票数: <span>'.$this->_tpl_vars['articlevals']['monthvote'].'</span>票</p>
                        <p>本周票数: <span>'.$this->_tpl_vars['articlevals']['weekvote'].'</span>票</p>
                    </div>
                    <div class="dr">
						';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
                        <a href="javascript:;" onclick="showLoginLayer()"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/btn2.png" alt=""></a>
						';
}else{
echo '
						<a href="'.$this->_tpl_vars['url_uservote'].'"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/btn2.png" alt=""></a>
						';
}
echo '
                    </div>
                </div>
            </div>
<!--
            <div class="data-cell">
                <div class="tit">
                    <span><i class="iconfont c3 icon-qiandai"></i> 打赏作品</span>
                    <em>今日<i>0</i>人打赏</em>
                </div>

                <div class="dc">
                    <div class="dl">
                        <p>本月打赏人数: <span>0</span>人</p>
                        <p>本周打赏人数: <span>0</span>人</p>
                    </div>
                    <div class="dr">
                        <a href="javascript:;" onclick="showVoteBox(2)"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/btn3.png" alt=""></a>
                    </div>
                </div>
            </div>
-->
            <div class="comments">
                <div class="tit">为该书点评</div>
                <form action="'.$this->_tpl_vars['jieqi_url'].'/doreviews?aid='.$this->_tpl_vars['articleid'].'" method="post" name="frmnewreviews" onsubmit="return CheckPost();" enctype="multipart/form-data">
                    <input type="hidden" name="parent_id" id="parentId">
                    <input type="text" name="ptitle" class="title" id="title" placeholder="评论标题">
                    <textarea name="pcontent" id="pcontent" placeholder=""></textarea>
                  <input type="text" size="8" style="border:#ccc solid 1px;background:#fff;float:left;display:block;margin-right:10px;height:20px;" maxlength="8" name="checkcode" title="点击显示验证码">
                  <img id="p_imgccode" src="'.$this->_tpl_vars['jieqi_url'].'/checkcode.php"  onclick="this.src=\''.$this->_tpl_vars['jieqi_url'].'/checkcode.php?rand=\'+Math.random();" title="点击刷新验证码">  			   
                  <div class="btns">
                        <span>温馨提示: 请文明发言</span>
						<input type="hidden" name="action" id="action" value="newpost" />
                        <input type="submit" name="submit"  value="评论">
                    </div>
                </form>

                <div class="comments-tab">
                    <div class="hd">
                        <span>系统已有<em>'.$this->_tpl_vars['reviewsnum'].'</em>条评论</span>
                        <ul><!--<li>热门评论</li>--><li>最新评论</li></ul>
                    </div>
                    <div class="bd">
                        <div class="comments-list-box">
                             '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'最新书评', 'module'=>'article', 'filename'=>'block_areviews', 'classname'=>'BlockArticleAreviews', 'side'=>'-1', 'title'=>'最新书评', 'vars'=>'5,0,0,id', 'template'=>'block_areviews.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
                            
                            <div class="loadmore">
                                <a href="'.$this->_tpl_vars['jieqi_url'].'/reviewsget?aid='.$this->_tpl_vars['articleid'].'" class="loadmore-btn">查看更多评论</a>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="right">
            <div class="rank-component">
                <div class="tit">
                    <span>作者信息</span>
                </div>
                <div class="content">
                    <div class="author-info">
'.jieqi_get_block(array('bid'=>'0', 'blockname'=>'关于作者', 'module'=>'system', 'filename'=>'block_uinfo', 'classname'=>'BlockSystemUinfo', 'side'=>'-1', 'title'=>'关于作者', 'vars'=>'$authorid', 'template'=>'block_style_info_uinfo.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'

                        <p>本书公告：';
if($this->_tpl_vars['notice'] != ""){
echo truncate(htmlclickable($this->_tpl_vars['notice']),'20').'……';
}else{
echo '本书尚无公告！';
}
echo '</p>
                    </div>
                </div>
            </div>
            <div class="c15"></div>

            <div class="rank-component">
                <div class="tit">
                    <span>作者其他作品</span>
<!--                    <a href="">更多 &gt;</a>-->
                </div>
                <div class="content">
                    <ul class="rank-ul">
'.jieqi_get_block(array('bid'=>'0', 'blockname'=>'作者作品', 'module'=>'article', 'filename'=>'block_uarticles', 'classname'=>'BlockArticleUarticles', 'side'=>'-1', 'title'=>'作者作品', 'vars'=>'lastupdate,3,0,$authorid', 'template'=>'block_style_info_uarticles.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).' 
                    </ul>
                </div>
            </div>

            <div class="c15"></div>
            <div class="rank-component">
                <div class="tit">
                    <span>热门作品</span>
                    <a href="'.$this->_tpl_vars['jieqi_url'].'/books">更多 &gt;</a>
                </div>
                <div class="content">
<!--                    <div class="rank-first">-->
<!--                        <div class="info">-->
<!--                            <span class="n1">NO.1</span>-->
<!--                            <div class="bt"><a href="">我是标题我是标题</a></div>-->
<!--                            <p><span>2931023</span>点击</p>-->
<!--                            <div class="author">作者</div>-->
<!--                        </div>-->
<!--                        <div class="pic">-->
<!--                            <a href="">-->
<!--                                <img src="picture/book.png" alt="">-->
<!--                            </a>-->
<!--                        </div>-->
<!--                    </div>-->
                    <ul class="rank-ul">
						'.jieqi_get_block(array('bid'=>'0', 'blockname'=>'点击榜', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>'-1', 'title'=>'点击榜', 'vars'=>'allvisit,10,0,0,0,0', 'template'=>'index_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
                    
                    </ul>
                </div>
            </div>

            <div class="c15"></div>

            <div class="rank-component people-recommended tuhao fensi-component">
                <div class="tit">
                    <span>粉丝榜</span>
<!--                    <a href="">更多 &gt;</a>-->
                </div>
                <div class="content">
                    <div class="rank-tab">

                        <div class="bd">
                            <ul>
							'.jieqi_get_block(array('bid'=>'0', 'blockname'=>'粉丝值排行榜', 'module'=>'article', 'filename'=>'block_credit', 'classname'=>'BlockArticleCredit', 'side'=>'-1', 'title'=>'粉丝值排行榜', 'vars'=>'point,10,0,id', 'template'=>'block_style_info_credit.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
							</ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--投票弹出层 S-->
<div class="vote-box">
    <div class="hd">
        <ul><li>打赏</li></ul>
        <span class="layui-layer-setwin"><a class="layui-layer-ico layui-layer-close layui-layer-close1" href="javascript:;"></a></span>
    </div>
    <div class="bd">
        <div>
            <div class="tit">这本书太棒了，犒劳一下，希望后续更加精彩！</div>
            <ul>
                <li data-num="100" class="active"><a href="javascript:;">100点</a></li>
                <li data-num="200"><a href="javascript:;">200点</a></li>
                <li data-num="500"><a href="javascript:;">500点</a></li>
                <li data-num="1000"><a href="javascript:;">1000点</a></li>
                <li data-num="2000"><a href="javascript:;">2000点</a></li>
                <li data-num="5000"><a href="javascript:;">5000点</a></li>
                <li data-num="10000"><a href="javascript:;">1万点</a></li>
                <li data-num="20000"><a href="javascript:;">2万点</a></li>
                <li data-num="50000"><a href="javascript:;">5万点</a></li>
            </ul>
            <p>本次打赏<span class="vnum">100</span>'.$this->_tpl_vars['egoldname'].'</p>
            <div class="btn">
                <input name="reward_num" class="vnumInput" type="hidden" value="100">
                <button type="button" data-type="reward">确认打赏</button>
            </div>
        </div>
    </div>
</div>
<!--投票弹出层 E-->

<script type="text/javascript">
    var isGuest = ';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo 'true';
}else{
echo 'false';
}
echo ';
    var commentP = 1;
    jQuery(".detail-tab").slide();
    jQuery(".comments-tab").slide();
    //打赏弹出层
    jQuery(".vote-box").slide({trigger:"click"});
    function showVoteBox(type){
        if(isGuest) {
            showLoginLayer();
            return false;
        }
        jQuery(".vote-box .hd ul li:eq("+type+")").trigger(\'click\');
        layer.open({
            type: 1,
            shadeClose: true, //开启遮罩关闭
            shade: 0.5,
            skin: \'book-layer-wrap\',
            closeBtn: 0,
            title: false,
            area: \'500px\',
            content: $(\'.vote-box\')
        });
    }
    $(".vote-box ul li").on(\'click\', function(){
        $(this).siblings().removeClass(\'active\');
        $(this).addClass(\'active\');
        $(this).parent().parent().find(".vnum").text($(this).attr("data-num"));
        $(this).parent().parent().find(".vnumInput").val($(this).attr("data-num"));
    });
    $(".vote-box .btn button").click(function () {
        var acttype = $(this).attr("data-type");
        var num = $(this).parent().find(".vnumInput").val();
		window.location.href="'.$this->_tpl_vars['jieqi_url'].'/tip?do=submit&action=post&id='.$this->_tpl_vars['articleid'].'&payegold="+num+"";
    });

    //评论回复
    $(".comments-list-box").on(\'click\', \'.reply-btn\', function () {
        $("#parentId").val($(this).attr(\'data-id\'));
        $("#title").val("回复：" + $(this).attr(\'data-name\'));
        window.scrollTo(0,1500);
        return false;
    });
</script>
    <div class="c15"></div>

<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
        '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
         </div>
    </div>
</div>

<div class="c15"></div>';
?>