<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'article';

?>