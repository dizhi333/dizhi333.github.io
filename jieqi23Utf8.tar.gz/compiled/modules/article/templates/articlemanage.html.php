<?php
echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>'.$this->_tpl_vars['articlename'].'章节管理-'.$this->_tpl_vars['jieqi_sitename'].'</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/bootstrap.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/theme.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/font-awesome.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/ionicons.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/_all-skins.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/blue.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/style.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article-create.css" rel="stylesheet">
<style type="text/css">
body,td,th {
	font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.chapter-management{width:100%;
font-size:15px;}
.chapter-management ul{padding:0;}
.chapter-management li{width:540px;
height:35px;
line-height:35px;
display:block;
float:left;
padding-left:30px;
font-weight:600;}
.chapter-management .bt{width:100%;
height:50px;
line-height:50px;
text-align:center;
padding-left:0;}
.chapter-management li a{margin-left:10px;}
.chapter-move{width:95%;
height:150px;
border-bottom:solid 2px #3c8dbc;
margin:auto;
font-weight:600;
text-align:center;}
.chapter-move .chapter-header{width:90%;
height:50px;
line-height:50px;
margin:0 auto;
font-size:18px;}
.chapter-header{width:90%;
height:50px;
line-height:50px;
font-weight:600;
margin:0 auto;
font-size:18px;
text-align:center;}
.chapter-move .button{margin-top:20px;}
.chapter-move #submit_sort{background:#3c8dbc;
color:#fff;}
</style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
'.$this->_tpl_vars['url_article'].'
    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="/" class="navbar-brand">'.$this->_tpl_vars['jieqi_sitename'].'&middot;<span>作家中心</span></a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li  class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/author">作品管理 <span class="sr-only">(current)</span></a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?id=3">申请签约</a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/mreport">作品收入</a></li>
						
                    </ul>
                </div>
                
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="'.$this->_tpl_vars['jieqi_url'].'/authornotice" class="dropdown">
                                <i class="fa fa-bell-o"></i>&nbsp;&nbsp;&nbsp;通知
                                                            </a>
                        </li>
                        <li class="dropdown user user-menu">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'" class="user-image" alt="'.$this->_tpl_vars['jieqi_username'].'">
                                <span class="hidden-xs">'.$this->_tpl_vars['jieqi_username'].'</span>
                            </a>
                                                        <ul class="dropdown-menu">
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php"><i class="fa fa-edit"></i>我的资料</a>
                                </li>
                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php" id="modifyPwdBtn"><i class="fa fa-lock"></i>更改密码</a>
                                </li>
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'"><i class="fa fa-sign-out"></i>退出登录</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="box box-default chapter">
    <div class="box-header with-border">
        <h3 class="box-title">《'.$this->_tpl_vars['articlename'].'》章节管理</h3>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/newchapter.php?aid='.$this->_tpl_vars['articleid'].'" class="btn btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> 新建章节</a>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/newvolume.php?aid='.$this->_tpl_vars['articleid'].'" id="createVolumeBtn" class="btn btn-sm btn-default pull-right margin-r-5">新建分卷</a>
    </div>
    <div class="box-body">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li><a href="/modules/article/articleget.php?id='.$this->_tpl_vars['articleid'].'">作品设置</a></li>
                <li class="active"><a href="/modules/article/articlemanage.php?id='.$this->_tpl_vars['articleid'].'">已发布章节</a></li>
				<li><a href="/modules/article/reviewsget?aid='.$this->_tpl_vars['articleid'].'">管理书评</a></li>
            </ul>
        </div>
		<div class="chapter-move">
                        <div class="chapter-header">
                            <span>章节排序</span>
                        </div>
						<form name="chaptersort" id="chaptersort" action="'.$this->_tpl_vars['url_chaptersort'].'" method="post">
                        <div class="chapter-body">
                            <div class="chapter-body-right">
                                <div class="chapter-body-right-header">  
                                    <span>选择章节或分卷</span>
                                    <select name="fromid" id="fromid">
									';
if (empty($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = array();
elseif (!is_array($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = (array)$this->_tpl_vars['chapterrows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['chapterrows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['chapterrows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['chapterrows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
                                    ';
if($this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptertype'] == 0){
echo '
                                    <option value="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chapterorder'].'">|-'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</option>
                                    ';
}else{
echo '
                                    <option value="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chapterorder'].'">'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</option>
                                    ';
}
echo '
                                    ';
}
echo '                                   
                     			   </select>
								   <span>移动到</span>
                                    <select name="toid" id="toid">
									<option value="0">--最前面--</option>
									';
if (empty($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = array();
elseif (!is_array($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = (array)$this->_tpl_vars['chapterrows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['chapterrows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['chapterrows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['chapterrows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
                                    ';
if($this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptertype'] == 0){
echo '
                                    <option value="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chapterorder'].'">|-'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</option>
                                    ';
}else{
echo '
                                    <option value="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chapterorder'].'">'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</option>
                                    ';
}
echo '
                                    ';
}
echo '                                 
                     			   </select>
								   <span>之后</span>
                                    <div class="button"><input type="submit" class="btn" name="submit_sort"  id="submit_sort" value="确定移动" /><input type="hidden" name="aid" id="aid" value="'.$this->_tpl_vars['articleid'].'" /><input type="hidden" name="act" value="sort" />'.$this->_tpl_vars['jieqi_token_input'].'</div>
                                </div>
                            </div>
                        </div>
						</form>
        </div>
			<div class="chapter-header">
                <span>章节目录</span>
            </div>
        <div class="chapter-management">
			<ul>
			';
if (empty($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = array();
elseif (!is_array($this->_tpl_vars['chapterrows'])) $this->_tpl_vars['chapterrows'] = (array)$this->_tpl_vars['chapterrows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['chapterrows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['chapterrows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['chapterrows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['chapterrows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
			';
if($this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptertype'] == 1){
echo '
			<li class="bt">'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'
			<a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chapteredit'].'">编辑分卷</a>
			<a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chapterdelete'].$this->_tpl_vars['jieqi_token_url'].'">删除分卷</a></li>
			';
}else{
echo '
				<li><i class="public-on">';
if($this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['isvip_n'] > 0){
echo '<font color="red">VIP</font>';
}else{
echo '免费';
}
echo '</i>
				<a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chapteredit'].'">'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['chaptername'].'</a>
				<a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chapterdelete'].$this->_tpl_vars['jieqi_token_url'].'">删除</a>
                <a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chapteredit'].'" style="margin-right:10px">修改</a>
				';
if($this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['isvip_n'] > 0){
echo '
				<a href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chaptersetfree'].$this->_tpl_vars['jieqi_token_url'].'" style="margin-right:10px" title="设为免费章节">免</a>
				';
}else{
echo '
				<a  href="'.$this->_tpl_vars['chapterrows'][$this->_tpl_vars['i']['key']]['url_chaptersetvip'].$this->_tpl_vars['jieqi_token_url'].'" style="margin-right:10px" title="设为VIP章节">VIP</a>
				';
}
echo '
				</li>
				';
}
echo '
			';
}
echo '
			<ul>
        </div>
    </div>
</div>
          </section>
        </div>
    </div>

    <footer class="main-footer">
        <div class="container">
            <div class="pull-right hidden-xs">
                Copyright &copy; '.date('Y',$this->_tpl_vars['jieqi_time']).' All Rights Reserved '.$this->_tpl_vars['jieqi_sitename'].' 版权所有
            </div>
        </div>
    </footer>
</div>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.activeForm.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/app.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.slimscroll.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/icheck.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/vue.js"></script>
<!--[if lt IE 9]>
<script src="/js/html5shiv.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">jQuery(document).ready(function () {

$(function() {

    $("#publishBtn").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
    $("#publishBtnLeft").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
});
;jQuery(\'#w0\').parent().datetimepicker({"autoclose":true,"format":"yyyy-mm-dd hh:ii:ss","todayBtn":true,"language":"zh-CN"});

});</script></body>
</html>
';
?>