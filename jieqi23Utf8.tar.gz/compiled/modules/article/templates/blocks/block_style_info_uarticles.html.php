<?php
if($this->_tpl_vars['ownerid'] > 0){
if (empty($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = array();
elseif (!is_array($this->_tpl_vars['articlerows'])) $this->_tpl_vars['articlerows'] = (array)$this->_tpl_vars['articlerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['articlerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['articlerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['articlerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['articlerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	if($this->_tpl_vars['i']['order'] == 1){
echo '
                <li>
                                        <span class="l0">'.$this->_tpl_vars['i']['order'].'</span>
                                        <a href="'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['url_articleinfo'].'">'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</a>
                    <em>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['allvisit'].'</em>
                </li>
';
}else{
if($this->_tpl_vars['i']['order'] == 2){
echo '
                <li>
                                        <span class="l1">'.$this->_tpl_vars['i']['order'].'</span>
                                        <a href="'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['url_articleinfo'].'">'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</a>
                    <em>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['allvisit'].'</em>
                </li>
';
}else{
if($this->_tpl_vars['i']['order'] == 3){
echo '
                <li>
                                        <span class="l2">'.$this->_tpl_vars['i']['order'].'</span>
                                        <a href="'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['url_articleinfo'].'">'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</a>
                    <em>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['allvisit'].'</em>
                </li>
';
}else{
echo '
                <li>
                                        <span>'.$this->_tpl_vars['i']['order'].'</span>
                                        <a href="'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['url_articleinfo'].'">'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['articlename'].'</a>
                    <em>'.$this->_tpl_vars['articlerows'][$this->_tpl_vars['i']['key']]['allvisit'].'</em>
                </li>
';
}
}
}
}
echo ' 
';
}else{
echo '
                <li>
                                        <span class="l0"></span>
                                        <a href="#">暂无信息</a>
                    
                </li>
';
}

?>