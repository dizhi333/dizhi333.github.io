<?php

if (empty($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = array();
}
else if (!is_array($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = (array) $this->_tpl_vars["articlerows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["articlerows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["articlerows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["articlerows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n                            <li>\r\n\r\n                                <span>" . $this->_tpl_vars["i"]["order"] . "</span>\r\n\r\n                                <a href=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["url_articleinfo"] . "\" class=\"tit\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</a>\r\n\r\n                                <a href=\"javascript:;\" class=\"author\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["author"] . "</a>\r\n\r\n                            </li>\r\n";
}

?>
