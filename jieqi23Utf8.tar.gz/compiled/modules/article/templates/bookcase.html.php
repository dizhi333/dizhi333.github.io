<?php

echo "\r\n<div class=\"nav wrap\">\r\n    <div class=\"dropdown\">\r\n        <div class=\"btn\">\r\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\r\n</div>\r\n<div class=\"dropdown-items \">\r\n    ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \r\n</div>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n<div class=\"position wrap\">\r\n    <span>您的位置: </span>\r\n    <a href=\"\">官网首页</a>\r\n    <span>></span>\r\n    <a class=\"active\" href=\"\">个人中心</a>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n\r\n\r\n<div class=\"wrap\">\r\n    <div class=\"customer-wrap\">\r\n\r\n        <div class=\"menu\">\r\n    <div class=\"intro\">\r\n        <div class=\"avatar\">\r\n            <img src=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\" alt=\"" . $this->_tpl_vars["jieqi_username"] . "\" onerror=\"this.src='" . jieqi_geturl("system", "avatar", $this->_tpl_vars["jieqi_userid"], "s") . "'\" />\r\n        </div>\r\n        <p>" . $this->_tpl_vars["name"] . "</p>\r\n\t\t<div class=\"icon\">\r\n            <a href=\"\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/images/level/" . $this->_tpl_vars["jieqi_group"] . ".png\" alt=\"\"></a>\r\n        </div>\r\n\r\n        <div class=\"c15\"></div>\r\n        <a href=\"\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/images/line0.png\" alt=\"\"></a>\r\n    </div>\r\n    <div class=\"acts\">\r\n        ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/usernav.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \r\n    </div>\r\n\r\n    <div class=\"btns\">\r\n                    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/images/sign.png\" alt=\"\"></a>\r\n        <!--        <a href=\"\"><img src=\"/images/service.png\" alt=\"\"></a>-->\r\n    </div>\r\n</div>\r\n        <div class=\"content\">\r\n            <div class=\"actions\">\r\n                <ul>\r\n                    <li class=\"active\"><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/useraccount.php\">账户信息</a></li>\r\n\t\t\t\t\t<li><span>|</span></li>\r\n                    <li ><a href=\"" . $this->_tpl_vars["jieqi_modules"]["pay"]["url"] . "/paylog.php\">充值记录</a></li>\r\n\t\t\t\t\t<li><span>|</span></li>\r\n                    <li ><a href=\"" . $this->_tpl_vars["jieqi_modules"]["obook"]["url"] . "/buylist.php\">订阅记录</a></li>\r\n\t\t\t\t\t<li><span>|</span></li>\r\n                    <li ><a href=\"" . $this->_tpl_vars["jieqi_modules"]["pay"]["url"] . "/buyegold.php\">在线充值</a></li>\r\n                </ul>\r\n            </div>\r\n\r\n            <div class=\"c15\"></div>\r\n\r\n<div class=\"customer-bookshelf\">\r\n                <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                    <thead>\r\n                    <th>作品</th>\r\n                    <th>章节</th>\r\n                    <th>最近更新</th>\r\n<!--                    <th>阅读进度</th>-->\r\n                    <th>作者</th>\r\n                    <th>阅读状态</th>\r\n                    <th>操作</th>\r\n                    </thead>\r\n                    <tbody>\r\n\t\t\t\t\t";

if (empty($this->_tpl_vars["bookcaserows"])) {
	$this->_tpl_vars["bookcaserows"] = array();
}
else if (!is_array($this->_tpl_vars["bookcaserows"])) {
	$this->_tpl_vars["bookcaserows"] = (array) $this->_tpl_vars["bookcaserows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["bookcaserows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["bookcaserows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["bookcaserows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["bookcaserows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["bookcaserows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n                        <tr>\r\n                        <td class=\"type\">\r\n\t\t\t\t\t\t<a href=\"" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["url_articleinfo"] . "\">" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</a>\r\n\t\t\t\t\t\t</td>\r\n                        <td class=\"book\">\r\n                            \r\n\t\t\t\t\t\t\t";

	if ($this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["freetime"] < $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["viptime"]) {
		echo "\r\n                            <a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/readbookcase.php?bid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["caseid"] . "&aid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "&cid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["vipchapterid"] . "\" class=\"chapter\">" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["vipchapter"] . "</a>\r\n\t\t\t\t\t\t\t";
	}
	else {
		echo "\r\n\t\t\t\t\t\t\t<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/readbookcase.php?bid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["caseid"] . "&aid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "&cid=" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["lastchapterid"] . "\" class=\"chapter\">" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["lastchapter"] . "</a>\r\n\t\t\t\t\t\t\t";
	}

	echo "\r\n                        </td>\r\n                        <td class=\"date\">" . date("Y-m-d", $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["lastupdate"]) . "</td>\r\n<!--                        <td class=\"progress\">-->\r\n<!--                            <a href=\"\">有更新</a>-->\r\n<!--                        </td>-->\r\n                        <td class=\"author\">\r\n                            " . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["author"] . "\r\n\t\t\t\t\t\t</td>\r\n                        <td class=\"status\">\r\n                            ";

	if ($this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["hasnew"] == 1) {
		echo "<span style=\"color:#f10;\">有新章节</span>";
	}
	else {
		echo "已阅读完";
	}

	echo "\r\n\t\t\t\t\t\t</td>\r\n                        <td>\r\n                            <a href=\"" . $this->_tpl_vars["bookcaserows"][$this->_tpl_vars["i"]["key"]]["url_delete"] . "\">删除</a>\r\n<!--                            <a href=\"\">置顶</a>-->\r\n                        </td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t";
}

echo "\r\n                    </tbody>\r\n                </table>\r\n                \r\n            </div>\r\n\r\n \r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n    <div class=\"c15\"></div>\r\n<div class=\"notice flink wrap\">\r\n    <div class=\"channel-box\">\r\n        <div class=\"tit\">\r\n            <span>友情链接</span>\r\n        </div>\r\n        <div class=\"content\">\r\n            " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n";

?>
