<?php

echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n<html lang=\"zh-CN\">\n\n<head>\n<meta charset=\"" . $this->_tpl_vars["jieqi_charset"] . "\" />\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"format-detection\" content=\"telephone=no, email=no\"/>\n<meta name=\"csrf-param\" content=\"_csrf-frontend\">\n<title>" . $this->_tpl_vars["articlename"] . "-" . $this->_tpl_vars["sort"] . "-" . $this->_tpl_vars["jieqi_sitename"] . "</title>\n<meta name=\"keywords\" content=\"" . $this->_tpl_vars["meta_keywords"] . "\" />\n<meta name=\"description\" content=\"" . truncate($this->_tpl_vars["intro"], "500", "..") . "\" />\n<meta property=\"og:type\" content=\"novel\"/>\n<meta property=\"og:title\" content=\"" . $this->_tpl_vars["article_title"] . "\"/>\n<meta property=\"og:description\" content=\"" . htmlclickable($this->_tpl_vars["intro"]) . "\"/>\n<meta property=\"og:image\" content=\"" . $this->_tpl_vars["url_limage"] . "\"/>\n<meta property=\"og:novel:category\" content=\"" . $this->_tpl_vars["sortname"] . "\"/>\n<meta property=\"og:novel:author\" content=\"" . $this->_tpl_vars["author"] . "\"/>\n<meta property=\"og:novel:book_name\" content=\"" . $this->_tpl_vars["article_title"] . "\"/>\n<meta property=\"og:novel:read_url\" content=\"" . $this->_tpl_vars["jieqi_url"] . "/modules/article/articleread.php?id=" . $this->_tpl_vars["articleid"] . "\"/>\n<meta property=\"og:url\" content=\"" . $this->_tpl_vars["url_articleinfo"] . "\"/>\n<meta property=\"og:novel:status\" content=\"" . $this->_tpl_vars["fullflag"] . "\"/>\n<meta property=\"og:novel:update_time\" content=\"" . date("Y-m-d", $this->_tpl_vars["lastupdate"]) . "\"/>\n<meta property=\"og:novel:latest_chapter_name\" content=\"";
if ((0 < $this->_tpl_vars["isvip_n"]) && (0 < $this->_tpl_vars["vipsize"])) {
	echo $this->_tpl_vars["vipchapter"];
}
else {
	echo $this->_tpl_vars["lastchapter"];
}

echo "\"/>\n<meta property=\"og:novel:latest_chapter_url\" content=\"";
if ((0 < $this->_tpl_vars["isvip_n"]) && (0 < $this->_tpl_vars["vipsize"])) {
	echo $this->_tpl_vars["url_vipchapter"];
}
else {
	echo $this->_tpl_vars["url_lastchapter"];
}

echo "\"/>\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/font_v3wvvvmymuprdx6r.css\" rel=\"stylesheet\">\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/main.css\" rel=\"stylesheet\">\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/customer.css\" rel=\"stylesheet\">\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery-1.9.1.min.js\"></script>\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/layer.min.js\"></script>\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery.superslide.2.1.js\"></script>\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/main.js\"></script>\n</head>\n\n<body class=\"\" >\n<div class=\"header nav-hide\">\n    <div class=\"top\">\n        <div class=\"wrap\">\n            <div class=\"welcome\">欢迎访问" . $this->_tpl_vars["jieqi_sitename"] . "！</div>\n            <ul class=\"top-menu\">\n\t\t\t\t";

if ($this->_tpl_vars["jieqi_userid"] == 0) {
	echo "\n                <li style=\"margin-right: 15px;\">\n                    <a href=\"javascript:;\" onclick=\"showLoginLayer()\">登录</a>\n                    |\n                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/register.php\">注册</a>\n                </li>\n\t\t\t\t";
}
else {
	echo "\n\t\t\t\t<li class=\"dropdown\">\n                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\">\n                        " . $this->_tpl_vars["jieqi_username"] . "\n\t\t\t\t\t\t<i class=\"iconfont icon-xiala\"></i>\n                    </a>\n                    <div class=\"sub\">\n\t\t\t\t\t\t";

	if ($this->_tpl_vars["jieqi_group"] == 2) {
		echo "\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/myarticle.php\">管理中心</a></p>\n\t\t\t\t\t\t";
	}
	else if (5 < $this->_tpl_vars["jieqi_group"]) {
		echo "\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/myarticle.php\">作者专区</a></p>\n\t\t\t\t\t\t";
	}
	else {
		echo "\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/applywriter.php\">申请作者</a></p>\n\t\t\t\t\t\t";
	}

	echo "\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\">个人中心</a></p>\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/bookcase.php\">我的书架</a></p>\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_user_url"] . "/logout.php?jumpurl=" . urlencode($this->_tpl_vars["jieqi_thisurl"]) . "\">退出登录</a></p>\n                    </div>\n                </li>\n\t\t\t\t";
}

echo "\n                <li>\n                    <a href=\"" . $this->_tpl_vars["jieqi_modules"]["pay"]["url"] . "/buyegold.php\">\n                        <i class=\"iconfont icon-jinbi\"></i> 充值\n                    </a>\n                </li>\n            </ul>\n        </div>\n    </div>\n        <div class=\"mid wrap\">\n    <div class=\"logo\">\n        <a href=\"/\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/logo.png\" alt=\"" . $this->_tpl_vars["jieqi_sitename"] . "\"></a>\n    </div>\n    <div class=\"search\">\n        <div class=\"search-form\">\n            <form id=\"search-form\" action=\"" . $this->_tpl_vars["jieqi_url"] . "/search\" method=\"get\" role=\"form\">\n\t\t\t<input type=\"text\" name=\"searchtype\" value=\"all\" style=\"display:none;\">\n            <input type=\"text\" name=\"searchkey\" placeholder=\"请输入书名或作者名\" value=\"\">\n            <button type=\"submit\">\n                <i class=\"iconfont icon-sousuo-sousuo\"></i>\n            </button>\n            </form>        </div>\n        <div class=\"search-hot\">\n                           " . jieqi_get_block(array("bid" => "0", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "0", "title" => "区块", "vars" => "allvote,5,0,0,0,0", "template" => "block_so.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n                    </div>\n        <script>\n            $(\"#search-form\").submit(function () {\n                if($(\"input[name='searchkey']\").val() == '' || $(\"input[name='searchkey']\").val() == '请输入书名或作者名'){\n                    layer.msg('请输入关键字');\n                    return false;\n                }\n            });\n        </script>\n    </div>\n    <div class=\"btn\">\n        <a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/bookcase.php\">\n            <i class=\"iconfont icon-book\"></i> 我的书架\n        </a>\n    </div>\n</div>\n\n<div class=\"nav wrap\">\n    <div class=\"dropdown\">\n        <div class=\"btn\">\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\n</div>\n<div class=\"dropdown-items \">\n    ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \n</div>\n</div>\n\n<div class=\"wrap\">\n    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/666.jpg\" alt=\"\"></a>\n</div>\n\n<div class=\"c15\"></div>\n<div class=\"position wrap\">\n    <span>您的位置: </span>\n    <a href=\"/\">官网首页</a>\n    <span>></span>\n    <a href=\"/books\">书库</a>\n    <span>></span>\n    <a class=\"active\" href=\"" . $this->_tpl_vars["url_articleinfo"] . "\">" . $this->_tpl_vars["article_title"] . " </a>\n</div>\n\n<div class=\"c15\"></div>\n\n\n\n<div class=\"wrap\">\n    <div class=\"directory-box\">\n        <div class=\"book-tit\">\n            " . $this->_tpl_vars["article_title"] . "        </div>\n        <div class=\"author\">\n            作者: " . $this->_tpl_vars["author"] . "        </div>\n\n        <div class=\"btns\">\n<!--            <a href=\"#\"><i class=\"iconfont icon-add\"></i> 收藏</a>-->\n<!--            <a href=\"#\"><i class=\"iconfont icon-shuqian\"></i> 书签</a>-->\n<!--            <a href=\"#\"><i class=\"iconfont icon-fenxiang\"></i> 分享</a>-->\n            <a href=\"/\"><i class=\"iconfont icon-fanhui1\"></i> 返回首页</a>\n        </div>\n        <div class=\"c15\"></div>\n\n                <div class=\"directory-cell\">\n\t\t\t";

if (empty($this->_tpl_vars["chapterrows"])) {
	$this->_tpl_vars["chapterrows"] = array();
}
else if (!is_array($this->_tpl_vars["chapterrows"])) {
	$this->_tpl_vars["chapterrows"] = (array) $this->_tpl_vars["chapterrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["chapterrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["chapterrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["chapterrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["chapterrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["chapterrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\n\t\t\t";

	if (($this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptertype"] == 0) & ($this->_tpl_vars["i"]["order"] == 1)) {
		echo "\n\t\t\t<div class=\"cell-tit\">\n                <div>正文</div>\n<!--                <span>以更新1章</span>-->\n                <a href=\"javascript:;\" class=\"toggle\">- 收起</a>\n            </div>\n\t\t\t<div class=\"cell-items\">\n                <ul>\n\t\t\t";
	}

	echo "\n\t\t\t";

	if ((0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptertype"]) & ($this->_tpl_vars["i"]["order"] == 1)) {
		echo "\n\t\t\t<div class=\"cell-tit\">\n                <div>" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</div>\n<!--                <span>以更新1章</span>-->\n                <a href=\"javascript:;\" class=\"toggle\">- 收起</a>\n            </div>\n\t\t\t<div class=\"cell-items\">\n                <ul>\n\t\t\t";
	}

	echo "\n\t\t\t";

	if ((0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptertype"]) & (1 < $this->_tpl_vars["i"]["order"])) {
		echo "\n\t\t\t\t</ul>\n\t\t\t</div>\n            <div class=\"cell-tit\">\n                <div>" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</div>\n<!--                <span>以更新1章</span>-->\n                <a href=\"javascript:;\" class=\"toggle\">- 收起</a>\n            </div>\n\t\t\t<div class=\"cell-items\">\n                <ul>\n\t\t\t";
	}
	else {
		echo "\n\t\t\t\t\t\n\t\t\t\t\t";

		if ((0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptertype"]) & ($this->_tpl_vars["i"]["order"] == 1)) {
			echo "\n\t\t\t\t\t";
		}
		else {
			echo "\n                    <li><p>";

			if (0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["isvip"]) {
				echo "<span>VIP</span>";
			}

			echo " \n\t\t\t\t\t<a href=\"" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["url_chapter"] . "\">" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</a>\n\t\t\t\t\t</p></li>\n\t\t\t\t\t";
		}

		echo "\n\t\t\t";
	}

	echo "\n\t\t\t";
}

echo "\n\t\t\t\t\t</ul>\n\t\t\t</div>\n        </div>\n        \n        <div class=\"c15\"></div>\n        <div class=\"btns\">\n<!--            <a href=\"#\"><i class=\"iconfont icon-add\"></i> 收藏</a>-->\n<!--            <a href=\"#\"><i class=\"iconfont icon-shuqian\"></i> 书签</a>-->\n<!--            <a href=\"#\"><i class=\"iconfont icon-fenxiang\"></i> 分享</a>-->\n            <a href=\"/\"><i class=\"iconfont icon-fanhui1\"></i> 返回首页</a>\n        </div>\n        <div class=\"c15\"></div>\n    </div>\n</div>\n\n    <div class=\"c15\"></div>\n\n<div class=\"notice flink wrap\">\n    <div class=\"channel-box\">\n        <div class=\"tit\">\n            <span>友情链接</span>\n        </div>\n        <div class=\"content\">\n        " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n         </div>\n    </div>\n</div>\n\n<div class=\"c15\"></div>\n\n<div class=\"footer\">\n\n    <div class=\"menu\">\n        <a href=\"#\">关于我们</a>\n        <span>|</span>\n        <a href=\"#\">商务合作</a>\n        <span>|</span>\n        <a href=\"#\">用户守则</a>\n        <span>|</span>\n        <a href=\"#\">联系我们</a>\n    </div>\n    <p>Copyright  2016-2017 www.qiyue.com All Rights Reserved \n\t<br/>根本就不存在的文化有限责任公司</p>\n    <div class=\"c15\"></div>\n    <div class=\"c15\"></div>\n    <p>\n\t\t<div style=\"width:300px;margin:0 auto; padding:20px 0;\">\n        <a href=\"http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=50010702501680\">\n        <img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/beian.png\" alt=\"\">\n        </a>\n                <a target=\"_blank\" href=\"http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=50010702501680\" style=\"display:inline-block;text-decoration:none;height:20px;line-height:20px;\"><img style=\"float:left;\"/><p style=\"float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;\">公网安备 000000000000号</p></a>\n        </div>\n    </p>\n</div>\n<div class=\"fix-menu\">\n    <div class=\"item\">\n        <a class=\"pic\" href=\"javascript:;\"><i class=\"iconfont icon-erweima\"></i></a>\n        <div class=\"sub\">\n            <img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/qr.png\" alt=\"\">\n\t\t\t<div style=\"text-align:center;color: red\">扫描上方二维码<br>看更多免费小说</div>\n        </div>\n    </div>\n\n    <div class=\"item\">\n        <a class=\"pic\" href=\"http://wpa.qq.com/msgrd?v=3&uin=1378283361&site=qq&menu=yes\" target=\"_blank\"><i class=\"iconfont icon-2\"></i></a>\n    </div>\n\n    <div class=\"item\">\n        <a class=\"pic\" href=\"javascript:;\" onclick=\"goTop()\"><i class=\"iconfont icon-back-top\"></i></a>\n    </div>\n</div>\n";

if ($this->_tpl_vars["jieqi_userid"] == 0) {
	echo "\n<div class=\"login-layer\">\n    <form id=\"login-form\" action=\"" . $this->_tpl_vars["jieqi_user_url"] . "/login.php?do=submit\" method=\"post\" role=\"form\">\n        <div class=\"login-cell\">\n            <i class=\"iconfont icon-yonghu\"></i>\n            <input type=\"text\" placeholder=\"输入用户名\" name=\"username\">\n        </div>\n\n        <div class=\"login-cell\">\n            <i class=\"iconfont icon-Password\"></i>\n            <input type=\"password\" placeholder=\"输入密码\" name=\"password\">\n        </div>\n\n        <div class=\"btns\">\n<!--            <p>-->\n<!--                <input type=\"checkbox\" id=\"auto-login\" name=\"\" value=\"\">-->\n<!--                <label for=\"auto-login\">自动登录</label>-->\n<!--            </p>-->\n\n            <div>\n<!--                <a href=\"/site/resetpwd\">忘记密码</a>\n                |-->\n\t\t\t\t\n                <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/register.php\">免费注册</a>\n            </div>\n        </div>\n\t\t<input type=\"hidden\" name=\"action\" value=\"login\">\n        <input type=\"submit\" class=\"btn-ok\" value=\"登 录\">\n\n        <p class=\"more\"><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/login.php\">更多登录方式</a></p>\n\n        <!--密码找回提示S-->\n        <p class=\"more\"><a href=\"#\" style=\"font-size: 14px;color:#ff0000\">无法登陆？请看这里></a></p>\n        <!--密码找回提示E-->\n\n    </form>\n</div>\n";
}

echo "\n\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.js\"></script>\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.activeform.js\"></script>\n<script type=\"text/javascript\">jQuery(document).ready(function () {\njQuery('#login-form').yiiActiveForm([], []);\n});</script></body>\n<script type=\"text/javascript\">\n    $(\".need-login\").click(function () {\n        showLoginLayer();\n        return false;\n    });\n</script>\n</html>\n";

?>
