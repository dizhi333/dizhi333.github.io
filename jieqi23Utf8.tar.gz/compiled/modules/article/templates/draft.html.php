<?php

echo "\r\n<div class=\"novel-home-body-container\" >\r\n    <div class=\"container container-box-shadow\" style=\"margin-bottom:48px;\">\r\n        <div class=\"clearfix\">\r\n                        <div class=\"novel-left-menu\">\r\n                <div class=\"menu-header\">作者中心</div>\r\n                <ul>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/myarticle.php\">作家首页</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_static_url"] . "/newarticle.php\">新建作品</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/masterpage.php\">管理作品</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/apply.php?id=3\">申请上架</a></li>\r\n                    ";

if (0 < $this->_tpl_vars["jieqi_modules"]["obook"]["publish"]) {
	echo "\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["jieqi_modules"]["obook"]["url"] . "/mreport.php\">收入管理</a></li>\r\n                    ";
}

echo "\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/newdraft.php\">新建草稿</a></li>\r\n                    <li class=\"on\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/draft.php\">管理草稿</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/persondetail.php\">作者实名信息</a></li>\r\n                </ul>\r\n            </div>\r\n            <div class=\"novel-right\">\r\n              <div class=\"user-my-write-book right-header pos-rel\">\r\n                管理草稿\r\n\t\t\t\t<div class=\"user-message-list-header clearfix js-message-list\">\r\n                   <a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/draft.php?type=3\" class=\"book-header-right ";

if ($this->_tpl_vars["_request"]["type"] == 3) {
	echo "on";
}

echo "\">待审章节</a><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/draft.php?type=2\" class=\"book-header-right ";

if ($this->_tpl_vars["_request"]["type"] == 2) {
	echo "on";
}

echo "\">定时章节</a><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/draft.php?type=1\" class=\"book-header-right ";

if ($this->_tpl_vars["_request"]["type"] == 1) {
	echo "on";
}

echo "\">私人草稿</a><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/draft.php\" class=\"book-header-right ";

if ($this->_tpl_vars["_request"]["type"] == 0) {
	echo "on";
}

echo "\">全部草稿</a>\r\n                </div>\r\n              </div>\r\n                    <div class=\"right-record\" id=\"shenqing1\">\r\n                        <table class=\"record-table\">\r\n                            <tr>\r\n                                <th style=\"padding-left: 35px;\">作品</th>\r\n                                <th style=\"\">章节标题</th>\r\n                                <th style=\"\">定时发表</th>\r\n                                <th style=\"\">草稿类型</th>\r\n                                <th style=\"\">操作</th>\r\n                            </tr>\r\n\t\t\t\t\t\t\t";

if (empty($this->_tpl_vars["draftrows"])) {
	$this->_tpl_vars["draftrows"] = array();
}
else if (!is_array($this->_tpl_vars["draftrows"])) {
	$this->_tpl_vars["draftrows"] = (array) $this->_tpl_vars["draftrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["draftrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["draftrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["draftrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["draftrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["draftrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n                            <tr>\r\n                                <td style=\"padding-left: 20px;\"><a href=\"" . jieqi_geturl("article", "article", $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["articleid"], "info") . "\" target=\"_blank\">《" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "》</a></td>\r\n                                <td style=\"padding-left: 10px;\"><a href=\"" . $this->_tpl_vars["article_static_url"] . "/draftedit.php?id=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["draftid"] . "\">" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</a></td>\r\n                                <td style=\"padding-left: 10px;\">";

	if (0 < $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["pubdate"]) {
		echo date("m-d H:i", $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["pubdate"]);
	}
	else {
		echo "----------";
	}

	echo "</td>\r\n                                <td style=\"padding-left: 10px;\">";

	if ($this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["isvip_n"] == 1) {
		echo "电子书";
	}
	else {
		echo "公众小说";
	}

	echo "</td>\r\n                                <td style=\"\"><a href=\"" . $this->_tpl_vars["article_static_url"] . "/draftedit.php?id=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["draftid"] . "\">编辑</a> <a href=\"javascript:if(confirm('确实要删除该章节么？')) document.location='" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["url_delete"] . "';\">删除</a> ";

	if ($this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["display_n"] == 1) {
		echo "待审";
	}
	else {
		echo " <a href=\"";

		if ($this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["isvip_n"] == 1) {
			echo $this->_tpl_vars["article_static_url"] . "/newchapter.php?aid=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "&draftid=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["draftid"];
		}
		else {
			echo $this->_tpl_vars["article_static_url"] . "/newchapter.php?aid=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "&draftid=" . $this->_tpl_vars["draftrows"][$this->_tpl_vars["i"]["key"]]["draftid"];
		}

		echo "\">发表</a>";
	}

	echo "</td>\r\n                            </tr>\r\n                            ";
}

echo "\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t</table><br />\r\n\t\t\t\t\t\t\t<div class=\"paging\">" . $this->_tpl_vars["url_jumppage"] . "</div>\r\n                    </div>\r\n\t\t\t\t\t\r\n                </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n";

?>
