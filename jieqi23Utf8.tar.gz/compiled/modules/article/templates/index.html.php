<?php

echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n<html lang=\"zh-CN\">\r\n\r\n<head>\r\n<meta charset=\"" . $this->_tpl_vars["jieqi_charset"] . "\" />\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n<meta name=\"format-detection\" content=\"telephone=no, email=no\"/>\r\n<meta name=\"csrf-param\" content=\"_csrf-frontend\">\r\n<title>" . $this->_tpl_vars["articlename"] . "-" . $this->_tpl_vars["sort"] . "-" . $this->_tpl_vars["jieqi_sitename"] . "</title>\r\n<meta name=\"keywords\" content=\"" . $this->_tpl_vars["meta_keywords"] . "\" />\r\n<meta name=\"description\" content=\"" . truncate($this->_tpl_vars["intro"], "500", "..") . "\" />\r\n<meta property=\"og:type\" content=\"novel\"/>\r\n<meta property=\"og:title\" content=\"" . $this->_tpl_vars["article_title"] . "\"/>\r\n<meta property=\"og:description\" content=\"" . htmlclickable($this->_tpl_vars["intro"]) . "\"/>\r\n<meta property=\"og:image\" content=\"" . $this->_tpl_vars["url_limage"] . "\"/>\r\n<meta property=\"og:novel:category\" content=\"" . $this->_tpl_vars["sortname"] . "\"/>\r\n<meta property=\"og:novel:author\" content=\"" . $this->_tpl_vars["author"] . "\"/>\r\n<meta property=\"og:novel:book_name\" content=\"" . $this->_tpl_vars["article_title"] . "\"/>\r\n<meta property=\"og:novel:read_url\" content=\"" . $this->_tpl_vars["jieqi_url"] . "/modules/article/articleread.php?id=" . $this->_tpl_vars["articleid"] . "\"/>\r\n<meta property=\"og:url\" content=\"" . $this->_tpl_vars["url_articleinfo"] . "\"/>\r\n<meta property=\"og:novel:status\" content=\"" . $this->_tpl_vars["fullflag"] . "\"/>\r\n<meta property=\"og:novel:update_time\" content=\"" . date("Y-m-d", $this->_tpl_vars["lastupdate"]) . "\"/>\r\n<meta property=\"og:novel:latest_chapter_name\" content=\"";
if ((0 < $this->_tpl_vars["isvip_n"]) && (0 < $this->_tpl_vars["vipsize"])) {
	echo $this->_tpl_vars["vipchapter"];
}
else {
	echo $this->_tpl_vars["lastchapter"];
}

echo "\"/>\r\n<meta property=\"og:novel:latest_chapter_url\" content=\"";
if ((0 < $this->_tpl_vars["isvip_n"]) && (0 < $this->_tpl_vars["vipsize"])) {
	echo $this->_tpl_vars["url_vipchapter"];
}
else {
	echo $this->_tpl_vars["lastchapter"];
}

echo "\"/>\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/font_v3wvvvmymuprdx6r.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/main.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/customer.css\" rel=\"stylesheet\">\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery-1.9.1.min.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/layer.min.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery.superslide.2.1.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/main.js\"></script>\r\n</head>\r\n\r\n<body class=\"\" >\r\n<div class=\"header nav-hide\">\r\n    <div class=\"top\">\r\n        <div class=\"wrap\">\r\n            <div class=\"welcome\">欢迎访问" . $this->_tpl_vars["jieqi_sitename"] . "！</div>\r\n            <ul class=\"top-menu\">\r\n\t\t\t\t";

if ($this->_tpl_vars["jieqi_userid"] == 0) {
	echo "\r\n                <li style=\"margin-right: 15px;\">\r\n                    <a href=\"javascript:;\" onclick=\"showLoginLayer()\">登录</a>\r\n                    |\r\n                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/register.php\">注册</a>\r\n                </li>\r\n\t\t\t\t";
}
else {
	echo "\r\n\t\t\t\t<li class=\"dropdown\">\r\n                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\">\r\n                        " . $this->_tpl_vars["jieqi_username"] . "\r\n\t\t\t\t\t\t<i class=\"iconfont icon-xiala\"></i>\r\n                    </a>\r\n                    <div class=\"sub\">\r\n\t\t\t\t\t\t";

	if ($this->_tpl_vars["jieqi_group"] == 2) {
		echo "\r\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/myarticle.php\">管理中心</a></p>\r\n\t\t\t\t\t\t";
	}
	else if (5 < $this->_tpl_vars["jieqi_group"]) {
		echo "\r\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/myarticle.php\">作者专区</a></p>\r\n\t\t\t\t\t\t";
	}
	else {
		echo "\r\n\t\t\t\t\t\t<p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/applywriter.php\">申请作者</a></p>\r\n\t\t\t\t\t\t";
	}

	echo "\r\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\">个人中心</a></p>\r\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/bookcase.php\">我的书架</a></p>\r\n                        <p><a href=\"" . $this->_tpl_vars["jieqi_user_url"] . "/logout.php?jumpurl=" . urlencode($this->_tpl_vars["jieqi_thisurl"]) . "\">退出登录</a></p>\r\n                    </div>\r\n                </li>\r\n\t\t\t\t";
}

echo "\r\n                <li>\r\n                    <a href=\"/account/recharge\">\r\n                        <i class=\"iconfont icon-jinbi\"></i> 充值\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n        <div class=\"mid wrap\">\r\n    <div class=\"logo\">\r\n        <a href=\"/\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/logo.png\" alt=\"" . $this->_tpl_vars["jieqi_sitename"] . "\"></a>\r\n    </div>\r\n    <div class=\"search\">\r\n        <div class=\"search-form\">\r\n            <form id=\"search-form\" action=\"" . $this->_tpl_vars["jieqi_url"] . "/search\" method=\"get\" role=\"form\">\r\n\t\t\t<input type=\"text\" name=\"searchtype\" value=\"all\" style=\"display:none;\">\r\n            <input type=\"text\" name=\"searchkey\" placeholder=\"请输入书名或作者名\" value=\"\">\r\n            <button type=\"submit\">\r\n                <i class=\"iconfont icon-sousuo-sousuo\"></i>\r\n            </button>\r\n            </form>        </div>\r\n        <div class=\"search-hot\">\r\n                            <a href=\"/site/search?w=%E5%A6%BB%E5%AD%90%E7%9A%84%E7%A7%98%E5%AF%86\">妻子的秘密</a>\r\n                            <a href=\"/site/search?w=%E5%9A%A3%E5%BC%A0%E5%AE%9D%E5%AE%9D%E8%B4%A2%E8%BF%B7%E5%A6%88%E5%92%AA\">嚣张宝宝财迷妈咪</a>\r\n                    </div>\r\n        <script>\r\n            $(\"#search-form\").submit(function () {\r\n                if($(\"input[name='searchkey']\").val() == '' || $(\"input[name='searchkey']\").val() == '请输入书名或作者名'){\r\n                    layer.msg('请输入关键字');\r\n                    return false;\r\n                }\r\n            });\r\n        </script>\r\n    </div>\r\n    <div class=\"btn\">\r\n        <a href=\"/bookshelf/index\">\r\n            <i class=\"iconfont icon-book\"></i> 我的书架\r\n        </a>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"nav wrap\">\r\n    <div class=\"dropdown\">\r\n        <div class=\"btn\">\r\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\r\n</div>\r\n<div class=\"dropdown-items \">\r\n    ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \r\n</div>\r\n</div>\r\n\r\n<div class=\"wrap\">\r\n    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/666.jpg\" alt=\"\"></a>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n<div class=\"position wrap\">\r\n    <span>您的位置: </span>\r\n    <a href=\"/\">官网首页</a>\r\n    <span>></span>\r\n    <a href=\"/book/index\">书库</a>\r\n    <span>></span>\r\n    <a class=\"active\" href=\"" . $this->_tpl_vars["url_articleinfo"] . "\">" . $this->_tpl_vars["article_title"] . " </a>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n\r\n\r\n\r\n<div class=\"wrap\">\r\n    <div class=\"directory-box\">\r\n        <div class=\"book-tit\">\r\n            " . $this->_tpl_vars["article_title"] . "        </div>\r\n        <div class=\"author\">\r\n            作者: " . $this->_tpl_vars["author"] . "        </div>\r\n\r\n        <div class=\"btns\">\r\n<!--            <a href=\"\"><i class=\"iconfont icon-add\"></i> 收藏</a>-->\r\n<!--            <a href=\"\"><i class=\"iconfont icon-shuqian\"></i> 书签</a>-->\r\n<!--            <a href=\"\"><i class=\"iconfont icon-fenxiang\"></i> 分享</a>-->\r\n            <a href=\"/\"><i class=\"iconfont icon-fanhui1\"></i> 返回首页</a>\r\n        </div>\r\n        <div class=\"c15\"></div>\r\n\r\n                <div class=\"directory-cell\">\r\n\t\t\t";

if (empty($this->_tpl_vars["chapterrows"])) {
	$this->_tpl_vars["chapterrows"] = array();
}
else if (!is_array($this->_tpl_vars["chapterrows"])) {
	$this->_tpl_vars["chapterrows"] = (array) $this->_tpl_vars["chapterrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["chapterrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["chapterrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["chapterrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["chapterrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["chapterrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n\t\t\t";

	if (0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptertype"]) {
		echo "\r\n            <div class=\"cell-tit\">\r\n                <div>" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</div>\r\n<!--                <span>以更新1章</span>-->\r\n                <a href=\"javascript:;\" class=\"toggle\">- 收起</a>\r\n            </div>\r\n            <div class=\"cell-items\">\r\n                <ul>\r\n\t\t\t\t\t";
	}
	else {
		echo "\r\n                    <li><p>";

		if (0 < $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["isvip"]) {
			echo "<span>VIP</span>";
		}

		echo " \r\n\t\t\t\t\t<a href=\"" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["url_chapter"] . "\">" . $this->_tpl_vars["chapterrows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</a>\r\n\t\t\t\t\t</p></li>\r\n\t\t\t\t\t";
	}

	echo " \r\n\t\t\t\t\t";

	if ($this->_tpl_vars["i"]["order"] == $this->_tpl_vars["i"]["count"]) {
		echo "\r\n                </ul>\r\n            </div>\r\n\t\t\t";
	}

	echo "\r\n\t\t\t";
}

echo "\r\n        </div>\r\n        \r\n        <div class=\"c15\"></div>\r\n        <div class=\"btns\">\r\n<!--            <a href=\"\"><i class=\"iconfont icon-add\"></i> 收藏</a>-->\r\n<!--            <a href=\"\"><i class=\"iconfont icon-shuqian\"></i> 书签</a>-->\r\n<!--            <a href=\"\"><i class=\"iconfont icon-fenxiang\"></i> 分享</a>-->\r\n            <a href=\"/\"><i class=\"iconfont icon-fanhui1\"></i> 返回首页</a>\r\n        </div>\r\n        <div class=\"c15\"></div>\r\n    </div>\r\n</div>\r\n\r\n    <div class=\"c15\"></div>\r\n\r\n<div class=\"notice flink wrap\">\r\n    <div class=\"channel-box\">\r\n        <div class=\"tit\">\r\n            <span>友情链接</span>\r\n        </div>\r\n        <div class=\"content\">\r\n        " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n         </div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n\r\n<div class=\"footer\">\r\n\r\n    <div class=\"menu\">\r\n        <a href=\"/page/10\">关于我们</a>\r\n        <span>|</span>\r\n        <a href=\"/page/11\">商务合作</a>\r\n        <span>|</span>\r\n        <a href=\"/page/12\">用户守则</a>\r\n        <span>|</span>\r\n        <a href=\"/page/13\">联系我们</a>\r\n    </div>\r\n    <p>Copyright  2016-2017 www.qiyue.com All Rights Reserved \r\n\t<br/>根本就不存在的文化有限责任公司</p>\r\n    <div class=\"c15\"></div>\r\n    <div class=\"c15\"></div>\r\n    <p>\r\n\t\t<div style=\"width:300px;margin:0 auto; padding:20px 0;\">\r\n        <a href=\"http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=50010702501680\">\r\n        <img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/beian.png\" alt=\"\">\r\n        </a>\r\n                <a target=\"_blank\" href=\"http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=50010702501680\" style=\"display:inline-block;text-decoration:none;height:20px;line-height:20px;\"><img src=\"\" style=\"float:left;\"/><p style=\"float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;\">公网安备 000000000000号</p></a>\r\n        </div>\r\n    </p>\r\n</div>\r\n<div class=\"fix-menu\">\r\n    <div class=\"item\">\r\n        <a class=\"pic\" href=\"javascript:;\"><i class=\"iconfont icon-erweima\"></i></a>\r\n        <div class=\"sub\">\r\n            <img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/qr.png\" alt=\"\">\r\n\t\t\t<div style=\"text-align:center;color: red\">扫描上方二维码<br>看更多免费小说</div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"item\">\r\n        <a class=\"pic\" href=\"http://wpa.qq.com/msgrd?v=3&uin=1378283361&site=qq&menu=yes\" target=\"_blank\"><i class=\"iconfont icon-2\"></i></a>\r\n    </div>\r\n\r\n    <div class=\"item\">\r\n        <a class=\"pic\" href=\"javascript:;\" onclick=\"goTop()\"><i class=\"iconfont icon-back-top\"></i></a>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"login-layer\">\r\n    <form id=\"login-form\" action=\"/site/login\" method=\"post\" role=\"form\">\r\n<input type=\"hidden\" name=\"_csrf-frontend\" value=\"b0V5WHkuS2oOD0APKktzLhcfSh0WGjoZKCMXME1jCFMCfB4hOnt4Aw==\">        <div class=\"login-cell\">\r\n            <i class=\"iconfont icon-yonghu\"></i>\r\n            <input type=\"text\" placeholder=\"手机号 / 邮箱\" name=\"username\">\r\n        </div>\r\n\r\n        <div class=\"login-cell\">\r\n            <i class=\"iconfont icon-Password\"></i>\r\n            <input type=\"password\" placeholder=\"密码\" name=\"password\">\r\n        </div>\r\n\r\n        <div class=\"btns\">\r\n<!--            <p>-->\r\n<!--                <input type=\"checkbox\" id=\"auto-login\" name=\"\" value=\"\">-->\r\n<!--                <label for=\"auto-login\">自动登录</label>-->\r\n<!--            </p>-->\r\n\r\n            <div>\r\n                <a href=\"/site/resetpwd\">忘记密码</a>\r\n                |\r\n                <a href=\"/site/signup\">免费注册</a>\r\n            </div>\r\n        </div>\r\n\r\n        <input type=\"submit\" class=\"btn-ok\" value=\"登 录\">\r\n\r\n        <p class=\"more\"><a href=\"/site/login\">更多登录方式</a></p>\r\n\r\n        <!--密码找回提示S-->\r\n        <p class=\"more\"><a href=\"/news/1\" style=\"font-size: 14px;color:#ff0000\">无法登陆？请看这里></a></p>\r\n        <!--密码找回提示E-->\r\n\r\n    </form></div>\r\n\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.activeform.js\"></script>\r\n<script type=\"text/javascript\">jQuery(document).ready(function () {\r\njQuery('#login-form').yiiActiveForm([], []);\r\n});</script></body>\r\n<script type=\"text/javascript\">\r\n    $(\".need-login\").click(function () {\r\n        showLoginLayer();\r\n        return false;\r\n    });\r\n</script>\r\n</html>\r\n";

?>
