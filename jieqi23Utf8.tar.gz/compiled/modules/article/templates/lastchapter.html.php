<?php

echo "<html>\r\n<head>\r\n<title>" . $this->_tpl_vars["jieqi_pagetitle"] . "</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=" . $this->_tpl_vars["jieqi_charset"] . "\" />\r\n<meta http-equiv=\"refresh\" content=\"0;url=" . $this->_tpl_vars["jumpurl"] . "\">\r\n<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"" . $this->_tpl_vars["jieqi_url"] . "/themes/" . $this->_tpl_vars["jieqi_theme"] . "/style.css\" />\r\n</head>\r\n<body>\r\n</body>\r\n</html>";

?>
