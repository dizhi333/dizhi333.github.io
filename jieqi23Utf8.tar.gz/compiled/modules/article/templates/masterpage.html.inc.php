<?php

$GLOBALS["jieqiTset"]["jieqi_blocks_module"] = "article";
$GLOBALS["jieqiTset"]["jieqi_page_rows"] = "40";

?>
