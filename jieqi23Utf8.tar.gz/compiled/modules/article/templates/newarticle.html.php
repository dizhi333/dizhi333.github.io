<?php

echo "\r\n\r\n<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset=\"gb2312\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <title>新建作品</title>\r\n    <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/bootstrap.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/theme.min.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/font-awesome.min.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/ionicons.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/_all-skins.min.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/blue.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/style.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/article.css\" rel=\"stylesheet\">\r\n<link href=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/css/article-create.css\" rel=\"stylesheet\">\r\n<style type=\"text/css\">\r\nbody,td,th {\r\n\tfont-family: \"Source Sans Pro\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\r\n}\r\n</style>\r\n<script type=\"text/javascript\">\r\n<!--\r\n\r\nfunction showsorts(obj){\r\n    var sortselect = document.getElementById('sortselect');\r\n    sortselect.innerHTML = '';\r\n\ttypeselect.innerHTML = '';\r\n    ";

if (empty($this->_tpl_vars["rgroup"]["items"])) {
	$this->_tpl_vars["rgroup"]["items"] = array();
}
else if (!is_array($this->_tpl_vars["rgroup"]["items"])) {
	$this->_tpl_vars["rgroup"]["items"] = (array) $this->_tpl_vars["rgroup"]["items"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["rgroup"]["items"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["rgroup"]["items"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["rgroup"]["items"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["rgroup"]["items"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["rgroup"]["items"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n\t  if(obj.options[obj.selectedIndex].value == " . $this->_tpl_vars["i"]["key"] . ") sortselect.innerHTML = '<div class=\"form-group field-article-category required\"><select id=\"article-category\" class=\"form-control\" onchange=\"showtypes(this)\" name=\"sortid\" aria-required=\"true\">";

	if (empty($this->_tpl_vars["sortrows"])) {
		$this->_tpl_vars["sortrows"] = array();
	}
	else if (!is_array($this->_tpl_vars["sortrows"])) {
		$this->_tpl_vars["sortrows"] = (array) $this->_tpl_vars["sortrows"];
	}

	$this->_tpl_vars["j"] = array();
	$this->_tpl_vars["j"]["columns"] = 1;
	$this->_tpl_vars["j"]["count"] = count($this->_tpl_vars["sortrows"]);
	$this->_tpl_vars["j"]["addrows"] = ((count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["j"]["columns"]) == 0 ? 0 : $this->_tpl_vars["j"]["columns"] - (count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["j"]["columns"]));
	$this->_tpl_vars["j"]["loops"] = $this->_tpl_vars["j"]["count"] + $this->_tpl_vars["j"]["addrows"];
	reset($this->_tpl_vars["sortrows"]);

	for ($this->_tpl_vars["j"]["index"] = 0; $this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["loops"]; $this->_tpl_vars["j"]["index"]++) {
		$this->_tpl_vars["j"]["order"] = $this->_tpl_vars["j"]["index"] + 1;
		$this->_tpl_vars["j"]["row"] = ceil($this->_tpl_vars["j"]["order"] / $this->_tpl_vars["j"]["columns"]);
		$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["order"] % $this->_tpl_vars["j"]["columns"];

		if ($this->_tpl_vars["j"]["column"] == 0) {
			$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["columns"];
		}

		if ($this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["count"]) {
			list($this->_tpl_vars["j"]["key"], $this->_tpl_vars["j"]["value"]) = each($this->_tpl_vars["sortrows"]);
			$this->_tpl_vars["j"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["j"]["key"] = "";
			$this->_tpl_vars["j"]["value"] = "";
			$this->_tpl_vars["j"]["append"] = 1;
		}

		if ($this->_tpl_vars["sortrows"][$this->_tpl_vars["j"]["key"]]["rgroup"] == $this->_tpl_vars["i"]["key"]) {
			echo "<option value=\"" . $this->_tpl_vars["j"]["key"] . "\">" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["j"]["key"]]["caption"] . "</option>";
		}
	}

	echo "</select><p class=\"help-block help-block-error\"></p></div>';\r\n    ";
}

echo "\r\n}\r\n\r\nfunction showtypes(obj){\r\n    var typeselect = document.getElementById('typeselect');\r\n    typeselect.innerHTML = '';\r\n    ";

if (empty($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = array();
}
else if (!is_array($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = (array) $this->_tpl_vars["sortrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["sortrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["sortrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["sortrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n\t  ";

	if ($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"] != "") {
		echo "\r\n\t  if(obj.options[obj.selectedIndex].value == " . $this->_tpl_vars["i"]["key"] . ") typeselect.innerHTML = '<div class=\"form-group field-article-subcategory required\"><select id=\"article-subcategory\" class=\"form-control\" name=\"typeid\" aria-required=\"true\">";

		if (empty($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"])) {
			$this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"] = array();
		}
		else if (!is_array($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"])) {
			$this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"] = (array) $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"];
		}

		$this->_tpl_vars["j"] = array();
		$this->_tpl_vars["j"]["columns"] = 1;
		$this->_tpl_vars["j"]["count"] = count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);
		$this->_tpl_vars["j"]["addrows"] = ((count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]) % $this->_tpl_vars["j"]["columns"]) == 0 ? 0 : $this->_tpl_vars["j"]["columns"] - (count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]) % $this->_tpl_vars["j"]["columns"]));
		$this->_tpl_vars["j"]["loops"] = $this->_tpl_vars["j"]["count"] + $this->_tpl_vars["j"]["addrows"];
		reset($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);

		for ($this->_tpl_vars["j"]["index"] = 0; $this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["loops"]; $this->_tpl_vars["j"]["index"]++) {
			$this->_tpl_vars["j"]["order"] = $this->_tpl_vars["j"]["index"] + 1;
			$this->_tpl_vars["j"]["row"] = ceil($this->_tpl_vars["j"]["order"] / $this->_tpl_vars["j"]["columns"]);
			$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["order"] % $this->_tpl_vars["j"]["columns"];

			if ($this->_tpl_vars["j"]["column"] == 0) {
				$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["columns"];
			}

			if ($this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["count"]) {
				list($this->_tpl_vars["j"]["key"], $this->_tpl_vars["j"]["value"]) = each($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);
				$this->_tpl_vars["j"]["append"] = 0;
			}
			else {
				$this->_tpl_vars["j"]["key"] = "";
				$this->_tpl_vars["j"]["value"] = "";
				$this->_tpl_vars["j"]["append"] = 1;
			}

			echo "<option value=\"" . $this->_tpl_vars["j"]["key"] . "\"";

			if ($this->_tpl_vars["j"]["key"] == $this->_tpl_vars["articlevals"]["typeid"]) {
				echo " selected=\"selected\"";
			}

			echo ">" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"][$this->_tpl_vars["j"]["key"]] . "</option>";
		}

		echo "</select><p class=\"help-block help-block-error\"></p></div>';\r\n\t  ";
	}

	echo "\r\n    ";
}

echo "\r\n}\r\n\r\n//-->\r\n</script>\r\n</head>\r\n<body class=\"hold-transition skin-blue layout-top-nav\">\r\n<div class=\"wrapper\">\r\n\r\n    <header class=\"main-header\">\r\n        <nav class=\"navbar navbar-static-top\">\r\n            <div class=\"container\">\r\n                <div class=\"navbar-header\">\r\n                    <a href=\"/\" class=\"navbar-brand\">" . $this->_tpl_vars["jieqi_sitename"] . "&middot;<span>作家中心</span></a>\r\n                    <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar-collapse\">\r\n                        <i class=\"fa fa-bars\"></i>\r\n                    </button>\r\n                </div>\r\n                                <div class=\"collapse navbar-collapse pull-left\" id=\"navbar-collapse\">\r\n                    <ul class=\"nav navbar-nav\">\r\n                        <li><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/author\">作品管理 <span class=\"sr-only\">(current)</span></a></li>\r\n                        <li class=\"active\"><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/modules/article/apply.php?id=3\">申请签约</a></li>\r\n                        <li><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/mreport\">作品收入</a></li>\r\n\t\t\t\t\t\t\r\n                    </ul>\r\n                </div>\r\n                \r\n                <div class=\"navbar-custom-menu\">\r\n                    <ul class=\"nav navbar-nav\">\r\n                        <li class=\"dropdown notifications-menu\">\r\n                            <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/authornotice\" class=\"dropdown\">\r\n                                <i class=\"fa fa-bell-o\"></i>&nbsp;&nbsp;&nbsp;通知\r\n                                                            </a>\r\n                        </li>\r\n                        <li class=\"dropdown user user-menu\">\r\n                                                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">\r\n                                <img src=\"" . jieqi_geturl("system", "avatar", $this->_tpl_vars["jieqi_userid"], "s") . "\" class=\"user-image\" alt=\"" . $this->_tpl_vars["jieqi_username"] . "\">\r\n                                <span class=\"hidden-xs\">" . $this->_tpl_vars["jieqi_username"] . "</span>\r\n                            </a>\r\n                                                        <ul class=\"dropdown-menu\">\r\n                                                                <li>\r\n                                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/userdetail.php\"><i class=\"fa fa-edit\"></i>我的资料</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"" . $this->_tpl_vars["jieqi_url"] . "/passedit.php\" id=\"modifyPwdBtn\"><i class=\"fa fa-lock\"></i>更改密码</a>\r\n                                </li>\r\n                                                                <li>\r\n                                    <a href=\"" . $this->_tpl_vars["jieqi_user_url"] . "/logout.php?jumpurl=" . urlencode($this->_tpl_vars["jieqi_thisurl"]) . "\"><i class=\"fa fa-sign-out\"></i>退出登录</a>\r\n                                </li>\r\n                            </ul>\r\n                        </li>\r\n                    </ul>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n    </header>\r\n\r\n    <div class=\"content-wrapper\">\r\n        <div class=\"container\">\r\n            <section class=\"content\">\r\n                <div class=\"box box-default\">\r\n    <div class=\"box-header with-border\">\r\n        <h3 class=\"box-title\">新建作品</h3>\r\n    </div>\r\n    <div class=\"box-body\">\r\n            <form id=\"register-form\" class=\"form-horizontal\" action=\"" . $this->_tpl_vars["url_newarticle"] . "\" method=\"post\" enctype=\"multipart/form-data\">\r\n            <div class=\"form-input-box\">\r\n                <div class=\"form-group field-article-name required\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-name\">书名</label>\r\n<div class=\"col-sm-9\">\r\n<input type=\"text\" id=\"article-name\" class=\"form-control\" name=\"articlename\" placeholder=\"作品名称\" aria-required=\"true\"><p class=\"help-block help-block-error\"></p></div>\r\n</div>\r\n\r\n<div class=\"form-group field-article-backupname\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-keywords\">副标题</label>\r\n<div class=\"col-sm-9\">\r\n<input type=\"text\" id=\"article-keywords\" class=\"form-control\" name=\"backupname\" placeholder=\"一句话副标题\">\r\n</div>\r\n</div>\r\n\r\n                <div class=\"form-group\">\r\n                    <label class=\"col-sm-3 control-label\" for=\"registerform-card_type\">作品分类</label>\r\n                    <div class=\"col-sm-3\">\r\n                        <div class=\"form-group field-article-channel required\">\r\n<select id=\"article-channel\" onchange=\"showsorts(this)\"  class=\"form-control\" name=\"rgroup\" aria-required=\"true\">\r\n<option value=\"0\">请选择频道</option>\r\n";

if (empty($this->_tpl_vars["rgroup"]["items"])) {
	$this->_tpl_vars["rgroup"]["items"] = array();
}
else if (!is_array($this->_tpl_vars["rgroup"]["items"])) {
	$this->_tpl_vars["rgroup"]["items"] = (array) $this->_tpl_vars["rgroup"]["items"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["rgroup"]["items"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["rgroup"]["items"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["rgroup"]["items"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["rgroup"]["items"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["rgroup"]["items"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n<option value=\"" . $this->_tpl_vars["i"]["key"] . "\" >" . $this->_tpl_vars["rgroup"]["items"][$this->_tpl_vars["i"]["key"]] . "</option>\r\n";
}

echo "\r\n</select><p class=\"help-block help-block-error\"></p>\r\n</div>                    </div>\r\n \r\n <div class=\"col-sm-3\" id=\"sortselect\" name=\"sortselect\">\r\n <!--\r\n<div class=\"form-group field-article-category required\">\r\n\r\n<select id=\"article-category\" class=\"form-control\" name=\"sortid\" aria-required=\"true\">\r\n<option value=\"\"  name=\"rgroup\" id=\"rgroup\">-分类-</option>\r\n";

if (empty($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = array();
}
else if (!is_array($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = (array) $this->_tpl_vars["sortrows"];
}

$this->_tpl_vars["j"] = array();
$this->_tpl_vars["j"]["columns"] = 1;
$this->_tpl_vars["j"]["count"] = count($this->_tpl_vars["sortrows"]);
$this->_tpl_vars["j"]["addrows"] = ((count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["j"]["columns"]) == 0 ? 0 : $this->_tpl_vars["j"]["columns"] - (count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["j"]["columns"]));
$this->_tpl_vars["j"]["loops"] = $this->_tpl_vars["j"]["count"] + $this->_tpl_vars["j"]["addrows"];
reset($this->_tpl_vars["sortrows"]);

for ($this->_tpl_vars["j"]["index"] = 0; $this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["loops"]; $this->_tpl_vars["j"]["index"]++) {
	$this->_tpl_vars["j"]["order"] = $this->_tpl_vars["j"]["index"] + 1;
	$this->_tpl_vars["j"]["row"] = ceil($this->_tpl_vars["j"]["order"] / $this->_tpl_vars["j"]["columns"]);
	$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["order"] % $this->_tpl_vars["j"]["columns"];

	if ($this->_tpl_vars["j"]["column"] == 0) {
		$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["columns"];
	}

	if ($this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["count"]) {
		list($this->_tpl_vars["j"]["key"], $this->_tpl_vars["j"]["value"]) = each($this->_tpl_vars["sortrows"]);
		$this->_tpl_vars["j"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["j"]["key"] = "";
		$this->_tpl_vars["j"]["value"] = "";
		$this->_tpl_vars["j"]["append"] = 1;
	}

	echo "\r\n<option value=\"" . $this->_tpl_vars["j"]["key"] . "\">" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["j"]["key"]]["caption"] . "</option>\r\n";
}

echo "\r\n</select>\r\n\r\n<p class=\"help-block help-block-error\"></p>\r\n</div>\r\n-->\r\n                    </div>\r\n                    <div class=\"col-sm-3\" id=\"typeselect\" name=\"typeselect\">\r\n<!--\t\t\t\t\t\r\n<div class=\"form-group field-article-subcategory required\" >\r\n\r\n<select id=\"article-subcategory\" class=\"form-control\" name=\"typeid\" aria-required=\"true\">\r\n<option value=\"\">-子分类-</option>\r\n";

if (empty($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = array();
}
else if (!is_array($this->_tpl_vars["sortrows"])) {
	$this->_tpl_vars["sortrows"] = (array) $this->_tpl_vars["sortrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["sortrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["sortrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["sortrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["sortrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	if (empty($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"])) {
		$this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"] = array();
	}
	else if (!is_array($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"])) {
		$this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"] = (array) $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"];
	}

	$this->_tpl_vars["j"] = array();
	$this->_tpl_vars["j"]["columns"] = 1;
	$this->_tpl_vars["j"]["count"] = count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);
	$this->_tpl_vars["j"]["addrows"] = ((count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]) % $this->_tpl_vars["j"]["columns"]) == 0 ? 0 : $this->_tpl_vars["j"]["columns"] - (count($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]) % $this->_tpl_vars["j"]["columns"]));
	$this->_tpl_vars["j"]["loops"] = $this->_tpl_vars["j"]["count"] + $this->_tpl_vars["j"]["addrows"];
	reset($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);

	for ($this->_tpl_vars["j"]["index"] = 0; $this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["loops"]; $this->_tpl_vars["j"]["index"]++) {
		$this->_tpl_vars["j"]["order"] = $this->_tpl_vars["j"]["index"] + 1;
		$this->_tpl_vars["j"]["row"] = ceil($this->_tpl_vars["j"]["order"] / $this->_tpl_vars["j"]["columns"]);
		$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["order"] % $this->_tpl_vars["j"]["columns"];

		if ($this->_tpl_vars["j"]["column"] == 0) {
			$this->_tpl_vars["j"]["column"] = $this->_tpl_vars["j"]["columns"];
		}

		if ($this->_tpl_vars["j"]["index"] < $this->_tpl_vars["j"]["count"]) {
			list($this->_tpl_vars["j"]["key"], $this->_tpl_vars["j"]["value"]) = each($this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"]);
			$this->_tpl_vars["j"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["j"]["key"] = "";
			$this->_tpl_vars["j"]["value"] = "";
			$this->_tpl_vars["j"]["append"] = 1;
		}

		echo "\r\n<option value=\"" . $this->_tpl_vars["j"]["key"] . "\">" . $this->_tpl_vars["sortrows"][$this->_tpl_vars["i"]["key"]]["types"][$this->_tpl_vars["j"]["key"]] . "</option>\r\n";
	}
}

echo "\r\n</select>\r\n\r\n<p class=\"help-block help-block-error\"></p>\r\n</div>\r\n-->\r\n\r\n                    </div>\r\n                </div>\r\n\r\n<div class=\"form-group field-article-keywords\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-keywords\">标签</label>\r\n<div class=\"col-sm-9\"><input type=\"text\" id=\"article-keywords\" class=\"form-control\" name=\"keywords\" placeholder=\"作品关键词\">\r\n<p class=\"help-block help-block-error\"></p>\r\n</div>\r\n</div>\r\n\r\n";

if (0 < $this->_tpl_vars["allowtrans"]) {
	echo "\r\n<div class=\"form-group field-article-author\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-author\">作者</label>\r\n<div class=\"col-sm-9\"><input type=\"text\" id=\"article-author\" class=\"form-control\" name=\"author\" placeholder=\"小说作者\">\r\n<p class=\"help-block help-block-error\">发表自己作品请留空</p>\r\n</div>\r\n</div>\r\n<div class=\"form-group field-article-intro\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-intro\">作者授权</label>\r\n<div class=\"col-sm-9\">\r\n";

	if (empty($this->_tpl_vars["authorflag"]["items"])) {
		$this->_tpl_vars["authorflag"]["items"] = array();
	}
	else if (!is_array($this->_tpl_vars["authorflag"]["items"])) {
		$this->_tpl_vars["authorflag"]["items"] = (array) $this->_tpl_vars["authorflag"]["items"];
	}

	$this->_tpl_vars["i"] = array();
	$this->_tpl_vars["i"]["columns"] = 1;
	$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["authorflag"]["items"]);
	$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["authorflag"]["items"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["authorflag"]["items"]) % $this->_tpl_vars["i"]["columns"]));
	$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
	reset($this->_tpl_vars["authorflag"]["items"]);

	for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
		$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
		$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

		if ($this->_tpl_vars["i"]["column"] == 0) {
			$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
		}

		if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
			list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["authorflag"]["items"]);
			$this->_tpl_vars["i"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["i"]["key"] = "";
			$this->_tpl_vars["i"]["value"] = "";
			$this->_tpl_vars["i"]["append"] = 1;
		}

		echo "\r\n<input type=\"radio\" style=\"margin-top:8px;\" name=\"authorflag\" value=\"" . $this->_tpl_vars["i"]["key"] . "\" ";

		if ($this->_tpl_vars["i"]["key"] == $this->_tpl_vars["authorflag"]["default"]) {
			echo "checked=\"checked\" ";
		}

		echo ">" . $this->_tpl_vars["authorflag"]["items"][$this->_tpl_vars["i"]["key"]];
	}

	echo "\r\n</div>\r\n</div>\r\n";
}

echo "\r\n<div class=\"form-group field-article-intro\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-intro\">授权级别</label>\r\n<div class=\"col-sm-9\">\r\n";

if (empty($this->_tpl_vars["permission"]["items"])) {
	$this->_tpl_vars["permission"]["items"] = array();
}
else if (!is_array($this->_tpl_vars["permission"]["items"])) {
	$this->_tpl_vars["permission"]["items"] = (array) $this->_tpl_vars["permission"]["items"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["permission"]["items"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["permission"]["items"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["permission"]["items"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["permission"]["items"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["permission"]["items"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n<input type=\"radio\" style=\"margin-top:8px;\" name=\"permission\" value=\"" . $this->_tpl_vars["i"]["key"] . "\" ";

	if ($this->_tpl_vars["i"]["key"] == $this->_tpl_vars["permission"]["default"]) {
		echo "checked=\"checked\" ";
	}

	echo ">" . $this->_tpl_vars["permission"]["items"][$this->_tpl_vars["i"]["key"]];
}

echo "\r\n</div>\r\n</div>\r\n\r\n<div class=\"form-group field-article-intro\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-intro\">首发状态</label>\r\n<div class=\"col-sm-9\">\r\n";

if (empty($this->_tpl_vars["firstflag"]["items"])) {
	$this->_tpl_vars["firstflag"]["items"] = array();
}
else if (!is_array($this->_tpl_vars["firstflag"]["items"])) {
	$this->_tpl_vars["firstflag"]["items"] = (array) $this->_tpl_vars["firstflag"]["items"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["firstflag"]["items"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["firstflag"]["items"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["firstflag"]["items"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["firstflag"]["items"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["firstflag"]["items"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n<input type=\"radio\" style=\"margin-top:8px;\" name=\"firstflag\" value=\"" . $this->_tpl_vars["i"]["key"] . "\" ";

	if ($this->_tpl_vars["i"]["key"] == $this->_tpl_vars["firstflag"]["default"]) {
		echo "checked=\"checked\" ";
	}

	echo ">" . $this->_tpl_vars["firstflag"]["items"][$this->_tpl_vars["i"]["key"]];
}

echo "\r\n</div>\r\n</div>\r\n\r\n\r\n                <div class=\"form-group field-article-intro\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-intro\">简介</label>\r\n<div class=\"col-sm-9\">\r\n<textarea id=\"article-intro\" class=\"form-control\" name=\"intro\" placeholder=\"作品简介\"></textarea>\r\n<p class=\"help-block help-block-error\"></p></div>\r\n</div>\r\n                <div class=\"form-group field-article-notice\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-notice\">本书公告</label>\r\n<div class=\"col-sm-9\">\r\n<textarea id=\"article-notice\" class=\"form-control\" name=\"notice\" placeholder=\"作品公告\"></textarea>\r\n<p class=\"help-block help-block-error\"></p></div>\r\n</div>\r\n\r\n<div class=\"form-group field-article-cover\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-cover\">封面小图</label>\r\n<div class=\"col-sm-9\">\r\n<input type=\"file\" id=\"article-cover\" name=\"articlespic\" placeholder=\"封面图片\">\r\n<p class=\"help-block help-block-error\">\r\n</p>\r\n</div>\r\n</div>\r\n<div class=\"form-group field-article-cover\">\r\n<label class=\"col-sm-3 control-label\" for=\"article-cover\">封面大图</label>\r\n<div class=\"col-sm-9\">\r\n<input type=\"file\" id=\"article-cover\" name=\"articlelpic\" placeholder=\"封面图片\">\r\n<p class=\"help-block help-block-error\">\r\n</p>\r\n</div>\r\n</div>\r\n                <div class=\"row\">\r\n                    <div class=\"col-sm-offset-4 col-sm-4\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"action\" id=\"action\" value=\"newarticle\" />" . $this->_tpl_vars["jieqi_token_input"] . "\r\n\t\t\t\t\t<input type=\"submit\" value=\"创建作品\"  name=\"submit\" class=\"btn btn-warning btn-block\" />\r\n\t\t\t\t\t\t</div>\r\n                </div>\r\n            </div>\r\n            </form>    </div>\r\n    <div class=\"box-footer\">\r\n\r\n    </div>\r\n</div>            </section>\r\n        </div>\r\n    </div>\r\n\r\n    <footer class=\"main-footer\">\r\n        <div class=\"container\">\r\n            <div class=\"pull-right hidden-xs\">\r\n                Copyright &copy; " . date("Y", $this->_tpl_vars["jieqi_time"]) . " All Rights Reserved " . $this->_tpl_vars["jieqi_sitename"] . " 版权所有\r\n            </div>\r\n        </div>\r\n    </footer>\r\n</div>\r\n\r\n<div id=\"msgModal\" class=\"fade modal\" role=\"dialog\" tabindex=\"-1\">\r\n<div class=\"modal-dialog \">\r\n<div class=\"modal-content\">\r\n<div class=\"modal-header\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>\r\n<h4 class=\"modal-title\">消息提示</h4>\r\n</div>\r\n<div class=\"modal-body\">\r\n\r\n</div>\r\n<div class=\"modal-footer\">\r\n<a href=\"#\" class=\"btn btn-primary\" data-dismiss=\"modal\">确定</a>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/bootstrap.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/app.min.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/jquery.slimscroll.min.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/icheck.min.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.validation.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/yii.activeForm.js\"></script>\r\n<script src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/js/vue.js\"></script>\r\n<!--[if lt IE 9]>\r\n<script src=\"/js/html5shiv.min.js\"></script>\r\n<![endif]-->\r\n<!--[if lt IE 9]>\r\n<script src=\"/js/respond.min.js\"></script>\r\n<![endif]-->\r\n<script type=\"text/javascript\">jQuery(document).ready(function () {\r\n$(\"#modifyPwdBtn\").click(function() {\r\n    $(\"#modifyPwdModal\").modal('show');\r\n});\r\n$(\"#savePwdBtn\").click(function() {\r\n    var form = $(\"#modifyPwdForm\");\r\n        $.ajax({\r\n            url: form.attr('action'),\r\n            type: 'post',\r\n            data: form.serialize(),\r\n            success: function (data) {\r\n                location.reload();\r\n            }\r\n        });\r\n});\r\njQuery('#msgModal').modal({\"show\":false});\r\njQuery('#modifyPwdForm').yiiActiveForm([], []);\r\njQuery('#modifyPwdModal').modal({\"show\":false});\r\n});</script></body>\r\n</html>\r\n";

?>
