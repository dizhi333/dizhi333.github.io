<?php

echo "\r\n<script type=\"text/javascript\">\r\nvar customprice = '" . $this->_tpl_vars["customprice"] . "';\r\nfunction frmnewdraft_validate(){\r\n  if(document.frmnewdraft.chaptername.value == \"\"){\r\n    alert(\"请输入章节标题\");\r\n    document.frmnewdraft.chaptername.focus();\r\n    return false;\r\n  }\r\n  if(document.frmnewdraft.chaptercontent.value == \"\" ){\r\n\talert( \"请输入章节内容\" );\r\n\tdocument.frmnewdraft.chaptercontent.focus();\r\n\treturn false;\r\n  }\r\n}\r\n//统计输入字数\r\nfunction show_inputsize(txt){\r\n\ttxt = \$_(txt);\r\n\tvar size = (arguments.length > 1) ? \$_(arguments[1]) : \$_(txt.id + '_size');\r\n\tsize.innerHTML = txt.value.replace(/\s/g, '').length;\r\n}\r\n//显示默认字数\r\naddEvent(window, 'load', function(){show_inputsize('chaptercontent');});\r\n</script>\r\n<div class=\"novel-home-body-container\" >\r\n    <div class=\"container container-box-shadow\" style=\"margin-bottom:48px;\">\r\n        <div class=\"clearfix\">\r\n                        <div class=\"novel-left-menu\">\r\n                <div class=\"menu-header\">作者中心</div>\r\n                <ul>\r\n                   <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/myarticle.php\">作家首页</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_static_url"] . "/newarticle.php\">新建作品</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/masterpage.php\">管理作品</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/apply.php?id=3\">申请上架</a></li>\r\n                    ";

if (0 < $this->_tpl_vars["jieqi_modules"]["obook"]["publish"]) {
	echo "\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["jieqi_modules"]["obook"]["url"] . "/mreport.php\">收入管理</a></li>\r\n                    ";
}

echo "\r\n                    <li class=\"on\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/newdraft.php\">新建草稿</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/draft.php\">管理草稿</a></li>\r\n                    <li class=\"\"><a href=\"" . $this->_tpl_vars["jieqi_url"] . "/persondetail.php\">作者实名信息</a></li>\r\n                </ul>\r\n            </div>\r\n            <div class=\"novel-right user-author-infor\">\r\n                <div class=\"right-header\">\r\n                    新建草稿\r\n                </div>\r\n               <div class=\"author-infor-header clearfix\"></div>     \r\n               <form name=\"frmnewdraft\" id=\"frmnewdraft\" method=\"post\"  action=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/newdraft.php?do=submit\" onsubmit=\"return frmnewdraft_validate();\" enctype=\"multipart/form-data\" >\r\n               <div class=\"author-infor-body\">\r\n                    <div class=\"author-infor-body-form\">\r\n\t\t\t\t\t    <div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">草稿类型：</div>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"isvip\" value=\"0\" checked=\"checked\" onclick=\"document.getElementById('selarticle').style.display='block';document.getElementById('selobook').style.display='none';if(customprice == '1') document.getElementById('sprice').style.display='none';\">免费章节&nbsp;&nbsp;</span>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"isvip\" value=\"1\" onclick=\"document.getElementById('selarticle').style.display='none';document.getElementById('selobook').style.display='block';if(customprice == '1') document.getElementById('sprice').style.display='';\">VIP章节</span>\r\n\t\t\t\t\t\t\t\r\n                        </div>\r\n                        <div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">作品名称：</div>\r\n\t\t\t\t\t\t\t<div id=\"selarticle\" style=\"display:block;\">\r\n                            <select style=\"width:150px;\" onchange=\"showsorts(this)\" name='articleid' id='articleid'>\r\n                            <option value=\"0\" >--请选择--</option>\r\n\t\t\t\t\t\t\t";

if (empty($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = array();
}
else if (!is_array($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = (array) $this->_tpl_vars["articlerows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["articlerows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["articlerows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["articlerows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n\t\t\t\t\t\t\t<option value=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "\" >" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</option>\r\n\t\t\t\t\t\t\t";
}

echo "\r\n\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<div id=\"selobook\" style=\"display:none;\">\r\n                            <select style=\"width:150px;\" onchange=\"showsorts(this)\" name='obookid' id='obookid'>\r\n                            <option value=\"0\" >--请选择--</option>\r\n\t\t\t\t\t\t\t";

if (empty($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = array();
}
else if (!is_array($this->_tpl_vars["articlerows"])) {
	$this->_tpl_vars["articlerows"] = (array) $this->_tpl_vars["articlerows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["articlerows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["articlerows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["articlerows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n\t\t\t\t\t\t\t";

	if (0 < $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["isvip"]) {
		echo "\r\n\t\t\t\t\t\t\t<option value=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "\" >" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</option>\r\n\t\t\t\t\t\t\t";
	}

	echo "\r\n\t\t\t\t\t\t\t";
}

echo "\r\n\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t</div>\r\n                        </div>\r\n\t\t\t\t\t\t<div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">章节标题：</div>\r\n                            <div class=\"form-input\"  style=\"width:400px;\"><input type=\"text\" name=\"chaptername\" id=\"chaptername\" size=\"50\" maxlength=\"50\"></div>\r\n                        </div>\r\n\t\t\t\t\t\t";

if (0 < $this->_tpl_vars["customprice"]) {
	echo "\r\n\t\t\t\t\t\t<div class=\"form-list clearfix\" id=\"sprice\" style=\"display:none;\">\r\n                            <div class=\"form-left\">本章定价：</div>\r\n                            <div class=\"form-input\" style=\"width:80px;\"><input type=\"text\" name=\"saleprice\" id=\"saleprice\" size=\"4\" maxlength=\"10\" value=\"" . $this->_tpl_vars["saleprice"] . "\"></div>\r\n\t\t\t\t\t\t\t<p style=\"margin-left:10px;line-height:30px;font-size:14px;\">&nbsp;&nbsp;" . $this->_tpl_vars["egoldname"] . "&nbsp;&nbsp;<span style=\"color:red\">(留空则自动按字数计价)</span></p>\r\n                        </div>\r\n\t\t\t\t\t\t";
}

if (0 < $this->_tpl_vars["authtypeset"]) {
	echo "\r\n\t\t\t\t\t\t<div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">作品排版：</div>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"typeset\" value=\"1\" checked=\"checked\">自动排版&nbsp;&nbsp;</span>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"typeset\" value=\"0\" checked=\"checked\">无需排版</span>\r\n                        </div>\r\n\t\t\t\t\t\t";
}

echo "\r\n\t\t\t\t\t\t";

if (0 < $this->_tpl_vars["uptiming"]) {
	echo "\r\n\t\t\t\t\t\t<div class=\"form-list clearfix\">\r\n                        <div class=\"form-left\">发表方式：</div>\r\n\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"autopub\" value=\"0\" checked=\"checked\" onclick=\"document.getElementById('pubtime').style.display='none';\">存为草稿&nbsp;&nbsp;</span>\t\r\n\t\t\t\t\t\t<input type=\"radio\" style=\"margin-top:8px;\" name=\"autopub\" value=\"1\" onclick=\"document.getElementById('pubtime').style.display='';\">定时发表</span>\r\n\t\t\t\t\t\t <b id=\"pubtime\" style=\"display:none;\"><input type=\"text\" name=\"pubyear\" id=\"pubyear\" size=\"4\" maxlength=\"4\" style=\"width:40px\" value=\"" . date("Y", $this->_tpl_vars["jieqi_time"]) . "\" >&nbsp;年&nbsp;<input type=\"text\" name=\"pubmonth\" id=\"pubmonth\" size=\"2\" maxlength=\"2\" style=\"width:35px\" value=\"" . date("m", $this->_tpl_vars["jieqi_time"]) . "\" >&nbsp;月&nbsp;<input type=\"text\" name=\"pubday\" id=\"pubday\" size=\"2\" maxlength=\"2\" style=\"width:35px\" value=\"" . date("d", $this->_tpl_vars["jieqi_time"]) . "\" >&nbsp;日&nbsp;<input type=\"text\" name=\"pubhour\" id=\"pubhour\" size=\"2\" maxlength=\"2\" style=\"width:35px\" value=\"" . date("h", $this->_tpl_vars["jieqi_time"]) . "\" >&nbsp;时&nbsp;<input type=\"text\" name=\"pubminute\" id=\"pubminute\" size=\"4\" maxlength=\"4\" style=\"width:35px\" value=\"\" >&nbsp;分&nbsp;</b>\r\n                        </div>\r\n\t\t\t\t\t\t";
}

echo "\r\n                        <div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">章节内容：</div>\r\n                            <textarea style=\"width:501px; height:510px;\" class=\"textarea\" name=\"chaptercontent\" id=\"chaptercontent\" rows=\"25\" cols=\"80\" onkeyup=\"show_inputsize(this);\" oninput=\"show_inputsize(this);\" onpropertychange=\"show_inputsize(this);\"></textarea>\r\n\t\t\t\t\t\t\t<p  class=\"input-p\">您已输入 <strong id=\"chaptercontent_size\"style=\"color:red;\">0</strong> 个字</p>\r\n                        </div>\r\n                        <div class=\"form-list clearfix\">\r\n                            <div class=\"form-left\">&nbsp;<input type=\"hidden\" name=\"action\" id=\"action\" value=\"newdraft\" /></div>\r\n                            <input type=\"submit\" value=\"保存\"  name=\"submit\" class=\"form-save\" />\r\n\t\t\t\t\t\t";

if (0 < $this->_tpl_vars["needupaudit"]) {
	echo "&nbsp;&nbsp;<span style=\"margin-left:10px;line-height:30px;font-size:12px;color:red\">注意：新建草稿的章节也会先保存在草稿箱待审章节列表中，管理员审核后才能正常显示。</span>";
}

echo "\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n               </form>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<script type=\"text/javascript\">\r\nlayer.ready(function(){\r\n\t\t$('#frmnewdraft').on('submit', function(e){\r\n\t\te.preventDefault();\r\n\t\tvar i = layer.load(0);\r\n\t\t\t\tGPage.postForm('frmnewdraft', $(\"#frmnewdraft\").attr(\"action\"),\r\n\t\t\t   function(data){\r\n\t\t\t\t\tif(data.status=='OK'){\r\n\t\t\t\t\t    layer.msg(data.msg,{icon: 6},function(){});\r\n\t\t\t\t\t\t$.ajaxSetup ({ cache: false });\r\n\t\t\t\t\t\tjumpurl(data.jumpurl);\r\n\t\t\t\t\t}else{\r\n\t\t\t\t\t    layer.close(i);\r\n\t\t\t\t\t\tlayer.alert(data.msg, {icon: 5}, !1);\r\n\t\t\t\t\t}\r\n\t\t\t   });\r\n//\t\t\t}\r\n\t\t});\r\n});\r\n$('#recode').click(function(){\r\n\t$('#checkcode').attr('src','" . $this->_tpl_vars["jieqi_url"] . "/checkcode.php?rand='+Math.random());\r\n});\r\n</script>\r\n";

?>
