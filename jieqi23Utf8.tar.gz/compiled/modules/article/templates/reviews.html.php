<?php

echo "\r\n<script>window.location.href='" . $this->_tpl_vars["url_articleinfo"] . "';</script> \r\n<table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n    <tr>\r\n        <td><table width=\"100%\"  border=\"0\" cellspacing=\"2\" cellpadding=\"3\">\r\n            <tr>\r\n                <td width=\"40%\" align=\"left\"><a href=\"" . $this->_tpl_vars["url_articleinfo"] . "\">《" . $this->_tpl_vars["articlename"] . "》</a> 书评列表</td>\r\n                <td width=\"60%\" align=\"right\">";

if ($this->_tpl_vars["type"] == "good") {
	echo "&nbsp;&nbsp;&nbsp;&nbsp;[<a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/reviews.php?aid=" . $this->_tpl_vars["articleid"] . "&type=all\">全部书评</a>] &nbsp;&nbsp; [精华书评]";
}
else {
	echo "&nbsp;&nbsp;&nbsp;&nbsp;[全部书评] &nbsp;&nbsp; [<a href=\"" . $this->_tpl_vars["article_dynamic_url"] . "/reviews.php?aid=" . $this->_tpl_vars["articleid"] . "&type=good\">精华书评</a>]";
}

echo "</td>\r\n            </tr>\r\n        </table></td>\r\n    </tr>\r\n</table>\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n  <tr align=\"center\">\r\n    <td width=\"54%\" class=\"title\">主题</td>\r\n    <td width=\"12%\" class=\"title\">回复/查看</td>\r\n    <td width=\"17%\" class=\"title\">发表人/回复人</td>\r\n    <td width=\"15%\" class=\"title\">发表时间</td>\r\n  </tr>\r\n  ";

if (empty($this->_tpl_vars["reviewrows"])) {
	$this->_tpl_vars["reviewrows"] = array();
}
else if (!is_array($this->_tpl_vars["reviewrows"])) {
	$this->_tpl_vars["reviewrows"] = (array) $this->_tpl_vars["reviewrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["reviewrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["reviewrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["reviewrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["reviewrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["reviewrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n  <tr>\r\n    <td>";

	if ($this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["istop"] == 1) {
		echo "<span class=\"hottext\">[顶]</span>";
	}

	if ($this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["isgood"] == 1) {
		echo "<span class=\"hottext\">[精]</span>";
	}

	echo "<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviewshow.php?rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["title"] . "</a></td>\r\n    <td align=\"center\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["replies"] . "/" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["views"] . "</td>\r\n    <td align=\"center\">";

	if (0 < $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["posterid"]) {
		echo "<a href=\"" . jieqi_geturl("system", "user", $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["posterid"]) . "\" target=\"_blank\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["poster"] . "</a>";
	}
	else {
		echo "游客";
	}

	if (0 < $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["replyflag"]) {
		echo "/";

		if (0 < $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["replierid"]) {
			echo "<a href=\"" . jieqi_geturl("system", "user", $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["replierid"]) . "\" target=\"_blank\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["replier"] . "</a>";
		}
		else {
			echo "游客";
		}
	}

	echo "</td>\r\n    <td align=\"center\">" . date("Y-m-d H:i:s", $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["posttime"]);

	if ($this->_tpl_vars["ismaster"] == 1) {
		echo "<br />";

		if ($this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["istop"] == 0) {
			echo "[<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviews.php?action=top&aid=" . $this->_tpl_vars["articleid"] . "&rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "\">置顶</a>]";
		}
		else {
			echo "[<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviews.php?action=untop&aid=" . $this->_tpl_vars["articleid"] . "&rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "\">置后</a>]";
		}

		echo " ";

		if ($this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["isgood"] == 0) {
			echo "[<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviews.php?action=good&aid=" . $this->_tpl_vars["articleid"] . "&rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "\">加精</a>]";
		}
		else {
			echo "[<a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviews.php?action=normal&aid=" . $this->_tpl_vars["articleid"] . "&rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "\">去精</a>]";
		}

		echo " [<a href=\"javascript:if(confirm('确实要删除该书评么？')) document.location='" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/reviews.php?action=del&aid=" . $this->_tpl_vars["articleid"] . "&rid=" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["topicid"] . "';\">删除</a>]";
	}

	echo "</td>\r\n  </tr>\r\n  ";
}

echo "\r\n</table>\r\n<table width=\"100%\"  border=\"0\" cellspacing=\"2\" cellpadding=\"3\">\r\n    <tr>\r\n        <td align=\"right\">" . $this->_tpl_vars["url_jumppage"] . "</td>\r\n    </tr>\r\n</table>\r\n";

if ($this->_tpl_vars["enablepost"] == 1) {
	echo "\r\n<form name=\"frmreview\" method=\"post\" action=\"" . $this->_tpl_vars["article_dynamic_url"] . "/reviews.php?aid=" . $this->_tpl_vars["articleid"] . "\">\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n  <caption>发表书评</caption>\r\n  <tr>\r\n    <td class=\"tdl\" width=\"25%\">标题：</td>\r\n    <td class=\"tdr\"><input type='text' class='text' name='ptitle' id='ptitle' size='60' maxlength='60' value='' /></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"tdl\" width=\"25%\">内容：</td>\r\n    <td class=\"tdr\"><textarea class=\"textarea\" name=\"pcontent\" id=\"pcontent\" cols=\"60\" rows=\"12\"></textarea>\r\n    <script type=\"text/javascript\">loadJs(\"" . $this->_tpl_vars["jieqi_url"] . "/scripts/ubbeditor_" . $this->_tpl_vars["jieqi_charset"] . ".js\", function(){UBBEditor.Create(\"pcontent\");});</script>\r\n    </td>\r\n  </tr>\r\n";

	if (0 < $this->_tpl_vars["postcheckcode"]) {
		echo "\r\n<tr>\r\n  <td class=\"tdl\">验证码：</td>\r\n  <td class=\"tdr\"><input type=\"text\" class=\"text\" size=\"8\" maxlength=\"8\" name=\"checkcode\" onfocus=\"if(\$_('p_imgccode').style.display == 'none'){\$_('p_imgccode').src = '" . $this->_tpl_vars["jieqi_url"] . "/checkcode.php';\$_('p_imgccode').style.display = '';}\" title=\"点击显示验证码\"><img id=\"p_imgccode\" src=\"\" style=\"cursor:pointer;vertical-align:middle;margin-left:3px;display:none;\" onclick=\"this.src='" . $this->_tpl_vars["jieqi_url"] . "/checkcode.php?rand='+Math.random();\" title=\"点击刷新验证码\"></td>\r\n</tr>\r\n";
	}

	echo "\r\n  <tr>\r\n    <td class=\"tdl\" width=\"25%\">&nbsp;<input type=\"hidden\" name=\"action\" id=\"action\" value=\"newpost\" /></td>\r\n    <td class=\"tdr\"><input type=\"submit\" name=\"Submit\" class=\"button\" value=\" 发表书评 \"></td>\r\n  </tr>\r\n</table>\r\n</form>\r\n";
}

?>
