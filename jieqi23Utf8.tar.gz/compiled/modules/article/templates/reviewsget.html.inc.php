<?php

$GLOBALS["jieqiTset"]["jieqi_page_rows"] = "20";
$this->_tpl_vars["jieqi_pagetitle"] = "{$this->_tpl_vars["articlename"]}的评论-{$this->_tpl_vars["jieqi_sitename"]}";

?>
