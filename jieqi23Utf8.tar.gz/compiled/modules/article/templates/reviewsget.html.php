<?php

echo "\r\n<div class=\"nav wrap\">\r\n    <div class=\"dropdown\">\r\n        <div class=\"btn\">\r\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\r\n</div>\r\n<div class=\"dropdown-items \">\r\n    ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \r\n</div>\r\n</div>\r\n\r\n<div class=\"wrap\">\r\n    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/666.jpg\" alt=\"\"></a>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n<div class=\"position wrap\">\r\n    <span>您的位置: </span>\r\n    <a href=\"/\">官网首页</a>\r\n    <span>></span>\r\n    <a href=\"/books\">书库</a>\r\n    <span>></span>\r\n    <a class=\"active\" href=\"\">" . $this->_tpl_vars["articlename"] . "</a>\r\n</div>\r\n\r\n<div class=\"c15\"></div>\r\n\r\n<div class=\"wrap\">\r\n    <div class=\"detail\">\r\n        <div class=\"left\">\r\n            <div class=\"comments\">\r\n                <div class=\"tit\">返回《<a href=\"" . $this->_tpl_vars["url_articleinfo"] . "\">" . $this->_tpl_vars["articlename"] . "</a>》</div>\r\n                <form action=\"" . $this->_tpl_vars["jieqi_url"] . "/reviewsget?aid=" . $this->_tpl_vars["articleid"] . "\" method=\"post\">\r\n                    <input type=\"hidden\" name=\"parent_id\" id=\"parentId\">\r\n                    <input type=\"text\" name=\"ptitle\" class=\"title\" id=\"title\" placeholder=\"评论标题\">\r\n                    <textarea name=\"pcontent\" id=\"pcontent\" placeholder=\"评论内容\"></textarea>\r\n                    <div class=\"btns\">\r\n                        <span>温馨提示: 请文明发言</span>\r\n\t\t\t\t\t\t<input type=\"hidden\" name=\"action\" id=\"action\" value=\"newpost\" />\r\n                        <input type=\"submit\" name=\"submit\" onclick=\"testnull()\" value=\"评论\">\r\n                    </div>\r\n                </form>\r\n\r\n                <div class=\"comments-tab\">\r\n                    <div class=\"bd\">\r\n                        <div class=\"comments-list-box\">\r\n\t\t\t\t\t\t\t";

if (empty($this->_tpl_vars["reviewrows"])) {
	$this->_tpl_vars["reviewrows"] = array();
}
else if (!is_array($this->_tpl_vars["reviewrows"])) {
	$this->_tpl_vars["reviewrows"] = (array) $this->_tpl_vars["reviewrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["reviewrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["reviewrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["reviewrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["reviewrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["reviewrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n                            <div class=\"comments-cell\">\r\n                                <div class=\"avatar\">\r\n                                    <a href=\"\"><img src=\"" . jieqi_geturl("system", "avatar", $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["posterid"], "s") . "\" alt=\"" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["poster"] . "\"></a>\r\n                                </div>\r\n                                <div class=\"info\">\r\n                                    <div class=\"name\"><a href=\"\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["poster"] . "：</a></div>\r\n                                    <div class=\"date\">" . date("Y-m-d H:i:s", $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["posttime"]) . " 发表</div>\r\n                                    <div class=\"cont\">" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["title"] . "</div>\r\n                                    <div class=\"btn\">\r\n                                        <a href=\"#\" class=\"reply-btn\" data-id=\"613\" data-name=\"" . $this->_tpl_vars["reviewrows"][$this->_tpl_vars["i"]["key"]]["poster"] . "  \"><i class=\"iconfont icon-groupcopy5\"></i> 回复</a>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n\t\t\t\t\t\t\t";
}

echo "\r\n                            <div class=\"pagination\">\r\n\r\n                                " . $this->_tpl_vars["url_jumppage"] . "\r\n                            </div>\r\n\r\n                        </div>\r\n\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div class=\"right\">\r\n            <div class=\"rank-component\">\r\n                <div class=\"tit\">\r\n                    <span>作者信息</span>\r\n                </div>\r\n                <div class=\"content\">\r\n                    <div class=\"author-info\">\r\n" . jieqi_get_block(array("bid" => "0", "blockname" => "关于作者", "module" => "system", "filename" => "block_uinfo", "classname" => "BlockSystemUinfo", "side" => "-1", "title" => "关于作者", "vars" => "\$authorid", "template" => "block_style_info_uinfo.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n\r\n                        <p>本书公告：";

if ($this->_tpl_vars["notice"] != "") {
	echo truncate(htmlclickable($this->_tpl_vars["notice"]), "20") . "……";
}
else {
	echo "本书尚无公告！";
}

echo "</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"c15\"></div>\r\n\r\n            <div class=\"rank-component\">\r\n                <div class=\"tit\">\r\n                    <span>作者其他作品</span>\r\n<!--                    <a href=\"\">更多 &gt;</a>-->\r\n                </div>\r\n                <div class=\"content\">\r\n                    <ul class=\"rank-ul\">\r\n" . jieqi_get_block(array("bid" => "0", "blockname" => "作者作品", "module" => "article", "filename" => "block_uarticles", "classname" => "BlockArticleUarticles", "side" => "-1", "title" => "作者作品", "vars" => "lastupdate,3,0,\$authorid", "template" => "block_style_info_uarticles.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . " \r\n                    </ul>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"c15\"></div>\r\n            <div class=\"rank-component\">\r\n                <div class=\"tit\">\r\n                    <span>热门作品</span>\r\n                    <a href=\"/book/index\">更多 &gt;</a>\r\n                </div>\r\n                <div class=\"content\">\r\n<!--                    <div class=\"rank-first\">-->\r\n<!--                        <div class=\"info\">-->\r\n<!--                            <span class=\"n1\">NO.1</span>-->\r\n<!--                            <div class=\"bt\"><a href=\"\">我是标题我是标题</a></div>-->\r\n<!--                            <p><span>2931023</span>点击</p>-->\r\n<!--                            <div class=\"author\">作者</div>-->\r\n<!--                        </div>-->\r\n<!--                        <div class=\"pic\">-->\r\n<!--                            <a href=\"\">-->\r\n<!--                                <img src=\"picture/book.png\" alt=\"\">-->\r\n<!--                            </a>-->\r\n<!--                        </div>-->\r\n<!--                    </div>-->\r\n                    <ul class=\"rank-ul\">\r\n\t\t\t\t\t\t" . jieqi_get_block(array("bid" => "0", "blockname" => "点击榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "点击榜", "vars" => "allvisit,10,0,0,0,0", "template" => "index_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n                    \r\n                    </ul>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"c15\"></div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<!--投票弹出层 S-->\r\n<div class=\"vote-box\">\r\n    <div class=\"hd\">\r\n        <ul><li>打赏</li></ul>\r\n        <span class=\"layui-layer-setwin\"><a class=\"layui-layer-ico layui-layer-close layui-layer-close1\" href=\"javascript:;\"></a></span>\r\n    </div>\r\n    <div class=\"bd\">\r\n        <div>\r\n            <div class=\"tit\">这本书太棒了，犒劳一下，希望后续更加精彩！</div>\r\n            <ul>\r\n                <li data-num=\"100\" class=\"active\"><a href=\"javascript:;\">100点</a></li>\r\n                <li data-num=\"200\"><a href=\"javascript:;\">200点</a></li>\r\n                <li data-num=\"500\"><a href=\"javascript:;\">500点</a></li>\r\n                <li data-num=\"1000\"><a href=\"javascript:;\">1000点</a></li>\r\n                <li data-num=\"2000\"><a href=\"javascript:;\">2000点</a></li>\r\n                <li data-num=\"5000\"><a href=\"javascript:;\">5000点</a></li>\r\n                <li data-num=\"10000\"><a href=\"javascript:;\">1万点</a></li>\r\n                <li data-num=\"20000\"><a href=\"javascript:;\">2万点</a></li>\r\n                <li data-num=\"50000\"><a href=\"javascript:;\">5万点</a></li>\r\n            </ul>\r\n            <p>本次打赏<span class=\"vnum\">100</span>" . $this->_tpl_vars["egoldname"] . "</p>\r\n            <div class=\"btn\">\r\n                <input name=\"reward_num\" class=\"vnumInput\" type=\"hidden\" value=\"100\">\r\n                <button type=\"button\" data-type=\"reward\">确认打赏</button>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<!--投票弹出层 E-->\r\n\r\n<script type=\"text/javascript\">\r\n        function testnull(){\r\n\t\t\tvar vname=$(\"input[name='ptitle']\").val();\r\n\t\t\tif (vname.length==0){\r\n\t\t\t\talert('null');\r\n\t\t\t\treturn;\r\n\t\t\t}\r\n\t\t};\r\n    </script>\r\n<script type=\"text/javascript\">\r\n    var isGuest = ";

if ($this->_tpl_vars["jieqi_userid"] == 0) {
	echo "true";
}
else {
	echo "false";
}

echo ";\r\n    var commentP = 1;\r\n    jQuery(\".detail-tab\").slide();\r\n    jQuery(\".comments-tab\").slide();\r\n    //打赏弹出层\r\n    jQuery(\".vote-box\").slide({trigger:\"click\"});\r\n    function showVoteBox(type){\r\n        if(isGuest) {\r\n            showLoginLayer();\r\n            return false;\r\n        }\r\n        jQuery(\".vote-box .hd ul li:eq(\"+type+\")\").trigger('click');\r\n        layer.open({\r\n            type: 1,\r\n            shadeClose: true, //开启遮罩关闭\r\n            shade: 0.5,\r\n            skin: 'book-layer-wrap',\r\n            closeBtn: 0,\r\n            title: false,\r\n            area: '500px',\r\n            content: $('.vote-box')\r\n        });\r\n    }\r\n    $(\".vote-box ul li\").on('click', function(){\r\n        $(this).siblings().removeClass('active');\r\n        $(this).addClass('active');\r\n        $(this).parent().parent().find(\".vnum\").text($(this).attr(\"data-num\"));\r\n        $(this).parent().parent().find(\".vnumInput\").val($(this).attr(\"data-num\"));\r\n    });\r\n    $(\".vote-box .btn button\").click(function () {\r\n        var acttype = $(this).attr(\"data-type\");\r\n        var num = $(this).parent().find(\".vnumInput\").val();\r\n\t\twindow.location.href=\"" . $this->_tpl_vars["jieqi_url"] . "/modules/article/tip.php?do=submit&action=post&id=" . $this->_tpl_vars["articleid"] . "&payegold=\"+num+\"\";\r\n    });\r\n\r\n    //评论回复\r\n    $(\".comments-list-box\").on('click', '.reply-btn', function () {\r\n        $(\"#parentId\").val($(this).attr('data-id'));\r\n        $(\"#title\").val(\"回复：\" + $(this).attr('data-name'));\r\n        window.scrollTo(0,1500);\r\n        return false;\r\n    });\r\n</script>\r\n    <div class=\"c15\"></div>\r\n\r\n<div class=\"notice flink wrap\">\r\n    <div class=\"channel-box\">\r\n        <div class=\"tit\">\r\n            <span>友情链接</span>\r\n        </div>\r\n        <div class=\"content\">\r\n        " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n         </div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"c15\"></div>";

?>
