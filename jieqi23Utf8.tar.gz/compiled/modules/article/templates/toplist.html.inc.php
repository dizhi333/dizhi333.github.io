<?php

$GLOBALS["jieqiTset"]["jieqi_blocks_module"] = "article";
$this->_tpl_vars["jieqi_pagetitle"] = "{$this->_tpl_vars["articletitle"]}-{$this->_tpl_vars["jieqi_sitename"]}";
$GLOBALS["jieqiTset"]["jieqi_page_rows"] = "15";

?>
