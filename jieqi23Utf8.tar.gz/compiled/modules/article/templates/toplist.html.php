<?php

if ($this->_tpl_vars["order"] == "toplist") {
	echo "\n<div class=\"nav wrap\">\n    <div class=\"dropdown\">\n        <div class=\"btn\">\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\n</div>\n<div class=\"dropdown-items \">\n";
	$_template_tpl_vars = $this->_tpl_vars;
	$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
	$this->_tpl_vars = $_template_tpl_vars;
	unset($_template_tpl_vars);
	echo " \n</div>   \n</div>\n<div class=\"wrap\">\n\n    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/666.jpg\" alt=\"\"></a>\n\n</div>\n\n\n\n<div class=\"c15\"></div>\n\n<div class=\"position wrap\">\n\n    <span>您的位置: </span>\n\n    <a href=\"#\">官网首页</a>\n\n    <span>></span>\n\n    <a class=\"active\" href=\"#\">排行榜</a>\n\n</div>\n\n\n\n<div class=\"c15\"></div>\n\n\n\n<div class=\"wrap\">\n\n    <div class=\"rank-wrap\">\n\n        <div class=\"left\">\n    <div class=\"tit\">\n        <p>详细排行榜</p>\n    </div>\n    <ul>\n\t\t";

	if (empty($this->_tpl_vars["toprows"])) {
		$this->_tpl_vars["toprows"] = array();
	}
	else if (!is_array($this->_tpl_vars["toprows"])) {
		$this->_tpl_vars["toprows"] = (array) $this->_tpl_vars["toprows"];
	}

	$this->_tpl_vars["i"] = array();
	$this->_tpl_vars["i"]["columns"] = 1;
	$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["toprows"]);
	$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["toprows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["toprows"]) % $this->_tpl_vars["i"]["columns"]));
	$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
	reset($this->_tpl_vars["toprows"]);

	for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
		$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
		$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

		if ($this->_tpl_vars["i"]["column"] == 0) {
			$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
		}

		if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
			list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["toprows"]);
			$this->_tpl_vars["i"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["i"]["key"] = "";
			$this->_tpl_vars["i"]["value"] = "";
			$this->_tpl_vars["i"]["append"] = 1;
		}

		echo "\n\t\t";

		if (0 < $this->_tpl_vars["toprows"][$this->_tpl_vars["i"]["key"]]["publish"]) {
			echo "\n        <li><a href=\"" . jieqi_geturl("article", "toplist", "1", $this->_tpl_vars["i"]["key"], $this->_tpl_vars["sortid"], $this->_tpl_vars["fullflag"]) . "\">" . $this->_tpl_vars["toprows"][$this->_tpl_vars["i"]["key"]]["caption"] . "</a></li>\n\t\t";
		}

		echo "\n\t\t";
	}

	echo "\n    </ul>\n</div>\n\n\n        <div class=\"right\">\n\n            <div class=\"rank-cell\">\n\n                <div class=\"hd\">\n\n                    <span>点击榜</span>\n\n                    <ul><li>周</li><li>月</li><li>总</li></ul>\n\n                </div>\n\n                <div class=\"bd\">\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "周点击榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "周点击榜", "vars" => "weekvisit,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n                        \n                    </ul>\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "月点击榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "月点击榜", "vars" => "monthvisit,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\n                        \n                    </ul>\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "总点击榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "总点击榜", "vars" => "allvisit,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n                        \n                    </ul>\n\n                </div>\n\n            </div>\n\n            <div class=\"rank-cell\">\n\n                <div class=\"hd\">\n\n                    <span>推荐榜</span>\n\n                    <ul><li>周</li><li>月</li><li>总</li></ul>\n\n                </div>\n\n                <div class=\"bd\">\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "周推荐榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "周推荐榜", "vars" => "weekvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\n                        \n                    </ul>\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "月推荐榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "月推荐榜", "vars" => "monthvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\n                        \n                    </ul>\n\t\t\t\t\t<ul>\n\t\t\t\t\t\n\t\t\t\t\t\t" . jieqi_get_block(array("bid" => "0", "blockname" => "总推荐榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "总推荐榜", "vars" => "allvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\t\t\t\t\t\n\t\t\t\t\t</ul>\n\n                </div>\n\n            </div>\n\n            <div class=\"rank-cell\">\n\n                <div class=\"hd\">\n\n                    <span>月票榜</span>\n\n                    <ul><li>周</li><li>月</li><li>总</li></ul>\n\n                </div>\n\n                <div class=\"bd\">\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "周月票榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "周月票榜", "vars" => "weekvipvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\n                        \n                    </ul>\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "月月票榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "月月票榜", "vars" => "monthvipvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n\n                        \n                    </ul>\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "总月票榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "总月票榜", "vars" => "allvipvote,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n                        \n                    </ul>\n\n                </div>\n\n            </div>\n\n            <div class=\"rank-cell\">\n\n                <div class=\"hd\">\n\n                    <span>新书榜</span>\n\n                </div>\n\n                <div class=\"bd\">\n\n                    <ul>\n\n                        \n                        " . jieqi_get_block(array("bid" => "0", "blockname" => "新书榜", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => "-1", "title" => "新书榜", "vars" => "postdate,10,0,0,0,0", "template" => "pc_toplist.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "</ul>\n\n                        \n                    </ul>\n\n                </div>\n\n            </div>\n\n        </div>\n\n    </div>\n\n</div>\n\n<script type=\"text/javascript\">\n\n    jQuery(\".rank-cell\").slide();\n\n</script>\n\n\n    <div class=\"c15\"></div>\n\n<div class=\"notice flink wrap\">\n    <div class=\"channel-box\">\n        <div class=\"tit\">\n            <span>友情链接</span>\n        </div>\n        <div class=\"content\">\n            " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n        </div>\n    </div>\n</div>\n\n<div class=\"c15\"></div>\n";
}
else {
	echo "\n<div class=\"nav wrap\">\n    <div class=\"dropdown\">\n        <div class=\"btn\">\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\n</div>\n<div class=\"dropdown-items \">\n    ";
	$_template_tpl_vars = $this->_tpl_vars;
	$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
	$this->_tpl_vars = $_template_tpl_vars;
	unset($_template_tpl_vars);
	echo " \n</div>\n</div>\n\n\n<div class=\"wrap\">\n    <a href=\"#\"><img src=\"" . $this->_tpl_vars["jieqi_url"] . "/tianyin/picture/banner2.png\" alt=\"\"></a>\n</div>\n\n<div class=\"c15\"></div>\n<div class=\"position wrap\">\n    <span>您的位置: </span>\n    <a href=\"#\">官网首页</a>\n    <span>></span>\n    <a class=\"active\" href=\"#\">排行榜</a>\n</div>\n\n<div class=\"c15\"></div>\n\n<div class=\"wrap\">\n    <div class=\"rank-wrap\">\n        <div class=\"left\">\n    <div class=\"tit\">\n        <p>详细排行榜</p>\n    </div>\n    <ul>\n        ";

	if (empty($this->_tpl_vars["toprows"])) {
		$this->_tpl_vars["toprows"] = array();
	}
	else if (!is_array($this->_tpl_vars["toprows"])) {
		$this->_tpl_vars["toprows"] = (array) $this->_tpl_vars["toprows"];
	}

	$this->_tpl_vars["i"] = array();
	$this->_tpl_vars["i"]["columns"] = 1;
	$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["toprows"]);
	$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["toprows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["toprows"]) % $this->_tpl_vars["i"]["columns"]));
	$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
	reset($this->_tpl_vars["toprows"]);

	for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
		$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
		$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

		if ($this->_tpl_vars["i"]["column"] == 0) {
			$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
		}

		if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
			list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["toprows"]);
			$this->_tpl_vars["i"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["i"]["key"] = "";
			$this->_tpl_vars["i"]["value"] = "";
			$this->_tpl_vars["i"]["append"] = 1;
		}

		echo "\n\t\t";

		if (0 < $this->_tpl_vars["toprows"][$this->_tpl_vars["i"]["key"]]["publish"]) {
			echo "\n        <li><a href=\"" . jieqi_geturl("article", "toplist", "1", $this->_tpl_vars["i"]["key"], $this->_tpl_vars["sortid"], $this->_tpl_vars["fullflag"]) . "\">" . $this->_tpl_vars["toprows"][$this->_tpl_vars["i"]["key"]]["caption"] . "</a></li>\n\t\t";
		}

		echo "\n\t\t";
	}

	echo "\n    </ul>\n</div>        <div class=\"right\">\n            <table cellspacing=\"0\" cellpadding=\"0\" class=\"rank-list\">\n                <thead>\n                    <th>排名</th>\n                    <th>分类</th>\n                    <th>书名</th>\n                    <th>最新章节</th>\n                    <th>作者</th>\n                    <th>更新时间</th>\n                </thead>\n                <tbody>\n\t\t\t\t\t";

	if (empty($this->_tpl_vars["articlerows"])) {
		$this->_tpl_vars["articlerows"] = array();
	}
	else if (!is_array($this->_tpl_vars["articlerows"])) {
		$this->_tpl_vars["articlerows"] = (array) $this->_tpl_vars["articlerows"];
	}

	$this->_tpl_vars["i"] = array();
	$this->_tpl_vars["i"]["columns"] = 1;
	$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["articlerows"]);
	$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["articlerows"]) % $this->_tpl_vars["i"]["columns"]));
	$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
	reset($this->_tpl_vars["articlerows"]);

	for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
		$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
		$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

		if ($this->_tpl_vars["i"]["column"] == 0) {
			$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
		}

		if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
			list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["articlerows"]);
			$this->_tpl_vars["i"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["i"]["key"] = "";
			$this->_tpl_vars["i"]["value"] = "";
			$this->_tpl_vars["i"]["append"] = 1;
		}

		echo "\n                    <tr>\n                        <td class=\"category\">" . $this->_tpl_vars["i"]["order"] . "</td>\n                        <td class=\"category\"><a href=\"" . jieqi_geturl("article", "articlelist", "1", $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["sortid"]) . "\">[" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["sort"] . "]</a></td>\n                        <td class=\"btit\"><a href=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["url_articleinfo"] . "\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["articlename"] . "</a></td>\n                        <td class=\"chapter\">\n\t\t\t\t\t\t";

		if (0 < $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["vipchapterid"]) {
			echo "\n\t\t\t\t\t\t<a href=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["url_vipchapter"] . "\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["vipchapter"] . "<span>VIP</span></a>\n\t\t\t\t\t\t";
		}
		else {
			echo "\n\t\t\t\t\t\t<a href=\"" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["url_lastchapter"] . "\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["lastchapter"] . "</a>\n\t\t\t\t\t\t";
		}

		echo "\n\t\t\t\t\t\t</td>\n                        <td class=\"author\">" . $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["author"] . "</td>\n                        <td class=\"date\">" . date("Y-m-d H:i:s", $this->_tpl_vars["articlerows"][$this->_tpl_vars["i"]["key"]]["lastupdate"]) . "</td>\n                    </tr>\n\t\t\t\t\t";
	}

	echo "\n                </tbody>\n            </table>\n            <div class=\"pagination\">\n\t\t\t" . $this->_tpl_vars["url_jumppage"] . "\n\t\t\t</div>\n\t\t</div>\n    </div>\n</div>\n\n    <div class=\"c15\"></div>\n\n<div class=\"notice flink wrap\">\n    <div class=\"channel-box\">\n        <div class=\"tit\">\n            <span>友情链接</span>\n        </div>\n        <div class=\"content\">\n            " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\n        </div>\n    </div>\n</div>\n\n<div class=\"c15\"></div>\n";
}

?>
