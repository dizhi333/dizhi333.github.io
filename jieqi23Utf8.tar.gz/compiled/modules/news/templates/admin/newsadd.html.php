<?php
echo '<br />
'.$this->_tpl_vars['news_add'].'
<br />
<br />
';
?>