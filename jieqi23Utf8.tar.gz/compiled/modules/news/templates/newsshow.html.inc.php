<?php

$GLOBALS["jieqiTset"]["jieqi_blocks_module"] = "news";
$GLOBALS["jieqiTset"]["jieqi_blocks_config"] = "guideblocks";

?>
