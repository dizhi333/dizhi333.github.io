<?php

echo "\r\n<div class=\"nav wrap\">\r\n    <div class=\"dropdown\">\r\n        <div class=\"btn\">\r\n    <i class=\"iconfont icon-caidan\"></i> 作品分类\r\n</div>\r\n<div class=\"dropdown-items \">\r\n    ";
$_template_tpl_vars = $this->_tpl_vars;
$this->_template_include(array(
				s => "templates/menu.html",
				s => array()
	));
$this->_tpl_vars = $_template_tpl_vars;
unset($_template_tpl_vars);
echo " \r\n</div>\r\n</div>\r\n\r\n\r\n<div class=\"c15\"></div>\r\n<div class=\"wrap news\">\r\n    <div class=\"content\">\r\n        <p class=\"title\">" . $this->_tpl_vars["title"] . "</p>\r\n\t\t" . $this->_tpl_vars["body"] . "\r\n\t </div>\r\n</div>\r\n    <div class=\"c15\"></div>\r\n\r\n<div class=\"notice flink wrap\">\r\n    <div class=\"channel-box\">\r\n        <div class=\"tit\">\r\n            <span>友情链接</span>\r\n        </div>\r\n        <div class=\"content\">\r\n            " . jieqi_get_block(array("bid" => "0", "blockname" => "友情链接", "module" => "link", "filename" => "block_linklist", "classname" => "BlockLinkLinklist", "side" => "-1", "title" => "友情链接", "vars" => "10,2,0,64", "template" => "link_list.html", "contenttype" => "4", "custom" => "0", "publish" => "3", "hasvars" => "1"), 1) . "\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<div class=\"c15\"></div>";

?>
