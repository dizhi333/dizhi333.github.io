<?php

echo "<form name=\"frmsearch\" action=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/buylog.php\" method=\"get\">\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n  <tr>\r\n    <td>\r\n\t<span class=\"hottext fr\">总记录：" . $this->_tpl_vars["osalestat"]["cot"] . "， 总金额：" . $this->_tpl_vars["osalestat"]["sumsaleprice"] . "</span>\r\n\t用户名： <input name=\"uname\" type=\"text\" class=\"text\" size=\"15\" value=\"" . $this->_tpl_vars["_request"]["uname"] . "\">\r\n\t小说名： <input name=\"aname\" type=\"text\" class=\"text\" size=\"15\" value=\"" . $this->_tpl_vars["_request"]["aname"] . "\">\r\n\t动作日期：<input name=\"datestart\" type=\"text\" class=\"text\" size=\"10\" maxlength=\"10\" value=\"" . $this->_tpl_vars["_request"]["datestart"] . "\">-<input name=\"dateend\" type=\"text\" class=\"text\" size=\"10\" maxlength=\"10\" value=\"" . $this->_tpl_vars["_request"]["dateend"] . "\">\r\n    <input type=\"submit\" name=\"btnsearch\" class=\"button\" value=\"搜 索\">\r\n    <input type=\"hidden\" name=\"act\" value=\"tip\">\r\n\t日期格式：2012-05-06\r\n  </tr>\r\n</table>\r\n</form>\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n<caption>VIP订阅记录</caption>\r\n  <tr align=\"center\">\r\n    <th width=\"20%\">小说名称</th>\r\n    <th width=\"35%\">章节</th>\r\n    <th width=\"10%\">价格</th>\r\n    <th width=\"15%\">用户名</th>\r\n    <th width=\"20%\">购买日期</th>\r\n  </tr>\r\n  ";

if (empty($this->_tpl_vars["osalerows"])) {
	$this->_tpl_vars["osalerows"] = array();
}
else if (!is_array($this->_tpl_vars["osalerows"])) {
	$this->_tpl_vars["osalerows"] = (array) $this->_tpl_vars["osalerows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["osalerows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["osalerows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["osalerows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["osalerows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["osalerows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n  <tr>\r\n    <td><a href=\"" . jieqi_geturl("article", "article", $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["articleid"], "info") . "\" target=\"_blank\">" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["obookname"] . "</a></td>\r\n    <td><a href=\"" . $this->_tpl_vars["obook_static_url"] . "/reader.php?oid=" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["obookid"] . "&cid=" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["ochapterid"] . "\" target=\"_blank\">" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["chaptername"] . "</a></td>\r\n    <td align=\"center\">" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["saleprice"] . "</td>\r\n    <td align=\"center\"><a href=\"" . jieqi_geturl("system", "user", $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["accountid"]) . "\" target=\"_blank\">" . $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["account"] . "</a></td>\r\n    <td align=\"center\">" . date("Y-m-d H:i:s", $this->_tpl_vars["osalerows"][$this->_tpl_vars["i"]["key"]]["buytime"]) . "</td>\r\n  </tr>\r\n  ";
}

echo "\r\n</table>\r\n<div class=\"pages\">" . $this->_tpl_vars["url_jumppage"] . "</div>\r\n\r\n";

?>
