<?php

echo "\r\n<form name=\"frmsearch\" method=\"get\" action=\"" . $this->_tpl_vars["url_salestat"] . "\">\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n    <tr>\r\n      <td>关键字：\r\n            <input name=\"keyword\" type=\"text\" id=\"keyword\" class=\"text\" size=\"15\" maxlength=\"50\"> \r\n            <input name=\"keytype\" type=\"radio\" class=\"radio\" value=\"0\" checked=\"checked\">书名\r\n            <input type=\"radio\" name=\"keytype\" class=\"radio\" value=\"1\">作者 \r\n\t\t\t<input type=\"radio\" name=\"keytype\" class=\"radio\" value=\"2\">发表者 \r\n\t\t\t&nbsp;&nbsp;\r\n            <input type=\"submit\" name=\"btnsearch\" class=\"button\" value=\"搜 索\">\r\n        &nbsp;&nbsp;&nbsp;</td>\r\n    </tr>\r\n</table>\r\n</form>\r\n<table class=\"grid\" width=\"100%\" align=\"center\">\r\n<caption>\r\n<a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/salestat.php\">显示全部</a>\r\n";

if (0 < count($this->_tpl_vars["jieqisites"])) {
	echo "\r\n | <a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/salestat.php?siteid=0\">本站原创</a>\r\n";

	if (empty($this->_tpl_vars["jieqisites"])) {
		$this->_tpl_vars["jieqisites"] = array();
	}
	else if (!is_array($this->_tpl_vars["jieqisites"])) {
		$this->_tpl_vars["jieqisites"] = (array) $this->_tpl_vars["jieqisites"];
	}

	$this->_tpl_vars["i"] = array();
	$this->_tpl_vars["i"]["columns"] = 1;
	$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["jieqisites"]);
	$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["jieqisites"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["jieqisites"]) % $this->_tpl_vars["i"]["columns"]));
	$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
	reset($this->_tpl_vars["jieqisites"]);

	for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
		$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
		$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

		if ($this->_tpl_vars["i"]["column"] == 0) {
			$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
		}

		if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
			list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["jieqisites"]);
			$this->_tpl_vars["i"]["append"] = 0;
		}
		else {
			$this->_tpl_vars["i"]["key"] = "";
			$this->_tpl_vars["i"]["value"] = "";
			$this->_tpl_vars["i"]["append"] = 1;
		}

		echo " | <a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/salestat.php?siteid=" . $this->_tpl_vars["i"]["key"] . "\">" . $this->_tpl_vars["jieqisites"][$this->_tpl_vars["i"]["key"]]["name"] . "</a>";
	}
}

echo "\r\n</caption>\r\n  <tr align=\"center\">\r\n    <th width=\"11%\">电子书名称</th>\r\n    <th width=\"8%\">作者</th>\r\n\t<th width=\"7%\">发表者</th>\r\n\t<th width=\"5%\">分成百分比</th>\r\n\t<th width=\"7%\">收款银行</th>\r\n\t<th width=\"10%\">收款账号</th>\r\n\t<th width=\"8%\">收款人</th>\r\n    <th width=\"5%\">订阅</th>\r\n\t<th width=\"6%\">打赏</th>\r\n\t<th width=\"5%\">礼物</th>\r\n\t<th width=\"5%\">催更</th>\r\n    <th width=\"5%\">总收入</th>\r\n\t<th width=\"5%\">待结算</th>\r\n    <th width=\"21%\">操作</th>\r\n  </tr>\r\n  ";

if (empty($this->_tpl_vars["obookrows"])) {
	$this->_tpl_vars["obookrows"] = array();
}
else if (!is_array($this->_tpl_vars["obookrows"])) {
	$this->_tpl_vars["obookrows"] = (array) $this->_tpl_vars["obookrows"];
}

$this->_tpl_vars["i"] = array();
$this->_tpl_vars["i"]["columns"] = 1;
$this->_tpl_vars["i"]["count"] = count($this->_tpl_vars["obookrows"]);
$this->_tpl_vars["i"]["addrows"] = ((count($this->_tpl_vars["obookrows"]) % $this->_tpl_vars["i"]["columns"]) == 0 ? 0 : $this->_tpl_vars["i"]["columns"] - (count($this->_tpl_vars["obookrows"]) % $this->_tpl_vars["i"]["columns"]));
$this->_tpl_vars["i"]["loops"] = $this->_tpl_vars["i"]["count"] + $this->_tpl_vars["i"]["addrows"];
reset($this->_tpl_vars["obookrows"]);

for ($this->_tpl_vars["i"]["index"] = 0; $this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["loops"]; $this->_tpl_vars["i"]["index"]++) {
	$this->_tpl_vars["i"]["order"] = $this->_tpl_vars["i"]["index"] + 1;
	$this->_tpl_vars["i"]["row"] = ceil($this->_tpl_vars["i"]["order"] / $this->_tpl_vars["i"]["columns"]);
	$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["order"] % $this->_tpl_vars["i"]["columns"];

	if ($this->_tpl_vars["i"]["column"] == 0) {
		$this->_tpl_vars["i"]["column"] = $this->_tpl_vars["i"]["columns"];
	}

	if ($this->_tpl_vars["i"]["index"] < $this->_tpl_vars["i"]["count"]) {
		list($this->_tpl_vars["i"]["key"], $this->_tpl_vars["i"]["value"]) = each($this->_tpl_vars["obookrows"]);
		$this->_tpl_vars["i"]["append"] = 0;
	}
	else {
		$this->_tpl_vars["i"]["key"] = "";
		$this->_tpl_vars["i"]["value"] = "";
		$this->_tpl_vars["i"]["append"] = 1;
	}

	echo "\r\n  <tr>\r\n    <td><a href=\"" . jieqi_geturl("article", "article", $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["articleid"], "info") . "\" target=\"_blank\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["obookname"] . "</a></td>\r\n    <td>";

	if ($this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["authorid"] == 0) {
		echo $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["author"];
	}
	else {
		echo "<a href=\"" . $this->_tpl_vars["jieqi_url"] . "/admin/personmanage.php?id=" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["authorid"] . "\" target=\"_blank\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["author"] . "</a>";
	}

	echo "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["poster"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["divided"] . "%</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["banktype"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["bankcard"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["bankuser"] . "</td>\r\n    <td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["sumegold"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["sumtip"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["sumgift"] . "</td>\r\n\t<td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["sumhurry"] . "</td>\r\n    <td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["sumemoney"] . "</td>\r\n    <td align=\"center\">" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["remainemoney"] . "</td>\r\n    <td align=\"center\"><a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/chapterstat.php?oid=" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["obookid"] . "\">章节销售</a> | <a href=\"" . $this->_tpl_vars["jieqi_modules"]["article"]["url"] . "/admin/actlog.php?aid=" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["articleid"] . "\">打赏记录</a> | <a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/paidlog.php?oid=" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["obookid"] . "\">结算记录</a> | <a href=\"" . $this->_tpl_vars["obook_dynamic_url"] . "/admin/paidnew.php?oid=" . $this->_tpl_vars["obookrows"][$this->_tpl_vars["i"]["key"]]["obookid"] . "\">结算</a></td>\r\n  </tr>\r\n  ";
}

echo "\r\n</table>\r\n<div class=\"pages\">" . $this->_tpl_vars["url_jumppage"] . "</div>";

?>
