<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'system';
$this->_tpl_vars['jieqi_pagetitle'] = "订阅记录-{$this->_tpl_vars['jieqi_sitename']}";
$GLOBALS['jieqiTset']['jieqi_page_rows'] = '30';

?>