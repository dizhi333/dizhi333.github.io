<?php

$GLOBALS["jieqiTset"]["jieqi_blocks_module"] = "obook";
$GLOBALS["jieqiTset"]["jieqi_page_rows"] = "30";

?>
