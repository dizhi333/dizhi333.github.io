<?php
echo '<br>
<table class="grid" width="80%" align="center">
  <caption>生成充值点卡</caption>
<form name="form1" method="post" action="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/admin/makepaycard.php">
  <tr>
    <td width="29%" align="right">充值卡批号：</td>
    <td width="71%"><input name="batchno" type="text" id="batchno" size="20" maxlength="11" class="text"> 
    即卡号的前面部分，允许留空</td>
  </tr>
  <tr>
    <td align="right">起始序号：</td>
    <td><input name="startid" type="text" id="startid" size="20" maxlength="11" class="text" /> 
      必须是数字</td>
  </tr>
  <tr>
    <td align="right">结束序号：</td>
    <td><input name="endid" type="text" id="endid" size="20" maxlength="11" class="text" />
必须是数字，结束序号必须大于等于起始序号</td>
  </tr>
  <tr>
    <td align="right">卡号长度：</td>
    <td><input name="cardlen" type="text" id="cardlen" size="20" maxlength="11" class="text" />
必须是数字，最长不超过30位</td>
  </tr>
  <tr>
    <td align="right">密码长度：</td>
    <td><input name="passlen" type="text" id="passlen" size="20" maxlength="11" class="text">
必须是数字，最长不超过30位</td>
  </tr>
  <tr>
    <td align="right">密码格式：</td>
    <td><input name="passtype" type="radio" value="1" checked="checked" />
      全数字 
        <input type="radio" name="passtype" value="2" />
      全字母 
      <input type="radio" name="passtype" value="3" />
      数字字母混合</td>
  </tr>
  <tr>
    <td align="right">充值金额：</td>
    <td><input name="payemoney" type="text" id="payemoney" size="20" maxlength="11" class="text"> 
    '.$this->_tpl_vars['egoldname'].'，必须是数字</td>
  </tr>
  
  <tr>
    <td colspan="2">说明：比如批号是 abc123 ，起始序号 0 ，结束序号 99，卡号长度 10 ，则生成的卡号为从 abc1230000 到 abc1230099 。</td>
    </tr>
  <tr>
    <td align="right"><input name="action" type="hidden" value="makepaycard" /></td>
    <td><input type="submit" name="make1" value="开始生成" class="button"></td>
  </tr>
  <tr>
    <td colspan="2" align="right" class="foot">&nbsp;</td>
  </tr>
  </form>
</table>

<br>
<br>
';
?>