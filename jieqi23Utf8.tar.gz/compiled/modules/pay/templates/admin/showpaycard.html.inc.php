<?php
$GLOBALS['jieqiTset']['jieqi_page_rows'] = '100';

?>