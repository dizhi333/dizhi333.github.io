<?php

echo "<html><head><meta http-equiv=\"refresh\" content=\"0;url=" . $this->_tpl_vars["url_pay"] . "\"></head><body></body></html>";

?>
