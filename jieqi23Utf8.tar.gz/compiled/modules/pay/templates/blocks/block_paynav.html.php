<?php

echo "<div>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=yeepaypay\">网上银行充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=alipaypay\">支付宝充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=yeemobilepay\">手机充值卡充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=yeegamepay\">游戏点卡充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=qqpay\">手机QQ充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=weixinpay\">微信充值</a>\r\n  <a class=\"btnlink\" href=\"buyegold.php?t=remitpay\">人工汇款充值</a>\r\n</div>";

?>
