<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'pay';
$this->_tpl_vars['jieqi_pagetitle'] = "支付宝充值-{$this->_tpl_vars['jieqi_sitename']}";

?>