<?php
echo '
<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="">官网首页</a>
    <span>></span>
    <a class="active" href="">个人中心</a>
</div>

<div class="c15"></div>


<div class="wrap">
    <div class="customer-wrap">

        <div class="menu">
    <div class="intro">
        <div class="avatar">
            <img src="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" alt="'.$this->_tpl_vars['jieqi_username'].'" onerror="this.src=\''.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'\'" />
        </div>
        <p>'.$this->_tpl_vars['name'].'</p>
		<div class="icon">
            <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/level/'.$this->_tpl_vars['jieqi_group'].'.png" alt=""></a>
        </div>

        <div class="c15"></div>
        <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/line0.png" alt=""></a>
    </div>
    <div class="acts">
        ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/usernav.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
    </div>

    <div class="btns">
                    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/sign.png" alt=""></a>
        <!--        <a href=""><img src="/images/service.png" alt=""></a>-->
    </div>
</div>
        <div class="content">
            <div class="actions">
                <ul>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/useraccount.php">账户信息</a></li>
					<li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/paylog.php">充值记录</a></li>
					<li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_modules']['obook']['url'].'/buylist.php">消费记录</a></li>
					<li><span>|</span></li>
                    <li class="active"><a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php">在线充值</a></li>
                </ul>
            </div>

            <div class="c15"></div>

           <div class="customer-recharge">
                <div class="balance">
                    '.$this->_tpl_vars['egoldname'].'充值
                </div>

                <div class="payment">
                    <form id="recharge-form" action="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/alipay.php" method="post" role="form">
                   <div class="tit">
                        <span>支付方式</span>
                        <em>最低10元</em>
                    </div>

                    <div class="items payment-choose">
                        <input type="hidden" name="payment" value="alipay">
                        <a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php" class="active" data-id="alipay">
                            <i class="iconfont icon-alipay"></i> 支付宝
                        </a>
                        <a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php?t=weixinpay" data-id="wechat">
                            <i class="iconfont icon-wechat"></i> 微信
                        </a>
						<a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php?t=paycardpay" data-id="paycardpay">
                            <i class="iconfont icon-shezhi"></i> 卡密
                        </a>
                    </div>

                    <div class="money">
                            <span>
                                <input type="radio" name="egold" value="1000" checked="checked" id="m10">
                                <label for="m10">10元</label>
                            </span>
                        <span>
                                <input type="radio" name="egold" value="200" id="m20">
                                <label for="m20">20元</label>
                            </span>
                        <span>
                                <input type="radio" name="egold" value="500" id="m30">
                                <label for="m30">50元</label>
                            </span>
                        <span>
                                <input type="radio" name="egold" value="1000" id="m40">
                                <label for="m40">100元</label>
                            </span>
                        <span>
                                <input type="radio" name="egold" value="2000" id="m50">
                                <label for="m50">200元</label>
                            </span>
                        <span>
                                <input type="radio" name="egold" value="5000" id="m100">
                                <label for="m100">500元</label>
                            </span>
                    </div>

                    <div class="btns">
                        <input type="submit" name="submit" value="提交">
                    </div>
                    </form>                </div>

                <div class="notice">
                    提示:
                    <p>人民币充值<span>'.$this->_tpl_vars['egoldname'].'</span>比例: <span>1:100</span></p>
                </div>
            </div>



 
        </div>
    </div>
</div>

    <div class="c15"></div>
<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>';
?>