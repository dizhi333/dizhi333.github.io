<?php

$GLOBALS["jieqiTset"]["jieqi_blocks_module"] = "pay";
$GLOBALS["jieqiTset"]["jieqi_blocks_config"] = "payblocks";
$this->_tpl_vars["jieqi_pagetitle"] = "充值卡充值-{$this->_tpl_vars["jieqi_sitename"]}";

?>
