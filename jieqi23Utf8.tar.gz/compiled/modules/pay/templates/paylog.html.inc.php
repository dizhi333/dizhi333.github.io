<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'pay';
$this->_tpl_vars['jieqi_pagetitle'] = "充值记录-{$this->_tpl_vars['jieqi_sitename']}";

?>