<?php

$this->_tpl_vars["jieqi_pagetitle"] = "微信充值-{$this->_tpl_vars["jieqi_sitename"]}";

?>
