 <?php require(dirname(__FILE__)."/configs/function.php");
if($anleye_domain != ( constant("JIEQI_LICENSE_KEY") ))
{
	header("Location:http://pic.host7.52jscn.com/shouquan.html");
	exit;
}

</head>
<body >
<div id="content" style="margin-top:80px;"><table class="grid" width="60%" align="center">
 <caption>系统授权信息</caption>
 <tr>
   <td class="tdl" width="35%">授权状态</td>
   <td class="tdr" width="65%">恭喜您，您已经获得VIP授权</td>
 </tr>
 <tr>
   <td class="tdl">系统版本</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 <tr>
   <td colspan="2" class="title" align="center">模块版本</td>
 </tr>
 
 <tr>
   <td class="tdl">用户徽章</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">新闻发布</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">友情链接</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">交流论坛</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">在线充值</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">VIP电子书</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td class="tdl">小说连载</td>
   <td class="tdr">2.30 <font color="#FF0000">锦尚中国VIP会员版</font></td>
 </tr>
 
 <tr>
   <td colspan="2" class="foot" align="center">Powered by <strong><a href="http://bbs.52jscn.com" target="_blank">锦尚中国</a></strong></td>
 </tr>
</table>
?>