<?php
if($this->_tpl_vars['ownerid'] > 0){
echo '
                        <div class="avatar">
                            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/authorpage.php?name='.$this->_tpl_vars['name'].'"><img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['uid'],'s',$this->_tpl_vars['avatar']).'" alt="'.$this->_tpl_vars['name'].'"></a>
                            <p>作者：'.$this->_tpl_vars['name'].'</p>
                        </div>
';
}else{
echo '
                        <div class="avatar">
                            <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['uid'],'s',$this->_tpl_vars['avatar']).'" alt="'.$this->_tpl_vars['name'].'">
                          <p>作者：暂无</p>
                        </div>
';
}

?>