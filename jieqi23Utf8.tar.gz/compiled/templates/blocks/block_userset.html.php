<?php
echo '<ul class="ulnav">
<li><a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">用户资料</a></li>
<li><a href="'.$this->_tpl_vars['jieqi_url'].'/useredit.php">修改资料</a></li>
<li><a href="'.$this->_tpl_vars['jieqi_url'].'/setavatar.php">设置头像</a></li>
<li><a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php">修改密码</a></li>
<li><a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php">退出登录</a></li>
</ul>';
?>