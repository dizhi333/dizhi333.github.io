<?php
echo '<div class="novel-home-body-container" >
    <div class="container container-box-shadow" style="margin-bottom:40px;">

        <div class="clearfix">

            <div class="user-register">
                <div class="title-header-tip clearfix">找回密码</div>
                <form class="user-my-infor"  name="frmgetpass" id="frmgetpass" method="post" action="getpass.php?do=submit" onsubmit="return frmpassedit_validate();" style="margin-left: 56px;">
                    <div class="clearfix" style="margin-top:40px;">
                        <div class="form-left" style="width: 120px">用户名：</div>
                        <div class="form-right">
                            <div class="form-input">
                               <input type="text" name="uname" id="uname" size="25" maxlength="30" value="" />
                            </div>
                        </div>
                        <div class="form-tips" style="display:none">我是错误提示</div>
                    </div>
                    <div class="clearfix" style="margin-top:20px;">
                        <div class="form-left" style="width: 120px">邮箱（Email）：</div>
                        <div class="form-right">
                            <div class="form-input">
                                <input type="text" name="email" id="email" size="25" maxlength="60" value="" />
                            </div>
                        </div>
                    </div>
                    <div class="clearfix" style="margin-top:20px;">
                        <div class="form-left" style="width: 120px">&nbsp;<input type="hidden" name="action" id="action" value="sendpass" /></div>
                        <div class="form-save">
                             <input type="submit" name="submit" value="提交"/>
                        </div>
                    </div>
                </form>
            </div>
			<div class="novel-right author-message">
              <div class="message-tip">

                <h2>说明：</h2>
                <p>提交以下信息并后，请查看您的邮箱，根据提示的链接返回本站重新设定密码。</p>
              </div>
            </div>

        </div>
    </div>
</div>
<script type="text/javascript">
layer.ready(function(){
		$(\'#frmgetpass\').on(\'submit\', function(e){
		e.preventDefault();
		var i = layer.load(0);
				GPage.postForm(\'frmgetpass\', $("#frmgetpass").attr("action"),
			   function(data){
					if(data.status==\'OK\'){
					    layer.msg(data.msg,{icon: 6},function(){});
						$.ajaxSetup ({ cache: false });
						jumpurl(data.jumpurl);
					}else{
					    layer.close(i);
						layer.alert(data.msg, {icon: 5}, !1);
					}
			   });
//			}
		});
});
$(\'#recode\').click(function(){
	$(\'#checkcode\').attr(\'src\',\''.$this->_tpl_vars['jieqi_url'].'/checkcode.php?rand=\'+Math.random());
});
</script>';
?>