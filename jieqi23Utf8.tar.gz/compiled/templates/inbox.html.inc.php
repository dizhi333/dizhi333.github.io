<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'system';
$GLOBALS['jieqiTset']['jieqi_page_rows'] = '30';
$this->_tpl_vars['jieqi_pagetitle'] = "消息中心-{$this->_tpl_vars['jieqi_sitename']}";

?>