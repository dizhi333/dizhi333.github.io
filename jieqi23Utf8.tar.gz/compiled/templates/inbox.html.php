<?php
echo '
<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="">官网首页</a>
    <span>></span>
    <a class="active" href="">个人中心</a>
</div>

<div class="c15"></div>


<div class="wrap">
    <div class="customer-wrap">

        <div class="menu">
    <div class="intro">
        <div class="avatar">
            <img src="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" alt="'.$this->_tpl_vars['jieqi_username'].'" onerror="this.src=\''.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'\'" />
        </div>
        <p>'.$this->_tpl_vars['name'].'</p>
		<div class="icon">
            <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/level/'.$this->_tpl_vars['jieqi_group'].'.png" alt=""></a>
        </div>

        <div class="c15"></div>
        <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/line0.png" alt=""></a>
    </div>
    <div class="acts">
        ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/usernav.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
    </div>

    <div class="btns">
                    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/sign.png" alt=""></a>
        <!--        <a href=""><img src="/images/service.png" alt=""></a>-->
    </div>
</div>

        <div class="content">
            <div class="actions">
                <ul>
					<li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=inbox">收件箱</a></li>
					<!--
					<li><span>|</span></li>
					<li ><a href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=outbox">发件箱</a></li>
					-->
				</ul>
            </div>

            <div class="c15"></div>
			<div class="customer-bookshelf">
                <table border="0" cellspacing="0" cellpadding="0">
                    <thead>
                    <th>留言内容</th>
                    <th>'.$this->_tpl_vars['usertitle'].'</th>
                    <th>时间</th>
                    <th>状态</th>
                    <th>操作</th>
                    </thead>
                    <tbody>
					';
if (empty($this->_tpl_vars['messagerows'])) $this->_tpl_vars['messagerows'] = array();
elseif (!is_array($this->_tpl_vars['messagerows'])) $this->_tpl_vars['messagerows'] = (array)$this->_tpl_vars['messagerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['messagerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['messagerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['messagerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['messagerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['messagerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
                        <tr>
                        <td><a href="'.$this->_tpl_vars['jieqi_url'].'/messagedetail.php?id='.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['messageid'].'">'.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['title'].'</a></td>
						<td>';
if($this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['fromid'] > 0){
echo $this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['fromname'];
}else{
echo '网站管理员';
}
echo '</td>
						<td>'.date('Y-m-d H:i:s',$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['postdate']).'</td>
						<td>';
if($this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['isread'] == 0){
echo '<span style="color:#f10">未读</span>';
}else{
echo '已读';
}
echo '</td>
						<td><a href="'.$this->_tpl_vars['url_delete'].'">删除</a></td>
						</tr>
					';
}
echo '
                    </tbody>
                </table>
                
            </div>

        </div>
 
        </div>
    </div>
</div>

    <div class="c15"></div>
<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>
';
?>