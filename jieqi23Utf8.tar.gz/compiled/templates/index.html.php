<?php
echo '<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items active">
';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>


<div class="banner-box wrap">
    <div class="slide">
        <div id="slideBox" class="slideBox">
            <div class="hd">
                <ul>
                                        <li>1</li>
                                        <li>2</li>
                                        <li>3</li>
                                        <li>4</li>
                                    </ul>
            </div>
            <div class="bd">
                <ul>
                                        <li><a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/61655a3cd9357b522.jpg" /></a></li>
                                        <li><a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/93565a1795084fe8b.jpg" /></a></li>
                                        <li><a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/63615a17dcb39a2f0.jpg" /></a></li>
                                        <li><a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/99285a17dcc526321.jpg" /></a></li>
                                    </ul>
            </div>
        </div>
    </div>

    <div class="lunbo">
        <div class="lunbo-box">

            <div class="bd">
                <ul class="picList">
                    '.$this->_tpl_vars['jieqi_pageblocks']['0']['content'].'
                </ul>
            </div>

            <a class="next"></a>
            <a class="prev"></a>
        </div>
    </div>
</div>

<div class="c15"></div>

<div class="notice wrap">
    <div class="channel-box">
        <div class="tit">
            <span><i class="iconfont icon-laba"></i> 最新公告</span>
        </div>
        <div class="content">
            <ul>
				'.$this->_tpl_vars['jieqi_pageblocks']['1']['content'].'
            </ul>
        </div>
    </div>
</div>

<div class="c15"></div>

<div class="channel-wrap wrap quality">
    <div class="channel-box">
        <div class="tit">
            <span><i class="iconfont icon-jingpinluxian"></i> 精品推荐</span>
        </div>
        <div class="content">
            '.$this->_tpl_vars['jieqi_pageblocks']['2']['content'].'

            <div class="lists">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['3']['content'].'

                </ul>
            </div>
        </div>
    </div>

    <div class="rank">
        <div class="tit">
            <span>本周强推</span>
            <!--<a href="/rank/index">更多 ></a>-->
        </div>
        <div class="content">
          
            '.$this->_tpl_vars['jieqi_pageblocks']['4']['content'].'
            </ul>
        </div>
    </div>
</div>

<div class="c15"></div>

<div class="wrap">
    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/666.jpg" alt=""></a>
</div>

<div class="c15"></div>

<div class="channel-wrap wrap people-recommended">
    <div class="channel-box">
        <div class="tit">
            <span>口碑推荐</span>
        </div>
        <div class="content">
            <div class="horizontal">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['5']['content'].'
                </ul>
            </div>

            <div class="vertical">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['6']['content'].'
                </ul>
            </div>
        </div>
    </div>

    <div class="rank">
        <div class="tit">
            <span>人气榜</span>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/books">更多 ></a>
        </div>
        <div class="content">
            <div class="rank-tab">
                <div class="hd">

                    <ul><li>周榜</li><li>月榜</li><li>总榜</li></ul>
                </div>
                <div class="bd">
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['7']['content'].'
                    </ul>
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['8']['content'].'
                    </ul>
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['9']['content'].'
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="c15"></div>

<div class="channel-wrap wrap people-recommended">
    <div class="channel-box">
        <div class="tit">
            <span>畅销推荐</span>
        </div>
        <div class="content">
            <div class="horizontal">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['10']['content'].'
                </ul>
            </div>

            <div class="vertical">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['11']['content'].'
                 </ul>
            </div>
        </div>
    </div>

    <div class="rank">
        <div class="tit">
            <span>推荐榜</span>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/books">更多 ></a>
        </div>
        <div class="content">
            <div class="rank-tab">
                <div class="hd">
                    <ul><li>周榜</li><li>月榜</li><li>总榜</li></ul>
                </div>
                <div class="bd">
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['12']['content'].'
                    </ul>
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['13']['content'].'
                    </ul>
                    <ul>
                        '.$this->_tpl_vars['jieqi_pageblocks']['14']['content'].'
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="c15"></div>

<div class="wrap">
    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/666.jpg" alt=""></a>
</div>

<div class="c15"></div>

<div class="latest wrap">
    <div class="channel-box">
        <div class="tit">
            <span>最近更新</span>
            <div class="btns">
                <a href="'.$this->_tpl_vars['jieqi_url'].'/books">更多 ></a>
            </div>
        </div>
        <div class="content">
            <div class="left">
                <ul>
                    '.$this->_tpl_vars['jieqi_pageblocks']['15']['content'].'
                </ul>
            </div>
            <div class="right">
                <table cellspacing="0" cellpadding="0">
                    '.$this->_tpl_vars['jieqi_pageblocks']['16']['content'].'
                </table>
            </div>
        </div>
    </div>
</div>

    <div class="c15"></div>

<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.$this->_tpl_vars['jieqi_pageblocks']['17']['content'].'
        </div>
    </div>
</div>

<div class="c15"></div>';
?>