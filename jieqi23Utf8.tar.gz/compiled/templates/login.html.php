<?php
echo '<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="/">官网首页</a>
    <span>></span>
    <a class="active" href="">用户登录</a>
</div>

<div class="c15"></div>



<div class="wrap">
    <div class="register-wrap">
        <div class="content" style="min-height: 332px">
            <div class="tit"><span>用户登录</span></div>

            <form id="login-form" action="'.$this->_tpl_vars['url_login'].'" method="post" role="form">
<input type="hidden" name="_csrf-frontend" value="VDd3M19CUFMwZxZWDSwgKzphPHkzCTphJQ4neg8xaWBmUDZHHAEBGQ==">
            <div class="register-cell" style="margin-top: 15px;">
                <div class="name">账号: </div>
                <div class="info">
                    <input class="txt" type="text" name="username" value="">
                    <p>请输入账号</p>
                </div>
            </div>

            <div class="register-cell">
                <div class="name">密码: </div>
                <div class="info">
                    <input class="txt" type="password" name="password" value="">
                    <p>请输入密码</p>
                </div>
            </div>
            <div class="register-cell">
                <div class="name"></div>
                <div class="info">
					<input type="hidden" name="action" value="login">
                    <input class="btn" type="submit" value="登录">
                </div>
            </div>
            
            </form>			<p style="text-align:center"><a href="'.$this->_tpl_vars['url_getpass'].'" style="font-size: 14px;color:#ff0000">找回密码></a></p>
			<p style="text-align:center"><a href="#" style="font-size: 14px;color:#ff0000">无法登陆？请看这里></a></p>
        </div>

        <div class="other">
            <p>没有账号立即注册</p>
            <a href="'.$this->_tpl_vars['url_register'].'" class="btn">立即注册</a>

            <p>您也可以使用其他账号登录: </p>
            <div id="w0"><ul class="auth-clients">
			<li><a class="qq auth-link" href="/api/qq/login.php" title="QQ 登录"><span class="auth-icon qq"></span></a></li>
			<li><a class="wechat auth-link" href="/api/weixin/login.php" title="Wechat"><span class="auth-icon wechat"></span></a></li>
			<!--<li><a class="weibo auth-link" href="/api/weibo/login.php" title="weibo"><span class="auth-icon weibo"></span></a></li>-->
			</ul>
			</div>
			</div>
    </div>
</div>
<div id="wx_login" style="display: none"></div>
    <div class="c15"></div>

<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>
';
?>