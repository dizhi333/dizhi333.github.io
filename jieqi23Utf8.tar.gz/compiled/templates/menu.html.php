<?php
echo '<ul>
        <li>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=3">
                <i class="iconfont icon-daxue"></i>
                <p>都市言情</p>
            </a>
        </li>
        <li class="n3">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=2">
                <i class="iconfont icon-dushi"></i>
                <p>武侠修真</p>
            </a>
        </li>
        <li>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=4">
                <i class="iconfont icon-yonghu"></i>
                <p>历史军事</p>
            </a>
        </li>
        <li class="n3">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=6">
                <i class="iconfont icon-home"></i>
                <p>科幻同人</p>
            </a>
        </li>
        <li>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=5">
                <i class="iconfont icon-star"></i>
                <p>游戏竞技</p>
            </a>
        </li>
        <li class="n3">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=7">
                <i class="iconfont icon-dacumojian"></i>
                <p>现代言情</p>
            </a>
        </li>
        <li class="active">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=8">
                <i class="iconfont icon-lishi"></i>
                <p>古代言情</p>
            </a>
        </li>
        <li class="active n3">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=9">
                <i class="iconfont icon-huangguan"></i>
                <p>幻想言情</p>
            </a>
        </li>
        <li class="active">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articlefilter.php?order=lastupdate&page=1&sortid=10">
                <i class="iconfont icon-sanyecao"></i>
                <p>综合其他</p>
            </a>
        </li>
        <li class="active n3">
            <a href="'.$this->_tpl_vars['jieqi_url'].'/books">
                <i class="iconfont icon-quanbu"></i>
                <p>全部</p>
            </a>
        </li>
    </ul>
</div>
</div>

    <div class="nav-items">
        <a href="'.$this->_tpl_vars['jieqi_url'].'/"';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'index.php'){
echo ' class="active"';
}
echo '>首页</a>
        <!--<a href="#" >男频</a>-->
        <!--<a href="#" >女频</a>-->
        <a href="'.$this->_tpl_vars['jieqi_url'].'/books"';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'articlefilter.php'){
echo ' class="active"';
}
echo ' >书库</a>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/full">完本</a>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/top"';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'toplist.php' || basename($this->_tpl_vars['jieqi_thisfile']) == 'articlelist.php'){
echo ' class="active"';
}
echo '>排行榜</a>
        <!--<a href="/page/9" >手机版</a>-->
        <a href="'.$this->_tpl_vars['jieqi_wap_url'].'">手机版</a>
    </div>

    <div class="nav-btns">
        <a href="#" target="_blank">
            <i class="iconfont icon-msnui-gift-bold"></i> 作家福利
        </a>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/author">
            <i class="iconfont icon-gerenxinxi"></i> 作家专区
        </a>
    </div>';
?>