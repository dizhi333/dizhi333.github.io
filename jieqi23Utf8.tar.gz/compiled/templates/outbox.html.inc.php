<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'system';
$GLOBALS['jieqiTset']['jieqi_page_rows'] = '30';

?>