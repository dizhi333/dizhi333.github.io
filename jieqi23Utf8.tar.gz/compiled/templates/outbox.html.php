<?php
echo '
<div class="novel-home-body-container" >
    <div class="container container-box-shadow" style="margin-bottom:48px;">
        <div class="clearfix">
                        <div class="novel-left-menu">
                <div class="menu-header">用户中心</div>
                <ul>
                   <li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">个人中心</a></li>
	<li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/useredit.php">修改资料</a></li>
    <li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/setavatar.php">设置头像</a></li>
    <li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php">修改密码</a></li>
	<li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=inbox">收件箱</a></li>
	<li class="on"><a href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=outbox">发件箱</a></li>
	<li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/newmessage.php">写新消息</a></li>
	<li class=""><a href="'.$this->_tpl_vars['jieqi_url'].'/newmessage.php?tosys=1">写给管理员</a></li>

    ';
if($this->_tpl_vars['jieqi_modules']['article']['publish'] > 0){
echo '
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/bookcase.php">我的书架</a></li>
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/myactlog.php">打赏记录</a></li>
    ';
}
echo '
    ';
if($this->_tpl_vars['jieqi_modules']['obook']['publish'] > 0){
echo '
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['obook']['url'].'/buylist.php">订阅记录</a></li>
    ';
}
echo '
    ';
if($this->_tpl_vars['jieqi_modules']['pay']['publish'] > 0){
echo '
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php">在线充值</a></li>
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/paylog.php">充值记录</a></li>
    ';
}
echo '
    ';
if($this->_tpl_vars['jieqi_modules']['article']['publish'] > 0){
echo '
    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/applywriter.php">申请作者</a></li>
    ';
}
echo '
	<li class=""><a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'">退出登录</a></li>
                </ul>
            </div>
            <div class="novel-right author-message">
                <div class="right-header pos-rel">
                  发件箱
                </div>
				<form action="'.$this->_tpl_vars['url_action'].'" method="post" name="checkform" id="checkform">
                <table class="message-table">
                  <tr>
                    <th style="width: 33px;"></th>
                    <th style=" width: 533px;">留言内容</th>
                    <th style="width: 100px;">'.$this->_tpl_vars['usertitle'].'</th>
                    <th>时间</th>
                  </tr>
				  ';
if (empty($this->_tpl_vars['messagerows'])) $this->_tpl_vars['messagerows'] = array();
elseif (!is_array($this->_tpl_vars['messagerows'])) $this->_tpl_vars['messagerows'] = (array)$this->_tpl_vars['messagerows'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['messagerows']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['messagerows']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['messagerows']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['messagerows']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['messagerows']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
                  <tr>
                    <td style="padding-left: 5px;"><input type="checkbox" id="checkid[]" name="checkid[]" value="'.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['messageid'].'"></td>
                    <td style="font-size: 12px;">
                      <a href="'.$this->_tpl_vars['jieqi_url'].'/messagedetail.php?id='.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['messageid'].'">'.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['title'].'</a></td>
                    <td style="font-size: 14px;">';
if($this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['toid'] > 0){
echo '<a href="'.jieqi_geturl('system','user',$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['toid']).'" target="_blank">'.$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['toname'].'</a>';
}else{
echo '<span class="hottext">网站管理员</span>';
}
echo '</td>
                    <td style="color: #999;">'.date('Y-m-d H:i:s',$this->_tpl_vars['messagerows'][$this->_tpl_vars['i']['key']]['postdate']).'</td>
                  </tr> 
                  ';
}
echo '
				  </table> 
				  <div class=" clearfix author-message-bot">
			  <div class=""><button type="button" name="allcheck" class="zengsong" style="background:#3CABDB;color:#FFFFFF;" onclick="javascript: for (var i=0;i<this.form.elements.length;i++){ this.form.elements[i].checked = true; }">全部选中</button>&nbsp;&nbsp;<button type="button" name="allcheck" class="zengsong" style="background:#3CABDB;color:#FFFFFF;" onclick="javascript: for (var i=0;i<this.form.elements.length;i++){ this.form.elements[i].checked = false; }">全部取消</button>&nbsp;&nbsp;<button type="button" name="allcheck" class="zengsong" style="background:#3CABDB;color:#FFFFFF;" onclick="javascript:if(confirm(\'确实要删除选中记录么？\')){ this.form.checkaction.value=\'1\'; this.form.submit();}">删除选中记录</button>&nbsp;&nbsp;<button type="button" name="allcheck" class="zengsong" style="background:#3CABDB;color:#FFFFFF;" onclick="javascript:if(confirm(\'确实要清空所有记录么？\'))document.location=\''.$this->_tpl_vars['url_delete'].'\'">清空所有记录</button><input name="checkaction" type="hidden" id="checkaction" value="0"></div>
			  </div>
			  </form>
			  <div class="paging" style="margin-top: 10px;">'.$this->_tpl_vars['url_jumppage'].'</div>
              <div class="message-tip">

                <h2>郑重提示：</h2>
                <p>'.$this->_tpl_vars['boxname'].'（收/发件箱共允许消息数：<font color="red"><b>'.$this->_tpl_vars['maxmessage'].'</b></font>，现有消息数：<font color="red"><b>'.$this->_tpl_vars['nowmessage'].'</b></font>）</p>
              </div>
            </div>
        </div>
    </div>
</div>


';
?>