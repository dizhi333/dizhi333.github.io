<?php
echo '
<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="">官网首页</a>
    <span>></span>
    <a class="active" href="">个人中心</a>
</div>

<div class="c15"></div>


<div class="wrap">
    <div class="customer-wrap">

        <div class="menu">
    <div class="intro">
        <div class="avatar">
            <img src="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" alt="'.$this->_tpl_vars['jieqi_username'].'" onerror="this.src=\''.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'\'" />
        </div>
        <p>'.$this->_tpl_vars['name'].'</p>
		<div class="icon">
            <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/level/'.$this->_tpl_vars['jieqi_group'].'.png" alt=""></a>
        </div>

        <div class="c15"></div>
        <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/line0.png" alt=""></a>
    </div>
    <div class="acts">
        ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/usernav.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
    </div>

    <div class="btns">
                    <a href="#"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/sign.png" alt=""></a>
        <!--        <a href=""><img src="/images/service.png" alt=""></a>-->
    </div>
</div>
        <div class="content">
            <div class="actions">
                <ul>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">基本信息</a></li>
                    <li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/useredit.php">修改资料</a></li>
                    <li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/setavatar.php">头像设置</a></li>
                    <li><span>|</span></li>
                    <li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php">修改密码</a></li>
                </ul>
            </div>

            <div class="c15"></div>

            <div class="customer-edit">
                <form id="login-form" action="'.$this->_tpl_vars['url_passedit'].'" method="post" role="form">
                <div class="edit-cell">
                    <div class="name">原始密码: </div>
                    <div class="info">
                        <input class="txt" type="password" name="oldpass" value="">
                    </div>
                </div>

                <div class="edit-cell">
                    <div class="name">新密码: </div>
                    <div class="info">
                        <input class="txt" type="password" name="newpass" value="">
                    </div>
                </div>

                <div class="edit-cell">
                    <div class="name">确认密码: </div>
                    <div class="info">
                        <input class="txt" type="password" name="repass" value="">
                    </div>
                </div>

                <div class="edit-cell">
                    <div class="name"></div>
                    <div class="info">
						<input type="hidden" name="action" id="action" value="update" />
                        <input class="btn" type="submit" value="保存">
                    </div>
                </div>
                </form>
            </div>

        </div>
    </div>
</div>
    <div class="c15"></div>
<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>';
?>