<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'article';
$this->_tpl_vars['jieqi_pagetitle'] = "作者实名信息-{$this->_tpl_vars['jieqi_sitename']}";

?>