<?php
echo '
<style>
.button{
	font:15px Calibri, Arial, sans-serif;

	/* A semi-transparent text shadow */
	text-shadow:1px 1px 0 rgba(255,255,255,0.4);
	
	/* Overriding the default underline styling of the links */
	text-decoration:none !important;
	white-space:nowrap;
	
	display:inline-block;
	vertical-align:baseline;
	position:relative;
	cursor:pointer;
	padding:10px 20px;
	
	background-repeat:no-repeat;

	/* The following two rules are fallbacks, in case
	   the browser does not support multiple backgrounds. */

	background-position:bottom left;
	background-image:url(\'button_bg.png\');
	
	/* Multiple backgrounds version. The background images
	   are defined individually in color classes */
	
	background-position:bottom left, top right, 0 0, 0 0;
	background-clip:border-box;
	
	/* Applying a default border raidus of 8px */
	
	-moz-border-radius:8px;
	-webkit-border-radius:8px;
	border-radius:8px;
	
	/* A 1px highlight inside of the button */
	
	-moz-box-shadow:0 0 1px #fff inset;
	-webkit-box-shadow:0 0 1px #fff inset;
	box-shadow:0 0 1px #fff inset;
	
	/* Animating the background positions with CSS3 */
	/* Currently works only in Safari/Chrome */
	
	-webkit-transition:background-position 1s;
	-moz-transition:background-position 1s;
	transition:background-position 1s;
}
.button:hover{
	
	/* The first rule is a fallback, in case the browser
	   does not support multiple backgrounds
	*/
	
	background-position:top left;
	background-position:top left, bottom right, 0 0, 0 0;
}

.button:active{
	/* Moving the button 1px to the bottom when clicked */
	bottom:-1px;
}
.button.small	{ font-size:13px;}
.blue.button{
	color:white !important;
	
	border:1px solid #84acc3 !important;
	
	/* A fallback background color */
	background-color: #48b5f2;
	
	/* Specifying a version with gradients according to */
	
	background-image:	url(\'button_bg.png\'), url(\'button_bg.png\'),
						-moz-radial-gradient(	center bottom, circle,
												rgba(89,208,244,1) 0,rgba(89,208,244,0) 100px),
						-moz-linear-gradient(#4fbbf7, #3faeeb);

	background-image:	url(\'button_bg.png\'), url(\'button_bg.png\'),
						-webkit-gradient(	radial, 50% 100%, 0, 50% 100%, 100,
											from(rgba(89,208,244,1)), to(rgba(89,208,244,0))),
						-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4fbbf7), to(#3faeeb));
}

.blue.button:hover{
	background-color:#63c7fe;
	
	background-image:	url(\'button_bg.png\'), url(\'button_bg.png\'),
						-moz-radial-gradient(	center bottom, circle,
												rgba(109,217,250,1) 0,rgba(109,217,250,0) 100px),
						-moz-linear-gradient(#63c7fe, #58bef7);
						
	background-image:	url(\'button_bg.png\'), url(\'button_bg.png\'),
						-webkit-gradient(	radial, 50% 100%, 0, 50% 100%, 100,
											from(rgba(109,217,250,1)), to(rgba(109,217,250,0))),
						-webkit-gradient(linear, 0% 0%, 0% 100%, from(#63c7fe), to(#58bef7));
}
</style>
<div class="novel-home-body-container" >
    <div class="container container-box-shadow" style="margin-bottom:48px;">
        <div class="clearfix">
                  <div class="novel-left-menu">
                <div class="menu-header">作者中心</div>
                <ul>
                   <li class=""><a href="'.$this->_tpl_vars['article_dynamic_url'].'/myarticle.php">作家首页</a></li>
                    <li class=""><a href="'.$this->_tpl_vars['article_static_url'].'/newarticle.php">新建作品</a></li>
                    <li class=""><a href="'.$this->_tpl_vars['article_dynamic_url'].'/masterpage.php">管理作品</a></li>
                    <li class=""><a href="'.$this->_tpl_vars['article_dynamic_url'].'/apply.php?id=3">申请上架</a></li>
                    ';
if($this->_tpl_vars['jieqi_modules']['obook']['publish'] > 0){
echo '
                    <li class=""><a href="'.$this->_tpl_vars['jieqi_modules']['obook']['url'].'/mreport.php">收入管理</a></li>
                    ';
}
echo '
                    <li class=""><a href="'.$this->_tpl_vars['article_dynamic_url'].'/newdraft.php">新建草稿</a></li>
                    <li class=""><a href="'.$this->_tpl_vars['article_dynamic_url'].'/draft.php">管理草稿</a></li>
                    <li class="on"><a href="'.$this->_tpl_vars['jieqi_url'].'/persondetail.php">作者实名信息</a></li>
                </ul>
            </div>
            <div class="novel-right user-author-infor">
                <div class="right-header">';
if($this->_tpl_vars['personsvars']['denyedit'] == 0){
echo '<a href="'.$this->_tpl_vars['jieqi_url'].'/personedit.php" class="fr f14 c-orange">修改信息>></a>';
}else{
echo '<p class="fr f14 c-orange">您的信息已被锁定，禁止修改！如果确实需要修改，请联系管理员处理。</p>';
}
echo '作者信息</div>
               <div class="author-infor-header clearfix">
                   <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'l',$this->_tpl_vars['avatar']).'" class="" alt=""/>
                   <div class="infor-header-right">
                       <p class="" style="margin-top: -6px;">笔名：'.$this->_tpl_vars['penname'].'(ID:'.$this->_tpl_vars['jieqi_userid'].')</p>
                       <p class="" style="margin-top: 10px;">姓名：'.$this->_tpl_vars['personsvars']['realname'].'</p>
                       <p class="" style="margin-top: 10px;">身份证：'.$this->_tpl_vars['personsvars']['idcard'].'</p>
                       <p style="margin-top: 10px;">QQ号码：'.$this->_tpl_vars['personsvars']['qq'].'</p>
                       <p style="margin-top: 10px;">手机号码：'.$this->_tpl_vars['personsvars']['mobilephone'].'</p>
                       <p style="margin-top: 10px;">电子邮箱：'.$this->_tpl_vars['personsvars']['address'].'</p>
                       <p style="margin-top: 10px;">补充信息：'.$this->_tpl_vars['personsvars']['mynote'].'</p>
                       <p style="margin-top: 10px;">银行名称：'.$this->_tpl_vars['personsvars']['banktype'].'</p>
                       <p style="margin-top: 10px;">收款人：'.$this->_tpl_vars['personsvars']['bankuser'].'</p>
                       <p style="margin-top: 10px;">银行账户：'.$this->_tpl_vars['personsvars']['bankcard'].'</p>
                   </div>
               </div>
			  
             ';
if($this->_tpl_vars['jieqi_group'] == 3 && $this->_tpl_vars['jieqi_modules']['article']['publish'] > 0){
echo '<div align="center"><a class="button small blue" href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/applywriter.php">申请成为作者</a></div>';
}
echo '	   
            </div>
        </div>
    </div>
</div>
';
?>