<?php
echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>章节列表-'.$this->_tpl_vars['jieqi_sitename'].'</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/bootstrap.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/theme.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/font-awesome.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/ionicons.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/_all-skins.min.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/blue.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/style.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/article-create.css" rel="stylesheet">
<style type="text/css">
body,td,th {
	font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
</style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

    <header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="/" class="navbar-brand">'.$this->_tpl_vars['jieqi_sitename'].'&middot;<span>作家中心</span></a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                                <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/author">作品管理 <span class="sr-only">(current)</span></a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?id=3">申请签约</a></li>
                        <li><a href="'.$this->_tpl_vars['jieqi_url'].'/mreport">作品收入</a></li>
						<li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/persondetail.php">实名认证</a></li>
                    </ul>
                </div>
                
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="'.$this->_tpl_vars['jieqi_url'].'/authornotice" class="dropdown">
                                <i class="fa fa-bell-o"></i>&nbsp;&nbsp;&nbsp;通知
                                                            </a>
                        </li>
                        <li class="dropdown user user-menu">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="'.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'" class="user-image" alt="'.$this->_tpl_vars['jieqi_username'].'">
                                <span class="hidden-xs">'.$this->_tpl_vars['jieqi_username'].'</span>
                            </a>
                                                        <ul class="dropdown-menu">
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php"><i class="fa fa-edit"></i>我的资料</a>
                                </li>
                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php" id="modifyPwdBtn"><i class="fa fa-lock"></i>更改密码</a>
                                </li>
                                                                <li>
                                    <a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'"><i class="fa fa-sign-out"></i>退出登录</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="content-wrapper">
        <div class="container">
            <section class="content">
                <div class="box box-default chapter">
    <div class="box-header with-border">
        <h3 class="box-title">实名认证</h3>
    </div>
    <div class="box-body">
        <div class="chapter-content">

		
		<form id="register-form" class="form-horizontal" action="'.$this->_tpl_vars['jieqi_url'].'/modules/article/apply.php?do=submit" method="post" enctype="multipart/form-data">
            <div class="form-input-box">
			<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="article-name">说明：</label>
<div class="col-sm-9">
请填写真实信息，否则申请作者可能无法收到签约协议。
</div>
</div>
<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">笔名</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" name="p_penname" value="'.$this->_tpl_vars['penname'].'" placeholder="输入笔名" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">姓名</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" name="p_realname" value="'.$this->_tpl_vars['personsvars']['realname'].'" placeholder="输入真实姓名" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">身份证</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" name="p_idcard" value="'.$this->_tpl_vars['personsvars']['idcard'].'" placeholder="输入真实身份证号码" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">QQ号码</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" name="p_qq" value="'.$this->_tpl_vars['personsvars']['qq'].'" placeholder="输入QQ号码" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">手机号码</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" value="'.$this->_tpl_vars['personsvars']['mobilephone'].'" name="p_mobilephone" placeholder="输入真实手机号码" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="penname">电子邮箱</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" value="'.$this->_tpl_vars['personsvars']['address'].'" name="p_address" placeholder="输入真实电子邮箱" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-intro">
<label class="col-sm-3 control-label" for="article-intro">补充信息</label>
<div class="col-sm-9"><textarea id="article-intro" class="form-control" name="p_mynote" rows="5" placeholder="相关的补充信息">'.$this->_tpl_vars['personsvars']['mynote'].'</textarea>
<p class="help-block help-block-error">
</p>
</div>
</div>

<div class="form-group">
                    <label class="col-sm-3 control-label" for="registerform-card_type">银行名称</label>
                    <div class="col-sm-3">
                        <div class="form-group field-article-channel required">
<select id="article-channel" class="form-control" name="p_banktype" aria-required="true">
				<option value="'.$this->_tpl_vars['personsvars']['bankuser'].'" >'.$this->_tpl_vars['personsvars']['bankuser'].'</option>
                <option value="工商银行" >工商银行</option>
                <option value="农业银行" >农业银行</option>
                <option value="中国银行" >中国银行</option>
                <option value="建设银行" >建设银行</option>
                <option value="交通银行" >交通银行</option>
                <option value="中信银行" >中信银行</option>
                <option value="光大银行" >光大银行</option>
                <option value="华夏银行" >华夏银行</option>
                <option value="民生银行" >民生银行</option>
                <option value="广发银行" >广发银行</option>
                <option value="平安银行" >平安银行</option>
                <option value="招商银行" >招商银行</option>
                <option value="福建兴业银行" >福建兴业银行</option>
                <option value="上海浦东发展银行" >上海浦东发展银行</option>
                <option value="城市商业银行" >城市商业银行</option>
                <option value="农村商业银行" >农村商业银行</option>
                <option value="恒丰银行" >恒丰银行</option>
                <option value="浙商银行" >浙商银行</option>
                <option value="农村合作银行" >农村合作银行</option>
                <option value="渤海银行" >渤海银行</option>
                <option value="微商银行股份有限公司" >微商银行股份有限公司</option>
                <option value="村镇银行" >村镇银行</option>
                <option value="上海农村商业银行" >上海农村商业银行</option>
                <option value="农村信用合作社" >农村信用合作社</option>
                <option value="邮政储汇" >邮政储汇</option>
                <option value="韩国外换银行" >韩国外换银行</option>
                <option value="友利银行" >友利银行</option>
                <option value="新韩银行" >新韩银行</option>
                <option value="支付宝" >支付宝</option>
                <option value="其他" >其他</option>
</select>
</div>                    </div>
                    
                </div>
				
<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="article-name">收款人</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" value="'.$this->_tpl_vars['personsvars']['bankuser'].'" name="p_bankuser" placeholder="输入收款人姓名" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

<div class="form-group field-article-name required">
<label class="col-sm-3 control-label" for="article-name">银行账户</label>
<div class="col-sm-9">
<input type="text" id="article-name" class="form-control" value="'.$this->_tpl_vars['personsvars']['bankcard'].'" name="p_bankcard" placeholder="输入银行账户号码" aria-required="true"><p class="help-block help-block-error"></p></div>
</div>

                <div class="row">
                    <div class="col-sm-offset-4 col-sm-4">
					<input type="hidden" name="action" id="action" value="update" />'.$this->_tpl_vars['jieqi_token_input'].'
					<input type="submit" value=" 确定修改 " class="btn btn-warning btn-block" />
					</div>
                </div>
            </div>
            </form>
		
		
        </div>
    </div>
</div>
          </section>
        </div>
    </div>

    <footer class="main-footer">
        <div class="container">
            <div class="pull-right hidden-xs">
                Copyright &copy; '.date('Y',$this->_tpl_vars['jieqi_time']).' All Rights Reserved '.$this->_tpl_vars['jieqi_sitename'].' 版权所有
            </div>
        </div>
    </footer>
</div>
<div id="msgModal" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">消息提示</h4>
</div>
<div class="modal-body">

</div>
<div class="modal-footer">
<a href="#" class="btn btn-primary" data-dismiss="modal">确定</a>
</div>
</div>
</div>
</div>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/bootstrap-datetimepicker.zh-CN.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.activeForm.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/app.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.slimscroll.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/icheck.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/vue.js"></script>
<!--[if lt IE 9]>
<script src="/js/html5shiv.min.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="/js/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">jQuery(document).ready(function () {
var content = new Vue({
  el: \'#editChapter\',
  data: {
      \'chapter\' : {},
  }
});

$(function() {
    $("#publishBtn").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
    $("#publishBtnLeft").click(function() {
        var msg = \'\';
        if($("#chapterNameInput").val() == \'\'){
            msg = \'标题不能为空\';
        }else if($("#chapterContentInput").val() == \'\'){
            msg = \'内容不能为空\';
        }
        if(msg){
            $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+msg+\'</p>\');
            $(\'#msgModal\').modal(\'show\');
            return;
        }
        $("#chapterNameSpan").text($("#chapterNameInput").val());
        $(\'#publishModal\').modal(\'show\');
    });
    
    $("#publishOkBtn").click(function() {
        var $form = $("#edit-form");
        $.ajax({
            url: $form.attr(\'publishUrl\'),
            type: \'post\',
            data: $form.serialize(),
            dataType: \'json\',
            success: function (data) {
                if(data.state == \'error\'){
                    $(\'#msgModal .modal-body\').html(\'<p style="text-align: center;font-size: 14px;color:#575757;">\'+data.msg+\'</p>\');
                    $(\'#msgModal\').modal(\'show\');
                    return;
                }
                if($("#id").val() == \'\'){
                    location.href = \'/chapter/draft?article_id=1518\';
                }else{
                    location.reload();
                }
            }
        });
    });
    
    $("#publishType input").click(function () {
        if($(this).val() == 1){
            $("#dateTimePickerBox").show();
        }else{
            $("#dateTimePickerBox").hide();
        }
    });
});
;jQuery(\'#w0\').parent().datetimepicker({"autoclose":true,"format":"yyyy-mm-dd hh:ii:ss","todayBtn":true,"language":"zh-CN"});
jQuery(\'#publishModal\').modal({"show":false});
});</script></body>
</html>
';
?>