<?php
echo '<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="">官网首页</a>
    <span>></span>
    <a class="active" href="">用户注册</a>
</div>

<div class="c15"></div>

<div class="wrap">
    <div class="register-wrap">
        <div class="content">
            <form id="signup-form" action="'.$this->_tpl_vars['form_action'].'?do=submit" method="post" role="form">
<input type="hidden" name="_csrf-frontend" value="b0JiekQ0LWokDQoICEVMXCYSMAorRUgOHA0tQiEEbB0lCFoyPWAUAQ==">            <div class="tit"><span>用户注册</span></div>

            <div class="register-cell">
                <div class="name">登录账号: </div>
                <div class="info">
                    <input class="txt" type="text" name="username" value="">
                    <p>由6~16位之内的数字、下划线、英文字母组成</p>                </div>
            </div>

            <div class="register-cell">
                <div class="name">E-mail: </div>
                <div class="info">
                    <input class="txt" type="text" name="email" value="">
                    <p>请填写邮箱</p>                </div>
            </div>
			
            <div class="register-cell">
                <div class="name">账户密码: </div>
                <div class="info">
                    <input class="txt" type="password" name="password" value="">
                    <p>建议密码长度在6~30之内</p>                </div>
            </div>

            <div class="register-cell">
                <div class="name">确认密码: </div>
                <div class="info">
                    <input class="txt" type="password" name="repassword" value="">
                    <p>请再次输入密码</p>                </div>
            </div>
';
if($this->_tpl_vars['show_checkcode'] > 0){
echo '
            <div class="register-cell">
                <div class="name">验证码: </div>
                <div class="info captcha">
                    <input class="txt" type="text" name="checkcode" value="" onfocus="if($_(\'reg_imgccode\').style.display == \'none\'){$_(\'reg_imgccode\').src = \''.$this->_tpl_vars['jieqi_url'].'/checkcode.php\';$_(\'reg_imgccode\').style.display = \'\';}">
                    <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/checkcode.php"  onclick="this.src=\''.$this->_tpl_vars['jieqi_url'].'/checkcode.php?rand=\'+Math.random();" alt="点击更换验证码"></a>
                </div>
            </div>
';
}
echo '

            <div class="register-cell">
                <div class="name"></div>
                <div class="info captcha">
                    <div class="rls">
                        <label>
                        <input type="checkbox" name="agreement" value="1" >
                        点击"注册"表示您已查看并同意遵守</label><a href="">《用户使用协议》</a>
                    </div>
                </div>
            </div>

            <div class="register-cell">
                <div class="name"></div>
                <div class="info">
					<input type="hidden" name="action" id="action" value="newuser" />
                    <input class="btn" type="submit" name="submit" value="注册">
                </div>
            </div>
            </form>        </div>

        <div class="other">
            <p>已有账号，立即登录</p>
            <a href="'.$this->_tpl_vars['jieqi_url'].'/login.php" class="btn">立即登录</a>

            <p>您也可以使用其他账号登录: </p>
            <div id="w0"><ul class="auth-clients">
			<li><a class="qq auth-link" href="/api/qq/login.php" title="QQ 登录"><span class="auth-icon qq"></span></a></li>
			<li><a class="wechat auth-link" href="/api/weixin/login.php" title="Wechat"><span class="auth-icon wechat"></span></a></li>
			<!--<li><a class="weibo auth-link" href="/api/weibo/login.php" title="weibo"><span class="auth-icon weibo"></span></a></li>-->
			</ul>
			</div>
		</div>
	</div>
</div>
<div id="wx_login" style="display: none"></div>
    <div class="c15"></div>

<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>
';
?>