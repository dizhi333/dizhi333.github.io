<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'system';
$this->_tpl_vars['jieqi_pagetitle'] = "个人中心-{$this->_tpl_vars['jieqi_sitename']}";

?>