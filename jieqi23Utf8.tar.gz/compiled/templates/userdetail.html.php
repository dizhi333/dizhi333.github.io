<?php
echo '
<div class="nav wrap">
    <div class="dropdown">
        <div class="btn">
    <i class="iconfont icon-caidan"></i> 作品分类
</div>
<div class="dropdown-items ">
    ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/menu.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
</div>
</div>

<div class="c15"></div>
<div class="position wrap">
    <span>您的位置: </span>
    <a href="">官网首页</a>
    <span>></span>
    <a class="active" href="">个人中心</a>
</div>

<div class="c15"></div>


<div class="wrap">
    <div class="customer-wrap">

        <div class="menu">
    <div class="intro">
        <div class="avatar">
            <img src="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" alt="'.$this->_tpl_vars['jieqi_username'].'" onerror="this.src=\''.jieqi_geturl('system','avatar',$this->_tpl_vars['jieqi_userid'],'s').'\'" />
        </div>
        <p>'.$this->_tpl_vars['name'].'</p>
		<div class="icon">
            <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/level/'.$this->_tpl_vars['jieqi_group'].'.png" alt=""></a>
            <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/vip/'.$this->_tpl_vars['isvip'].'.png" alt=""></a>
        </div>

        <div class="c15"></div>
        <a href=""><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/line0.png" alt=""></a>
    </div>
    <div class="acts">
        ';
$_template_tpl_vars = $this->_tpl_vars;
 $this->_template_include(array('template_include_tpl_file' => 'templates/usernav.html', 'template_include_vars' => array()));
 $this->_tpl_vars = $_template_tpl_vars;
 unset($_template_tpl_vars);
echo ' 
    </div>

    <div class="btns">
                    <a href="'.$this->_tpl_vars['jieqi_url'].'/user/signin.php"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/sign.png" alt=""></a>
        <!--        <a href=""><img src="/images/service.png" alt=""></a>-->
    </div>
</div>
        <div class="content">
            <div class="actions">
                <ul>
                    <li class="active"><a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">基本信息</a></li>
                    <li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/useredit.php">修改资料</a></li>
                    <li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/setavatar.php">头像设置</a></li>
                    <li><span>|</span></li>
                    <li><a href="'.$this->_tpl_vars['jieqi_url'].'/passedit.php">修改密码</a></li>
                </ul>
            </div>

            <div class="c15"></div>

            <div class="static-cell">
                <div class="hd">用户名: </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['uname'].'</span>
                </div>
            </div>

            <div class="static-cell">
                <div class="hd">用户昵称: </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['name'].'</span>
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">性别：</div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['sex'].'</span>
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">Email： </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['email'].'</span>
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">QQ： </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['qq'].'</span>
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">注册日期： </div>
                <div class="bd">
                    <span class="i1">'.date('Y-m-d',$this->_tpl_vars['regdate']).'</span>
                </div>
            </div>
            <div class="static-cell">
                <div class="hd">用户等级: </div>
                <div class="bd">
					<img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/level/'.$this->_tpl_vars['jieqi_group'].'.png" alt="'.$this->_tpl_vars['group'].'">
<!--                    <div class="progress">-->
<!--                        <div class="load" style="width:20%;"></div>-->
<!--                        <p>成长值 10/500</p>-->
<!--                    </div>-->
<!--                    <a href="" class="i3">查看用户等级体系</a>-->
                </div>
            </div>

            <div class="static-cell">
                <div class="hd">VIP等级: </div>
                <div class="bd">
					<img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/vip/'.$this->_tpl_vars['isvip'].'.png" alt="';
if($this->_tpl_vars['isvip'] <= 0){
echo '非vip会员';
}else{
echo 'VIP会员';
}
echo '">
<!--                    <div class="progress">-->
<!--                        <div class="load" style="width:20%;"></div>-->
<!--                        <p>成长值 10/500</p>-->
<!--                    </div>-->
<!--                    <a href="" class="i3">查看用户等级体系</a>-->
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">赠券: </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['juan'].'张</span>
<!--                    <a href="" class="i2">查看明细</a>-->
                </div>
            </div>

            <div class="static-cell">
                <div class="hd">VIP月票: </div>
                <div class="bd">
                    <span class="i1">'.intval($this->_tpl_vars['setting']['gift']['vipvote']).'张</span>
<!--                    <a href="" class="i2">查看明细</a>-->
                </div>
            </div>

            <div class="static-cell">
                <div class="hd">日推荐票: </div>
                <div class="bd">
                    <span class="i1">'.intval($this->_tpl_vars['right']['article']['dayvotes']).'张</span>
<!--                    <a href="" class="i2">查看明细</a>-->
<!--                    <a href="" class="i3">如何获得更多？</a>-->
                </div>
            </div>
			<div class="static-cell">
                <div class="hd">签名: </div>
                <div class="bd">
                    <span class="i1">'.$this->_tpl_vars['sign'].'</span>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="c15"></div>
<div class="notice flink wrap">
    <div class="channel-box">
        <div class="tit">
            <span>友情链接</span>
        </div>
        <div class="content">
            '.jieqi_get_block(array('bid'=>'0', 'blockname'=>'友情链接', 'module'=>'link', 'filename'=>'block_linklist', 'classname'=>'BlockLinkLinklist', 'side'=>'-1', 'title'=>'友情链接', 'vars'=>'10,2,0,64', 'template'=>'link_list.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
    </div>
</div>

<div class="c15"></div>
';
?>