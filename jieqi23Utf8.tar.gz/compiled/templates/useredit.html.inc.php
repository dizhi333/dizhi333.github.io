<?php
$GLOBALS['jieqiTset']['jieqi_blocks_module'] = 'system';
$this->_tpl_vars['jieqi_pagetitle'] = "修改资料-{$this->_tpl_vars['jieqi_sitename']}";

?>