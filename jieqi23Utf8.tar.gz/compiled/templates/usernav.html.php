<?php
echo '<ul>
            <li>
                <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/ico_zuojia.gif" alt="">
                <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">个人资料</a>
            </li>
            <li>
                <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/ico_account.gif" alt="">
                <a href="'.$this->_tpl_vars['jieqi_url'].'/useraccount.php">我的账户</a>
            </li>
            <li>
                <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/ico_bookshelf.gif" alt="">
                <a href="'.$this->_tpl_vars['jieqi_url'].'/bookcase">我的书架</a>
            </li>
			
            <li>
                <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/ico_shuping.gif" alt="">
				';
if($this->_tpl_vars['jieqi_group'] == 2){
echo '
				<a href="'.$this->_tpl_vars['jieqi_url'].'/author">作者专区</a>
				';
}elseif($this->_tpl_vars['jieqi_group'] > 5){
echo '
                <a href="'.$this->_tpl_vars['jieqi_url'].'/author">作者专区</a>
				';
}else{
echo '
				<a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/applywriter.php">申请作者</a>
				';
}
echo '
            </li>
			
            <li>
                <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/images/ico_booklist.gif" alt="">
                <a href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=inbox">消息中心</a>
            </li>
        </ul>';
?>