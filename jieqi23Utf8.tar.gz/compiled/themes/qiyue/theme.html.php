<?php
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="zh-CN">
<head>
<meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no, email=no"/>
<title>'.$this->_tpl_vars['jieqi_pagetitle'].'</title>
<meta name="keywords" content="'.$this->_tpl_vars['meta_keywords'].'"/>
';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'articleinfo.php'){
echo '
<meta name="description" content="'.truncate($this->_tpl_vars['intro'],'500','..').'" />
<meta property="og:type" content="novel"/>
<meta property="og:title" content="'.$this->_tpl_vars['article_title'].'"/>
<meta property="og:description" content="'.htmlclickable($this->_tpl_vars['intro']).'"/>
<meta property="og:image" content="'.$this->_tpl_vars['url_limage'].'"/>
<meta property="og:novel:category" content="'.$this->_tpl_vars['sortname'].'"/>
<meta property="og:novel:author" content="'.$this->_tpl_vars['author'].'"/>
<meta property="og:novel:book_name" content="'.$this->_tpl_vars['article_title'].'"/>
<meta property="og:novel:read_url" content="'.$this->_tpl_vars['jieqi_url'].'/modules/article/articleread.php?id='.$this->_tpl_vars['articleid'].'"/>
<meta property="og:url" content="'.$this->_tpl_vars['url_articleinfo'].'"/>
<meta property="og:novel:status" content="'.$this->_tpl_vars['fullflag'].'"/>
<meta property="og:novel:update_time" content="'.date('Y-m-d',$this->_tpl_vars['lastupdate']).'"/>
<meta property="og:novel:latest_chapter_name" content="';
if($this->_tpl_vars['isvip_n'] > 0 && $this->_tpl_vars['vipsize'] > 0){
echo $this->_tpl_vars['vipchapter'];
}else{
echo $this->_tpl_vars['lastchapter'];
}
echo '"/>
<meta property="og:novel:latest_chapter_url" content="';
if($this->_tpl_vars['isvip_n'] > 0 && $this->_tpl_vars['vipsize'] > 0){
echo $this->_tpl_vars['url_vipchapter'];
}else{
echo $this->_tpl_vars['lastchapter'];
}
echo '"/>
';
}
echo '
<meta name="description" content="'.$this->_tpl_vars['meta_description'].'"/>
';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'login.php'){
echo '
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/authchoice.css" rel="stylesheet">
';
}
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'register.php'){
echo '
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/authchoice.css" rel="stylesheet">
';
}
echo '
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/font_v3wvvvmymuprdx6r.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/main.css" rel="stylesheet">
<link href="'.$this->_tpl_vars['jieqi_url'].'/tianyin/css/customer.css" rel="stylesheet">
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery-1.9.1.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/layer.min.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/jquery.superslide.2.1.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/main.js"></script></head>
 </head>
    <body>
<div class="header';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'index.php'){
}else{
echo ' nav-hide';
}
echo '">
    <div class="top">
        <div class="wrap">
            <div class="welcome">欢迎访问'.$this->_tpl_vars['jieqi_sitename'].'！</div>
            <ul class="top-menu">
				';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
                <li style="margin-right: 15px;">
                    <a href="javascript:;" onclick="showLoginLayer()">登录</a>
                    |
                    <a href="'.$this->_tpl_vars['jieqi_url'].'/register.php">注册</a>
                </li>
				';
}else{
echo '
				<li class="dropdown">
                    <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">
                        '.$this->_tpl_vars['jieqi_username'].'
						<i class="iconfont icon-xiala"></i>
                    </a>
                    <div class="sub">
						';
if($this->_tpl_vars['jieqi_group'] == 2){
echo '
						<p><a href="'.$this->_tpl_vars['jieqi_url'].'/admin">管理中心</a></p>
						';
}elseif($this->_tpl_vars['jieqi_group'] > 5){
echo '
						<p><a href="'.$this->_tpl_vars['jieqi_url'].'/author">作者专区</a></p>
						';
}else{
echo '
						<p><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/applywriter.php">申请作者</a></p>
						';
}
echo '
                        <p><a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php">个人中心</a></p>
                        <p><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/bookcase.php">我的书架</a></p>
                        <p><a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'">退出登录</a></p>
                    </div>
                </li>
				';
}
echo '
                <li>
                    <a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php">
                        <i class="iconfont icon-jinbi"></i> 充值
                    </a>
                </li>
            </ul>
        </div>
    </div>
        <div class="mid wrap">
    <div class="logo">
        <a href="/"><img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/logo.png" alt="'.$this->_tpl_vars['jieqi_sitename'].'"></a>
    </div>
    <div class="search">
        <div class="search-form">
            <form id="search-form" action="'.$this->_tpl_vars['jieqi_url'].'/search" method="get" role="form">
			<input type="text" name="searchtype" value="all" style="display:none;">
            <input type="text" name="searchkey" placeholder="请输入书名或作者名" value="">
            <button type="submit" name="submit">
                <i class="iconfont icon-sousuo-sousuo"></i>
            </button>
            </form>
			</div>
        <div class="search-hot">
            '.jieqi_get_block(array('bid'=>'0', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>'0', 'title'=>'区块', 'vars'=>'allvote,5,0,0,0,0', 'template'=>'block_so.html', 'contenttype'=>'4', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'1'), 1).'
        </div>
        <script>
            $("#search-form").submit(function () {
                if($("input[name=\'searchkey\']").val() == \'\' || $("input[name=\'searchkey\']").val() == \'请输入书名或作者名\'){
                    layer.msg(\'请输入关键字\');
                    return false;
                }
            });
        </script>
    </div>
    <div class="btn">
        <a href="'.$this->_tpl_vars['jieqi_url'].'/bookcase">
            <i class="iconfont icon-book"></i> 我的书架
        </a>
    </div>
</div>
';
if($this->_tpl_vars['jieqi_top_bar'] != ""){
echo $this->_tpl_vars['jieqi_top_bar'];
}
if($this->_tpl_vars['jieqi_showtblock'] == 1){
if (empty($this->_tpl_vars['jieqi_tblocks'])) $this->_tpl_vars['jieqi_tblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_tblocks'])) $this->_tpl_vars['jieqi_tblocks'] = (array)$this->_tpl_vars['jieqi_tblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_tblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_tblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_tblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_tblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_tblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
  ';
if($this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo '
  '.$this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['content'];
}
}
echo '

';
if(empty($this->_tpl_vars['jieqi_clblocks']) == false || empty($this->_tpl_vars['jieqi_crblocks']) == false){
echo '

';
if (empty($this->_tpl_vars['jieqi_clblocks'])) $this->_tpl_vars['jieqi_clblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_clblocks'])) $this->_tpl_vars['jieqi_clblocks'] = (array)$this->_tpl_vars['jieqi_clblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_clblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_clblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_clblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_clblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_clblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '

';
if (empty($this->_tpl_vars['jieqi_crblocks'])) $this->_tpl_vars['jieqi_crblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_crblocks'])) $this->_tpl_vars['jieqi_crblocks'] = (array)$this->_tpl_vars['jieqi_crblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_crblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_crblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_crblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_crblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_crblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['content'].'
 
';
}
echo '

';
}
echo '


';
if($this->_tpl_vars['jieqi_showlblock'] == 1){
echo '

';
if (empty($this->_tpl_vars['jieqi_lblocks'])) $this->_tpl_vars['jieqi_lblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_lblocks'])) $this->_tpl_vars['jieqi_lblocks'] = (array)$this->_tpl_vars['jieqi_lblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_lblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_lblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_lblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_lblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_lblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '  

  ';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
}else{
}
}else{
echo '
  ';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
}else{
}
}
if($this->_tpl_vars['jieqi_showcblock'] == 1){
if (empty($this->_tpl_vars['jieqi_ctblocks'])) $this->_tpl_vars['jieqi_ctblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_ctblocks'])) $this->_tpl_vars['jieqi_ctblocks'] = (array)$this->_tpl_vars['jieqi_ctblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_ctblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_ctblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_ctblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_ctblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_ctblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
if (empty($this->_tpl_vars['jieqi_cmblocks'])) $this->_tpl_vars['jieqi_cmblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_cmblocks'])) $this->_tpl_vars['jieqi_cmblocks'] = (array)$this->_tpl_vars['jieqi_cmblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_cmblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_cmblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_cmblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_cmblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_cmblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
if($this->_tpl_vars['jieqi_contents'] != ""){
echo $this->_tpl_vars['jieqi_contents'];
}
if($this->_tpl_vars['jieqi_showcblock'] == 1){
if (empty($this->_tpl_vars['jieqi_cbblocks'])) $this->_tpl_vars['jieqi_cbblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_cbblocks'])) $this->_tpl_vars['jieqi_cbblocks'] = (array)$this->_tpl_vars['jieqi_cbblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_cbblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_cbblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_cbblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_cbblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_cbblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
echo '

';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
echo '

';
if (empty($this->_tpl_vars['jieqi_rblocks'])) $this->_tpl_vars['jieqi_rblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_rblocks'])) $this->_tpl_vars['jieqi_rblocks'] = (array)$this->_tpl_vars['jieqi_rblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_rblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_rblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_rblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_rblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_rblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '

';
}
echo '


';
if($this->_tpl_vars['jieqi_showbblock'] == 1){
if (empty($this->_tpl_vars['jieqi_bblocks'])) $this->_tpl_vars['jieqi_bblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_bblocks'])) $this->_tpl_vars['jieqi_bblocks'] = (array)$this->_tpl_vars['jieqi_bblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_bblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_bblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_bblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_bblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_bblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
if($this->_tpl_vars['jieqi_bottom_bar'] != ""){
echo $this->_tpl_vars['jieqi_bottom_bar'];
}
echo '

<div class="footer">

    <div class="menu">
        <a href="#">关于我们</a>
        <span>|</span>
        <a href="#">商务合作</a>
        <span>|</span>
        <a href="#">用户守则</a>
        <span>|</span>
        <a href="#">联系我们</a>
    </div>
    <p>Copyright  2017-'.date('Y',$this->_tpl_vars['jieqi_time']).'All Rights Reserved 
	<br/>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何色情小说，一经发现，即作删除！
	<br/>本站所收录的作品、社区话题、用户评论、用户上传内容或图片等均属用户个人行为。
	<br/>如前述内容侵害您的权益，欢迎举报投诉，一经核实，立即删除，本站不承担任何责任。</p>
    <p>
		<div style="width:300px;margin:0 auto; padding:20px 0;">
                <a target="_blank" href="http://www.beian.gov.cn" style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img src="" style="float:left;"/><p style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;">桂ICP备18001335号</p></a>
        </div>
    </p>
</div>
<div class="fix-menu">
    <div class="item">
        <a class="pic" href="javascript:;"><i class="iconfont icon-erweima"></i></a>
        <div class="sub">
            <img src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/picture/qr.png" alt="">
			<div style="text-align:center;color: red">扫描上方二维码<br>看更多免费小说</div>
        </div>
    </div>

    <div class="item">
        <a class="pic" href="http://wpa.qq.com/msgrd?v=3&uin=123456&site=qq&menu=yes" target="_blank"><i class="iconfont icon-2"></i></a>
    </div>

    <div class="item">
        <a class="pic" href="javascript:;" onclick="goTop()"><i class="iconfont icon-back-top"></i></a>
    </div>
</div>
';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
<div class="login-layer">
    <form id="login-form" action="'.$this->_tpl_vars['jieqi_user_url'].'/login.php?do=submit" method="post" role="form">
        <div class="login-cell">
            <i class="iconfont icon-yonghu"></i>
            <input type="text" placeholder="输入用户名" name="username">
        </div>

        <div class="login-cell">
            <i class="iconfont icon-Password"></i>
            <input type="password" placeholder="输入密码" name="password">
        </div>

        <div class="btns">
<!--            <p>-->
<!--                <input type="checkbox" id="auto-login" name="" value="">-->
<!--                <label for="auto-login">自动登录</label>-->
<!--            </p>-->

            <div>
<!--                <a href="/site/resetpwd">忘记密码</a>
                |-->
				
                <a href="'.$this->_tpl_vars['jieqi_url'].'/register.php">免费注册</a>
            </div>
        </div>
		<input type="hidden" name="action" value="login">
        <input type="submit" class="btn-ok" value="登 录">

        <p class="more"><a href="'.$this->_tpl_vars['jieqi_url'].'/login.php">更多登录方式</a></p>

        <!--密码找回提示S-->
        <p class="more"><a href="#" style="font-size: 14px;color:#ff0000">无法登陆？请看这里></a></p>
        <!--密码找回提示E-->

    </form>
</div>
';
}
echo '
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.js"></script>
<script src="'.$this->_tpl_vars['jieqi_url'].'/tianyin/js/yii.activeform.js"></script>
<script type="text/javascript">jQuery(document).ready(function () {
    // 幻灯
    jQuery(".slideBox").slide({mainCell:".bd ul",effect:"fold",autoPlay:true});
    // 轮播
    jQuery(".lunbo-box").slide({mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:3,trigger:"click"});
    // 排行榜tab
    jQuery(".rank-tab").slide();

    

jQuery(\'#search-form\').yiiActiveForm([], []);
jQuery(\'#login-form\').yiiActiveForm([], []);
});</script></body>
';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '
<script type="text/javascript">
    $(".need-login").click(function () {
        showLoginLayer();
        return false;
    });
</script>
';
}
echo '
</html>
';
?>