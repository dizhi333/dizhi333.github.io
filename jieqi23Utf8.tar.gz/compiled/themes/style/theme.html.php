<?php
echo '﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="'.$this->_tpl_vars['jieqi_charset'].'" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport">
        <meta name="viewport" content="width=device-width"/>
        <meta content="240" name="MobileOptimized">
        <title>'.$this->_tpl_vars['jieqi_pagetitle'].'</title>
        <meta name="keywords" content="'.$this->_tpl_vars['meta_keywords'].'"/>
        <meta name="description" content="'.$this->_tpl_vars['meta_description'].'"/>
        <link type="text/css" rel="stylesheet" href="'.$this->_tpl_vars['jieqi_url'].'/style/Css/common.css">
        <link type="text/css" rel="stylesheet" href="'.$this->_tpl_vars['jieqi_url'].'/style/Css/main.css">
        <script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/style/Scripts/jquery.cookie.js"></script>
        <script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/style/Scripts/record_cookie.js"></script> 
        <script type="text/javascript"  src="'.$this->_tpl_vars['jieqi_url'].'/style/Scripts/lu.js"></script>
		<script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/scripts/common.js"></script>
		';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'applywriter.php' || basename($this->_tpl_vars['jieqi_thisfile']) == 'register.php'){
echo '<script type="text/javascript"  src="'.$this->_tpl_vars['jieqi_url'].'/style/Scripts/sj.js"></script>';
}
echo '
        <script type="text/javascript"  src="'.$this->_tpl_vars['jieqi_url'].'/style/Scripts/bangdan.js"></script>
		<script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/scripts/skin/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/scripts/skin/layer.js"></script>
<script type="text/javascript" src="'.$this->_tpl_vars['jieqi_url'].'/scripts/skin/page.js"></script>
<script type="text/javascript">
layer.ready(function(){
	var jumpurl = $("#jumpurl").val();
	var url = "/api/qq/login.php";
	if (jumpurl && jumpurl!="undefined"){
		url = url + "?jumpurl=" + jumpurl;
	}
	
   $("#qqlogin").bind("click",function(){
		otherlogin(url);
	});
   $("#weibologin").bind("click",function(){
		otherlogin("/api/weibo/login.php");
	});
	$("#weixinlogin").bind("click",function(){
		otherlogin("/api/weixin/login.php");
	});
});
</script>
    </head>
    <body>
    <div class="novel-header">
    <div class="container clearfix">
        <a href="/"><img src="'.$this->_tpl_vars['jieqi_url'].'/style/images/logo-home.png" style="padding-top:30px;" class="logo-home" alt=""/></a>
        <ul class="">
            <li';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'index.php'){
echo ' class="on"';
}
echo '><a href="'.$this->_tpl_vars['jieqi_url'].'/">首页</a></li>
            <li';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'articlefilter.php' || basename($this->_tpl_vars['jieqi_thisfile']) == 'articleinfo.php'){
echo ' class="on"';
}
echo '><a href="'.jieqi_geturl('article','articlefilter','1','').'">书库</a></li>
            <li';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'toplist.php' || basename($this->_tpl_vars['jieqi_thisfile']) == 'articlelist.php'){
echo ' class="on"';
}
echo ' ><a href="'.jieqi_geturl('article','toplist','1','toplist').'">排行</a></li>
           <!-- <li ><a href="/Fuli/index.html">福利</a></li> -->
            <li';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'buyegold.php'){
echo ' class="on"';
}
echo '><a href="'.$this->_tpl_vars['jieqi_modules']['pay']['url'].'/buyegold.php">充值</a></li>
			<li ><a href="'.$this->_tpl_vars['jieqi_wap_url'].'">手机</a></li>
			<li';
if(basename($this->_tpl_vars['jieqi_thisfile']) == 'myarticle.php'){
echo ' class="on"';
}
echo '><a href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/myarticle.php">作者</a></li>
        </ul>
		';
if($this->_tpl_vars['jieqi_banner'] == ''){
echo '
        <div class="search">
		<form name="select"  method="post" action="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/search.php">
		    <input type="text" name="searchtype" value="all" style="display:none;">
            <input type="text" name="searchkey"  onfocus="if(this.value==\'请输入关键字\'){this.value=\'\'}" onblur="if(this.value==\'\'){this.value=\'请输入关键字\';}" placeholder="找书、找作者"/>
           <!--  <div class="search-btn" onClick="window.location.href=\'#search.html\'"></div> -->
			 <!-- <input name="image" type="image" class="search-btn" id="image" src="" align="bottom" /> -->
			 <button name="t_btnsearch" type="submit" class="search-btn" style="border:0px"></button>
		</form>	
        </div>
		';
}else{
echo $this->_tpl_vars['jieqi_banner'].'
        ';
}
echo '
    </div>
</div>
<div class="novel-home-body-header ">
    <div class="container clearfix">
        <div class="vip"><span>热门推荐：</span>'.jieqi_get_block(array('bid'=>'0', 'blockname'=>'热推', 'module'=>'article', 'filename'=>'block_commend', 'classname'=>'BlockArticleCommend', 'side'=>'-1', 'title'=>'热推', 'vars'=>'1|2|3', 'template'=>'block_style_reitui.html', 'contenttype'=>'1', 'custom'=>'0', 'publish'=>'3', 'hasvars'=>'2'), 1).'</div>
    ';
if($this->_tpl_vars['jieqi_userid'] == 0){
echo '	
        <a class="header-right" href="'.$this->_tpl_vars['jieqi_url'].'/login.php">用户登录</a>
	    <a class="header-right" href="'.$this->_tpl_vars['jieqi_url'].'/register.php">用户注册</a>
        <div class="login_other fr">
			<a href="/api/weixin/login.php" id="weixinlogin" class="weixin"></a>
           <a href="/api/weibo/login.php" id="weibologin" class="weibo"></a>
           <a href="/api/qq/login.php" id="qqlogin" class="qq"></a>
        </div>
	';
}else{
echo '
		';
if($this->_tpl_vars['jieqi_modules']['article']['publish'] > 0){
echo '<a class="header-right" href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/bookcase.php">我的追书</a>';
}
echo '
		';
if($this->_tpl_vars['jieqi_group'] == 2){
echo '
		<a class="header-right" href="'.$this->_tpl_vars['jieqi_url'].'/admin/index.php">管理中心</a>
		';
}elseif($this->_tpl_vars['jieqi_group'] > 5){
echo '
		<a class="header-right" href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/myarticle.php">作者中心</a>
		';
}else{
echo '
        <a class="header-right" href="'.$this->_tpl_vars['jieqi_modules']['article']['url'].'/applywriter.php">申请作者</a>
		';
}
echo '
        <a class="header-right" href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" target="_blank">用户中心</a>
		<a class="header-right" href="'.$this->_tpl_vars['jieqi_url'].'/message.php?box=inbox" target="_blank">短消息<b style="color:#f60">';
if($this->_tpl_vars['jieqi_newmessage'] > 0){
echo '('.$this->_tpl_vars['jieqi_newmessage'].')';
}
echo '</b></a>
        <a href="'.$this->_tpl_vars['jieqi_user_url'].'/logout.php?jumpurl='.urlencode($this->_tpl_vars['jieqi_thisurl']).'" class="fr header-user" style="color:#f60">退出</a>
        <a href="'.$this->_tpl_vars['jieqi_url'].'/userdetail.php" class="fr header-user">'.$this->_tpl_vars['jieqi_username'].'<span>|</span></a>
		';
}
echo '
    </div>
	
</div>

';
if($this->_tpl_vars['jieqi_top_bar'] != ""){
echo $this->_tpl_vars['jieqi_top_bar'];
}
if($this->_tpl_vars['jieqi_showtblock'] == 1){
if (empty($this->_tpl_vars['jieqi_tblocks'])) $this->_tpl_vars['jieqi_tblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_tblocks'])) $this->_tpl_vars['jieqi_tblocks'] = (array)$this->_tpl_vars['jieqi_tblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_tblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_tblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_tblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_tblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_tblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '
  ';
if($this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo '
  '.$this->_tpl_vars['jieqi_tblocks'][$this->_tpl_vars['i']['key']]['content'];
}
}
echo '

';
if(empty($this->_tpl_vars['jieqi_clblocks']) == false || empty($this->_tpl_vars['jieqi_crblocks']) == false){
echo '

';
if (empty($this->_tpl_vars['jieqi_clblocks'])) $this->_tpl_vars['jieqi_clblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_clblocks'])) $this->_tpl_vars['jieqi_clblocks'] = (array)$this->_tpl_vars['jieqi_clblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_clblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_clblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_clblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_clblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_clblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_clblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '

';
if (empty($this->_tpl_vars['jieqi_crblocks'])) $this->_tpl_vars['jieqi_crblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_crblocks'])) $this->_tpl_vars['jieqi_crblocks'] = (array)$this->_tpl_vars['jieqi_crblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_crblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_crblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_crblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_crblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_crblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_crblocks'][$this->_tpl_vars['i']['key']]['content'].'
 
';
}
echo '

';
}
echo '


';
if($this->_tpl_vars['jieqi_showlblock'] == 1){
echo '

';
if (empty($this->_tpl_vars['jieqi_lblocks'])) $this->_tpl_vars['jieqi_lblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_lblocks'])) $this->_tpl_vars['jieqi_lblocks'] = (array)$this->_tpl_vars['jieqi_lblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_lblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_lblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_lblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_lblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_lblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_lblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '  

  ';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
}else{
}
}else{
echo '
  ';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
}else{
}
}
if($this->_tpl_vars['jieqi_showcblock'] == 1){
if (empty($this->_tpl_vars['jieqi_ctblocks'])) $this->_tpl_vars['jieqi_ctblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_ctblocks'])) $this->_tpl_vars['jieqi_ctblocks'] = (array)$this->_tpl_vars['jieqi_ctblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_ctblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_ctblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_ctblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_ctblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_ctblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_ctblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
if (empty($this->_tpl_vars['jieqi_cmblocks'])) $this->_tpl_vars['jieqi_cmblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_cmblocks'])) $this->_tpl_vars['jieqi_cmblocks'] = (array)$this->_tpl_vars['jieqi_cmblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_cmblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_cmblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_cmblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_cmblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_cmblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_cmblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
if($this->_tpl_vars['jieqi_contents'] != ""){
echo $this->_tpl_vars['jieqi_contents'];
}
if($this->_tpl_vars['jieqi_showcblock'] == 1){
if (empty($this->_tpl_vars['jieqi_cbblocks'])) $this->_tpl_vars['jieqi_cbblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_cbblocks'])) $this->_tpl_vars['jieqi_cbblocks'] = (array)$this->_tpl_vars['jieqi_cbblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_cbblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_cbblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_cbblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_cbblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_cbblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_cbblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
echo '

';
if($this->_tpl_vars['jieqi_showrblock'] == 1){
echo '

';
if (empty($this->_tpl_vars['jieqi_rblocks'])) $this->_tpl_vars['jieqi_rblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_rblocks'])) $this->_tpl_vars['jieqi_rblocks'] = (array)$this->_tpl_vars['jieqi_rblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_rblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_rblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_rblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_rblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_rblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

';
if($this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_rblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
echo '

';
}
echo '


';
if($this->_tpl_vars['jieqi_showbblock'] == 1){
if (empty($this->_tpl_vars['jieqi_bblocks'])) $this->_tpl_vars['jieqi_bblocks'] = array();
elseif (!is_array($this->_tpl_vars['jieqi_bblocks'])) $this->_tpl_vars['jieqi_bblocks'] = (array)$this->_tpl_vars['jieqi_bblocks'];
$this->_tpl_vars['i']=array();
$this->_tpl_vars['i']['columns'] = 1;
$this->_tpl_vars['i']['count'] = count($this->_tpl_vars['jieqi_bblocks']);
$this->_tpl_vars['i']['addrows'] = count($this->_tpl_vars['jieqi_bblocks']) % $this->_tpl_vars['i']['columns'] == 0 ? 0 : $this->_tpl_vars['i']['columns'] - count($this->_tpl_vars['jieqi_bblocks']) % $this->_tpl_vars['i']['columns'];
$this->_tpl_vars['i']['loops'] = $this->_tpl_vars['i']['count'] + $this->_tpl_vars['i']['addrows'];
reset($this->_tpl_vars['jieqi_bblocks']);
for($this->_tpl_vars['i']['index'] = 0; $this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['loops']; $this->_tpl_vars['i']['index']++){
	$this->_tpl_vars['i']['order'] = $this->_tpl_vars['i']['index'] + 1;
	$this->_tpl_vars['i']['row'] = ceil($this->_tpl_vars['i']['order'] / $this->_tpl_vars['i']['columns']);
	$this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['order'] % $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['column'] == 0) $this->_tpl_vars['i']['column'] = $this->_tpl_vars['i']['columns'];
	if($this->_tpl_vars['i']['index'] < $this->_tpl_vars['i']['count']){
		list($this->_tpl_vars['i']['key'], $this->_tpl_vars['i']['value']) = each($this->_tpl_vars['jieqi_bblocks']);
		$this->_tpl_vars['i']['append'] = 0;
	}else{
		$this->_tpl_vars['i']['key'] = '';
		$this->_tpl_vars['i']['value'] = '';
		$this->_tpl_vars['i']['append'] = 1;
	}
	echo '

  ';
if($this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['title'] != ""){
echo $this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['title'];
}
echo $this->_tpl_vars['jieqi_bblocks'][$this->_tpl_vars['i']['key']]['content'].'

';
}
}
if($this->_tpl_vars['jieqi_bottom_bar'] != ""){
echo $this->_tpl_vars['jieqi_bottom_bar'];
}
echo '

    <div class="novel-footer">
    <div class="container clearfix">
        <div class="fl">
            <div class="link">
              <!--  <a href="'.$this->_tpl_vars['jieqi_url'].'/page.php?template=c_about">关于'.$this->_tpl_vars['jieqi_sitename'].'</a>
                <span>|</span>
                <a href="'.$this->_tpl_vars['jieqi_url'].'/page.php?template=c_contact">联系我们</a>
                <span>|</span>
                <a href="'.$this->_tpl_vars['jieqi_url'].'/page.php?template=c_recruitment">人才招聘</a>
                <span>|</span>
                <a href="'.$this->_tpl_vars['jieqi_url'].'/page.php?template=c_business">商务合作</a>-->
                <p>Copyright (C) 2014-2024 '.$this->_tpl_vars['jieqi_sitename'].' All Rights Reserved 
            </div>
        </div>
        <div class="link fr text-right" >
           <p>客服邮箱：123456789@qq.com&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QQ：123456789<br/>ICP经营许可证编号：XICP备123456789号

</p>
        </div>
    </div>
</div>
<ul id="side-bar" class="side-pannel side-bar">
  <a href="javascript:;" class="gotop" style="display:none;"><s class="g-icon-top"></s></a>
  <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=81763559&site=qq&menu=yes" class="text"><s class="g-icon-qq1"></s><span>在线咨询</span></a>

</ul>
<script>
	$(function(){
		$(window).scroll(function(){
			if($(window).scrollTop()>100){
				$("#side-bar .gotop").fadeIn();	
			}
			else{
				$("#side-bar .gotop").hide();
			}
		});
		$("#side-bar .gotop").click(function(){
			$(\'html,body\').animate({\'scrollTop\':0},500);
		});
	});
</script>
</body>
</html>';
?>