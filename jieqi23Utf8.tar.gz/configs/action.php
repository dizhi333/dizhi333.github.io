<?php

$jieqiAction["system"] = array(
				s => array("acttitle" => "会员注册", "minscore" => "0", "islog" => "0", "isvip" => "0", "ispay" => "0", "paytitle" => "", "paybase" => 1, "paymin" => "0", "paymax" => "0", "earnscore" => "0", "earncredit" => "0", "earnvipvote" => "0", "lenmin" => "3", "lenmax" => "14"),
				s => array("acttitle" => "会员登录", "minscore" => "0", "islog" => "0", "isvip" => "0", "ispay" => "0", "paytitle" => "", "paybase" => 1, "paymin" => "0", "paymax" => "0", "earnscore" => "2", "earncredit" => "0", "earnvipvote" => "0", "lenmin" => "0", "lenmax" => "0"),
				s => array("acttitle" => "点击广告", "minscore" => "0", "islog" => "0", "isvip" => "0", "ispay" => "0", "paytitle" => "", "paybase" => 1, "paymin" => "0", "paymax" => "5", "earnscore" => "1", "earncredit" => "0", "earnvipvote" => "0", "lenmin" => "0", "lenmax" => "0"),
				s => array("acttitle" => "发站内短信", "minscore" => "0", "islog" => "0", "isvip" => "0", "ispay" => "0", "paytitle" => "", "paybase" => 1, "paymin" => "0", "paymax" => "0", "earnscore" => "0", "earncredit" => "0", "earnvipvote" => "0", "lenmin" => "0", "lenmax" => "0"),
				s => array("acttitle" => "会客室发帖", "minscore" => "0", "islog" => "0", "isvip" => "0", "ispay" => "0", "paytitle" => "", "paybase" => 1, "paymin" => "0", "paymax" => "0", "earnscore" => "0", "earncredit" => "0", "earnvipvote" => "0", "lenmin" => "0", "lenmax" => "0")
	);

?>
