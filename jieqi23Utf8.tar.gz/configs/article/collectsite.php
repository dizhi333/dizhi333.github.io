<?php

$jieqiCollectsite["1"] = array("name" => "h7u", "config" => "h7u", "url" => "http://www.h7u.net/", "subarticleid" => "", "enable" => "1");
$jieqiCollectsite["2"] = array("name" => "地鼠吧", "config" => "123", "url" => "http://www.iwodu.com", "subarticleid" => "", "enable" => "1");
$jieqiCollectsite["3"] = array("name" => "走读文学网", "config" => "goread", "url" => "1", "subarticleid" => "1", "enable" => "1");

?>
