<?php
//会员贡献等级设置(数组等级由最高排到最低)
$jieqiCredit['article'] = array();
$jieqiCredit['article'][] = array('minnum'=>'0', 'caption'=>'书迷', 'icourl'=>'/style/images/lev1.png');
$jieqiCredit['article'][] = array('minnum'=>'500', 'caption'=>'书虫', 'icourl'=>'/style/images/lev2.png');
$jieqiCredit['article'][] = array('minnum'=>'1000', 'caption'=>'书呆', 'icourl'=>'/style/images/lev3.png');
$jieqiCredit['article'][] = array('minnum'=>'2000', 'caption'=>'书狂', 'icourl'=>'/style/images/lev4.png');
$jieqiCredit['article'][] = array('minnum'=>'5000', 'caption'=>'书侠', 'icourl'=>'/style/images/lev5.png');
$jieqiCredit['article'][] = array('minnum'=>'8000', 'caption'=>'书尊', 'icourl'=>'/style/images/lev6.png');
$jieqiCredit['article'][] = array('minnum'=>'10000', 'caption'=>'书王', 'icourl'=>'/style/images/lev7.png');
$jieqiCredit['article'][] = array('minnum'=>'20000', 'caption'=>'书皇', 'icourl'=>'/style/images/lev8.png');
$jieqiCredit['article'][] = array('minnum'=>'30000', 'caption'=>'书仙', 'icourl'=>'/style/images/lev9.png');
$jieqiCredit['article'][] = array('minnum'=>'50000', 'caption'=>'书神', 'icourl'=>'/style/images/lev10.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'书圣', 'icourl'=>'/style/images/lev11.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'书白银圣', 'icourl'=>'/style/images/lev12.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'黄金书圣', 'icourl'=>'/style/images/lev13.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'白金书圣', 'icourl'=>'/style/images/lev14.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'钻石书圣', 'icourl'=>'/style/images/lev15.png');
$jieqiCredit['article'][] = array('minnum'=>'80000', 'caption'=>'至尊书圣', 'icourl'=>'/style/images/lev16.png');

?>