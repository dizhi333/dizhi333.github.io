<?php
//过滤条件设置

//排序方式
$jieqiFilter['article']['order'] = array(
	'weekvisit' => array('caption'=>'周点击', 'order'=>'weekvisit DESC', 'limit'=>'lastvisit >= <{$weekstart}>'),
	'monthvisit' => array('caption'=>'月点击', 'order'=>'monthvisit DESC', 'limit'=>'lastvisit >= <{$monthstart}>'),
	'allvisit' => array('caption'=>'总点击', 'order'=>'allvisit DESC'),
	'weekvote' => array('caption'=>'周推荐', 'order'=>'weekvote DESC', 'limit'=>'lastvote >= <{$weekstart}>'),
	'monthvote' => array('caption'=>'月推荐', 'order'=>'monthvote DESC', 'limit'=>'lastvote >= <{$monthstart}>'),
	'allvote' => array('caption'=>'总推荐', 'order'=>'allvote DESC'),
	'newhot' => array('caption'=>'新书榜', 'order'=>'allvisit DESC', 'limit'=>'postdate >= '.(time() - 2592000)),
	'weekflower' => array('caption'=>'周鲜花', 'order'=>'weekflower DESC', 'limit'=>'lastflower >= <{$weekstart}>'),
	'monthflower' => array('caption'=>'月鲜花', 'order'=>'monthflower DESC', 'limit'=>'lastflower >= <{$monthstart}>'),
	'allflower' => array('caption'=>'总鲜花', 'order'=>'allflower DESC'),
	'monthvipvote' => array('caption'=>'本月月票', 'order'=>'monthvipvote DESC', 'limit'=>'lastvipvote >= <{$monthstart}>'),
	'allvipvote' => array('caption'=>'总月票榜', 'order'=>'allvipvote DESC'),
	'size' => array('caption'=>'字数', 'order'=>'size DESC'),
	'viptime' => array('caption'=>'最新签约', 'order'=>'viptime DESC'),
	'goodnum' => array('caption'=>'收藏数', 'order'=>'goodnum DESC'),
	'lastupdate' => array('caption'=>'更新时间', 'order'=>'lastupdate DESC'),
	'postdate' => array('caption'=>'入库时间', 'order'=>'postdate DESC'),
	'toptime' => array('caption'=>'编辑推荐', 'order'=>'toptime DESC')
);

//字数限制(注意：size 在数据库是字节数，是实际字数的2倍)
$jieqiFilter['article']['size'] = array(
	1 => array('caption'=>'30万以下', 'limit'=>'size < 600000'),
	2 => array('caption'=>'30-50万', 'limit'=>'size >= 600000 AND size < 1000000'),
	3 => array('caption'=>'50-100万', 'limit'=>'size >= 1000000 AND size < 2000000'),
	4 => array('caption'=>'100-200万', 'limit'=>'size >= 2000000 AND size < 4000000'),
	5 => array('caption'=>'200万以上', 'limit'=>'size >= 4000000')
);

//更新时间
$jieqiFilter['article']['update'] = array(
	1 => array('caption'=>'三日内', 'days'=>3),
	2 => array('caption'=>'七日内', 'days'=>7),
	3 => array('caption'=>'半月内', 'days'=>15),
	4 => array('caption'=>'一月内', 'days'=>30)
);

//写作进度
$jieqiFilter['article']['isfull'] = array(
	2 => array('caption'=>'正在连载', 'limit'=>'fullflag = 0'),
	1 => array('caption'=>'已经全本', 'limit'=>'fullflag > 0')
);

//所属频道
$jieqiFilter['article']['rgroup'] = array(
	1 => array('caption'=>'男生', 'limit'=>'rgroup = 1'),
	2 => array('caption'=>'女生', 'limit'=>'rgroup = 2'),
	3 => array('caption'=>'参赛作品', 'limit'=>'rgroup = 3'),
);

//VIP状态
$jieqiFilter['article']['isvip'] = array(
	1 => array('caption'=>'免费作品', 'limit'=>'isvip = 0'),
	2 => array('caption'=>'VIP作品', 'limit'=>'isvip > 0'),
	3 => array('caption'=>'包月作品', 'limit'=>'monthly > 0'),
	4 => array('caption'=>'精品作品', 'limit'=>'quality > 0')
);

?>