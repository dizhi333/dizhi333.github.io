<?php
$jieqiBlocks['0'] = array (
  'bid' => 0,
  'blockname' => '排 行 榜',
  'module' => 'article',
  'filename' => 'block_toplist',
  'classname' => 'BlockArticleToplist',
  'side' => 1,
  'title' => '排 行 榜',
  'vars' => '',
  'template' => '',
  'contenttype' => 0,
  'custom' => 0,
  'publish' => 3,
  'hasvars' => 0,
  'showtype' => 0,
);
$jieqiBlocks['1'] = array (
  'bid' => 0,
  'blockname' => '小说搜索',
  'module' => 'article',
  'filename' => 'block_search',
  'classname' => 'BlockArticleSearch',
  'side' => 1,
  'title' => '小说搜索',
  'vars' => '',
  'template' => '',
  'contenttype' => 0,
  'custom' => 0,
  'publish' => 3,
  'hasvars' => 0,
  'showtype' => 0,
);

?>