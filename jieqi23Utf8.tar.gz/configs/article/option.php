<?php
/**
 * 数据表里面可选项和值的对应关系
 * multiple 0 单选 1 对选
 * default 默认值
 * items 选项列表
*/
//管理授权
$jieqiOption['article']['authorflag'] = array('multiple' => 0, 'default' => 0, 'items' => array(1 => '授权给该作者', 0 => '暂时不予授权'));

//授权级别
$jieqiOption['article']['permission'] = array('multiple' => 0, 'default' => 2, 'items' => array(2 => '暂未授权', 1 => '独家作品', 0 => '授权作品'));

//首发状态
$jieqiOption['article']['firstflag'] = array('multiple' => 0, 'default' => 1, 'items' => array(1 => '本站首发', 0 => '他站首发'));

//连载状态
$jieqiOption['article']['fullflag'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '连载', 1 => '全本'));
$jieqiOption['article']['progress'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '新书上传', 1 => '情节展开', 2 => '精彩纷呈', 3 => '接近尾声', 4 => '已经完本'));

//是否VIP
$jieqiOption['article']['isvip'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '不限', 1 => 'VIP', 2 => '免费', 3 => '包月'));

//显示状态
$jieqiOption['article']['display'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '显示', 1 => '待审', 2=>'隐藏'));

//是否签约
$jieqiOption['article']['issign'] = array('multiple' => 0, 'default' => 0, 'items' => array(10 => 'VIP签约', 1 => '普通签约', 0 => '免费小说'));

//所属频道
$jieqiOption['article']['rgroup'] = array('multiple' => 0, 'default' => 0, 'items' => array(1 => '男生频道', 2 => '女生频道', 3 => '免费小说'));

//购买包月选项
$jieqiOption['article']['jieqimonthly'] = array('multiple' => 0, 'default' => 0, 'items' => array(1 => '1000', 3 => '3000', 6 => '6000', 12 => '12000'));

//包月选项
$jieqiOption['article']['monthly'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '未包月作品', 1 => '包月作品'));

//更新记录状态
$jieqiOption['article']['power'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '新增', 1 => '修改'));

//是否买断状态
$jieqiOption['article']['buyout'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '否', 1 => '是'));

//是否打折状态
$jieqiOption['article']['discount'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '否', 1 => '是'));

//是否精品状态
$jieqiOption['article']['quality'] = array('multiple' => 0, 'default' => 0, 'items' => array(0 => '否', 1 => '是'));

//申请书籍类型
$jieqiOption['article']['apply'] = array('multiple' => 0, 'default' => 0, 'items' => array( 1 => 'VIP', 2 => '包月', 3 => '签约', 4 => '精品', 5 => '封面推荐', 6 => 'VIP免费'));
?>