<?php
$jieqiPower['article'] = array (
  'adminconfig' => 
  array (
    'caption' => '管理参数设置',
    'groups' => false,
    'description' => '',
  ),
  'adminpower' => 
  array (
    'caption' => '管理权限设置',
    'groups' => false,
    'description' => '',
  ),
  'authorpanel' => 
  array (
    'caption' => '进入作家专栏',
    'groups' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '7',
      5 => '8',
      6 => '9',
      7 => '10',
    ),
    'description' => '',
  ),
  'newarticle' => 
  array (
    'caption' => '发表小说',
    'groups' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '7',
      5 => '8',
      6 => '9',
      7 => '10',
    ),
    'description' => '包括发表新小说、并且可以对自己的小说有增加章节、编辑章节和删除章节权限',
  ),
  'transarticle' => 
  array (
    'caption' => '转载小说',
    'groups' => 
    array (
      0 => '8',
      1 => '9',
      2 => '10',
    ),
    'description' => '',
  ),
  'needcheck' => 
  array (
    'caption' => '发表小说不需要审查',
    'groups' => 
    array (
      0 => '7',
      1 => '8',
      2 => '9',
      3 => '10',
    ),
    'description' => '',
  ),
  'manageallarticle' => 
  array (
    'caption' => '管理他人小说',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
  'delmyarticle' => 
  array (
    'caption' => '删除自己小说',
    'groups' => 
    array (
      0 => '7',
      1 => '8',
      2 => '9',
      3 => '10',
    ),
    'description' => '',
  ),
  'delallarticle' => 
  array (
    'caption' => '删除他人小说',
    'groups' => 
    array (
      0 => '10',
    ),
    'description' => '',
  ),
  'manageallreview' => 
  array (
    'caption' => '管理他人书评',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
  'newdraft' => 
  array (
    'caption' => '使用草稿箱',
    'groups' => 
    array (
      0 => '10',
    ),
    'description' => '允许作者将章节保存到草稿箱的权限',
  ),
  'managesort' => 
  array (
    'caption' => '管理小说分类',
    'groups' => false,
    'description' => '管理小说类别',
  ),
  'articleupattach' => 
  array (
    'caption' => '发文允许上传附件',
    'groups' => false,
    'description' => '',
  ),
  'reviewupattach' => 
  array (
    'caption' => '书评允许上传附件',
    'groups' => false,
    'description' => '',
  ),
  'viewuplog' => 
  array (
    'caption' => '查看更新记录',
    'groups' => 
    array (
      0 => '8',
      1 => '9',
      2 => '10',
    ),
    'description' => '',
  ),
  'newreview' => 
  array (
    'caption' => '发表书评',
    'groups' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '7',
      5 => '8',
      6 => '9',
      7 => '10',
    ),
    'description' => '',
  ),
  'articlemodify' => 
  array (
    'caption' => '修改小说统计',
    'groups' => 
    array (
      0 => '10',
    ),
    'description' => '',
  ),
  'setwriter' => 
  array (
    'caption' => '审核会员申请成为作者',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
  'uptiming' => 
  array (
    'caption' => '定时发表章节',
    'groups' => false,
    'description' => '',
  ),
  'edittime' => 
  array (
    'caption' => '允许24小时后章节编辑',
    'groups' => false,
    'description' => '',
  ),
  'delhischapters' => 
  array (
    'caption' => '允许删除自己小说章节',
    'groups' => 
    array (
      0 => '7',
      1 => '8',
      2 => '9',
      3 => '10',
    ),
    'description' => '',
  ),
  'needupaudit' => 
  array (
    'caption' => '发表章节不需要审查',
    'groups' => 
    array (
      0 => '7',
      1 => '8',
      2 => '9',
      3 => '10',
    ),
    'description' => '',
  ),
  'apply' => 
  array (
    'caption' => '申请书籍包月、VIP、精品、封面',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
  'articleedit' => 
  array (
    'caption' => '允许编辑小说信息',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
  'manageisvip' => 
  array (
    'caption' => '允许VIP、免费章节切换',
    'groups' => 
    array (
      0 => '9',
      1 => '10',
    ),
    'description' => '',
  ),
);

?>