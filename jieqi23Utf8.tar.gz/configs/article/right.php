<?php
$jieqiRight['article'] = array (
  'maxbookmarks' => 
  array (
    'caption' => '书架最大收藏量',
    'honors' => 
    array (
      1 => '',
      2 => '',
      3 => '',
      4 => '',
      5 => '',
      6 => '',
    ),
    'rescription' => '',
  ),
  'dayvotes' => 
  array (
    'caption' => '每天允许推荐次数',
    'honors' => 
    array (
      1 => '',
      2 => '',
      3 => '',
      4 => '',
      5 => '',
      6 => '',
    ),
    'rescription' => '',
  ),
  'dayrates' => 
  array (
    'caption' => '每天允许评分次数',
    'honors' => 
    array (
      1 => '',
      2 => '',
      3 => '',
      4 => '',
      5 => '',
      6 => '',
    ),
    'rescription' => '',
  ),
);

?>