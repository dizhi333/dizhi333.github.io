<?php
$jieqiCollect['sitename'] = '走读文学';
$jieqiCollect['siteurl'] = 'http://goread.net';
$jieqiCollect['subarticleid'] = '';
$jieqiCollect['subchapterid'] = '';
$jieqiCollect['proxy_host'] = '';
$jieqiCollect['proxy_port'] = '';
$jieqiCollect['autoclear'] = '0';
$jieqiCollect['defaultfull'] = '0';
$jieqiCollect['referer'] = '0';
$jieqiCollect['pagecharset'] = 'auto';
$jieqiCollect['urlarticle'] = 'http://goread.net/modules/article/articleinfo.php?id=<{articleid}>';
$jieqiCollect['articletitle']['left'] = '<h2>';
$jieqiCollect['articletitle']['right'] = '</h2>';
$jieqiCollect['articletitle']['middle'] = '!!!!';
$jieqiCollect['author']['left'] = '<a href="#" target="_blank"><img src="/images/noavatar.jpg" alt="';
$jieqiCollect['author']['right'] = '"></a>';
$jieqiCollect['author']['middle'] = '!!!!';
$jieqiCollect['sort']['left'] = '<span class="cate"><a>';
$jieqiCollect['sort']['right'] = '</a></span>';
$jieqiCollect['sort']['middle'] = '!!!!';
$jieqiCollect['keyword']['left'] = '<h2>';
$jieqiCollect['keyword']['right'] = '</h2>';
$jieqiCollect['keyword']['middle'] = '!!!!';
$jieqiCollect['intro']['left'] = '<pre class="note">';
$jieqiCollect['intro']['right'] = '</pre>
	    	        		           <pre class="note"></pre>';
$jieqiCollect['intro']['middle'] = '****';
$jieqiCollect['articleimage']['left'] = '<img src="';
$jieqiCollect['articleimage']['right'] = '" alt="!" class="book-cover" width="200" height="280">';
$jieqiCollect['articleimage']['middle'] = '~~~~';
$jieqiCollect['filterimage'] = '';
$jieqiCollect['indexlink'] = '';
$jieqiCollect['fullarticle'] = '';
$jieqiCollect['sortid']['玄幻'] = '1';
$jieqiCollect['sortid']['仙侠'] = '2';
$jieqiCollect['sortid']['都市'] = '3';
$jieqiCollect['sortid']['历史'] = '4';
$jieqiCollect['sortid']['军事'] = '4';
$jieqiCollect['sortid']['科幻'] = '5';
$jieqiCollect['sortid']['灵异'] = '5';
$jieqiCollect['sortid']['游戏'] = '6';
$jieqiCollect['sortid']['现言'] = '3';
$jieqiCollect['sortid']['幻想'] = '6';
$jieqiCollect['sortid']['其它'] = '1';
$jieqiCollect['urlindex'] = 'http://goread.net/modules/article/reader.php?aid=<{articleid}>';
$jieqiCollect['volume'] = '';
$jieqiCollect['chapter']['left'] = '<a href="http://goread.net/modules/article/reader.php?aid=$&cid=$" class="name">';
$jieqiCollect['chapter']['right'] = '</a>';
$jieqiCollect['chapter']['middle'] = '!!!!';
$jieqiCollect['chapterid']['left'] = '<a href="http://goread.net/modules/article/reader.php?aid=$&cid=';
$jieqiCollect['chapterid']['right'] = '" class="name">!</a>';
$jieqiCollect['chapterid']['middle'] = '$$$$';
$jieqiCollect['urlchapter'] = 'http://goread.net/modules/article/reader.php?aid=<{articleid}>&cid=<{chapterid}>';
$jieqiCollect['content']['left'] = 'div class="page-content " id="ChapterContents">';
$jieqiCollect['content']['right'] = '</div>

































<a href="javascript:" action-type="@boost" class="boost" title="打赏"></a>';
$jieqiCollect['content']['middle'] = '****';
$jieqiCollect['contentfilter'] = '';
$jieqiCollect['contentreplace'] = '';
$jieqiCollect['collectimage'] = '1';
$jieqiCollect['imagetranslate'] = '0';
$jieqiCollect['addimagewater'] = '0';
$jieqiCollect['imagebgcolor'] = '';
$jieqiCollect['imageareaclean'] = '';
$jieqiCollect['imagecolorclean'] = '';
$jieqiCollect['listcollect']['0']['title'] = '最近更新';
$jieqiCollect['listcollect']['0']['urlpage'] = 'http://goread.net/modules/article/articlefilter.php?order=lastupdate&page=1';
$jieqiCollect['listcollect']['0']['articleid']['left'] = '<a data-collect-index="1" target="_blank" class="title" hre';
$jieqiCollect['listcollect']['0']['articleid']['right'] = '"http://goread.net/modules/article/articleinfo.php?id=43">!</a>';
$jieqiCollect['listcollect']['0']['articleid']['middle'] = '$$$$';
$jieqiCollect['listcollect']['0']['startpageid'] = '1';
$jieqiCollect['listcollect']['0']['nextpageid'] = '++';
$jieqiCollect['listcollect']['0']['maxpagenum'] = '1';

?>