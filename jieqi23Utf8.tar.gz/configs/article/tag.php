<?php
$jieqiTag['article'] = array (
  8 => 
  array (
    'caption' => '玄幻',
  ),
  9 => 
  array (
    'caption' => '热血',
  ),
  10 => 
  array (
    'caption' => '升级',
  ),
  11 => 
  array (
    'caption' => '重生',
  ),
  14 => 
  array (
    'caption' => '高手',
  ),
  13 => 
  array (
    'caption' => '兵王',
  ),
  12 => 
  array (
    'caption' => '都市',
  ),
  15 => 
  array (
    'caption' => '灵异',
  ),
  16 => 
  array (
    'caption' => '爱情',
  ),
  17 => 
  array (
    'caption' => '恶魔王爷',
  ),
  18 => 
  array (
    'caption' => '冷千金',
  ),
  19 => 
  array (
    'caption' => '魔幻',
  ),
  20 => 
  array (
    'caption' => '吸血鬼',
  ),
  21 => 
  array (
    'caption' => '同人',
  ),
  22 => 
  array (
    'caption' => '青春校园',
  ),
  23 => 
  array (
    'caption' => '装逼',
  ),
  24 => 
  array (
    'caption' => '无耻',
  ),
  25 => 
  array (
    'caption' => '现代',
  ),
  26 => 
  array (
    'caption' => '言情',
  ),
  29 => 
  array (
    'caption' => '苏墨',
  ),
  36 => 
  array (
    'caption' => '洪荒',
  ),
  37 => 
  array (
    'caption' => '总裁',
  ),
  39 => 
  array (
    'caption' => '虐恋',
  ),
  40 => 
  array (
    'caption' => '战斗',
  ),
  43 => 
  array (
    'caption' => '道士',
  ),
  44 => 
  array (
    'caption' => '凡人',
  ),
  45 => 
  array (
    'caption' => '感情',
  ),
  46 => 
  array (
    'caption' => '末世',
  ),
  48 => 
  array (
    'caption' => '升级流',
  ),
  47 => 
  array (
    'caption' => '丧尸',
  ),
  49 => 
  array (
    'caption' => '无女主',
  ),
  50 => 
  array (
    'caption' => 'l',
  ),
  51 => 
  array (
    'caption' => '古言',
  ),
  52 => 
  array (
    'caption' => '搞笑',
  ),
  53 => 
  array (
    'caption' => '穿越',
  ),
  54 => 
  array (
    'caption' => '豪门恩怨',
  ),
  55 => 
  array (
    'caption' => '腹黑',
  ),
  56 => 
  array (
    'caption' => '萌娃',
  ),
  57 => 
  array (
    'caption' => '悬疑',
  ),
  58 => 
  array (
    'caption' => '惊悚',
  ),
  59 => 
  array (
    'caption' => '破案',
  ),
  60 => 
  array (
    'caption' => '犯罪',
  ),
  61 => 
  array (
    'caption' => '沈佳柔',
  ),
  62 => 
  array (
    'caption' => '凌靖宇',
  ),
  63 => 
  array (
    'caption' => '幻想言情',
  ),
  64 => 
  array (
    'caption' => 'w',
  ),
  71 => 
  array (
    'caption' => '落实',
  ),
  72 => 
  array (
    'caption' => '传统武侠',
  ),
);

?>