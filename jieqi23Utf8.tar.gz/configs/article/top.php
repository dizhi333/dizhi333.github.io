<?php
//排行榜类型配置
$jieqiTop['article']['toplist'] = array('caption'=>'排行预览榜', 'description'=>'', 'where'=>'', 'sort'=>'toplist', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['allvisit'] = array('caption'=>'总点击榜', 'description'=>'', 'where'=>'', 'sort'=>'allvisit', 'order'=>'DESC', 'default'=>1, 'publish' => '1');
$jieqiTop['article']['allvote'] = array('caption'=>'总推荐榜', 'description'=>'', 'where'=>'', 'sort'=>'allvote', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['monthvisit'] = array('caption'=>'月点击榜', 'description'=>'', 'where'=>'lastvisit >= <{$monthstart}>', 'sort'=>'monthvisit', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['monthvote'] = array('caption'=>'月推荐榜', 'description'=>'', 'where'=>'lastvote >= <{$monthstart}>', 'sort'=>'monthvote', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['weekvisit'] = array('caption'=>'周点击榜', 'description'=>'', 'where'=>'lastvisit >= <{$weekstart}>', 'sort'=>'weekvisit', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['weekvote'] = array('caption'=>'周推荐榜', 'description'=>'', 'where'=>'lastvote >= <{$weekstart}>', 'sort'=>'weekvote', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['dayvisit'] = array('caption'=>'日点击榜', 'description'=>'', 'where'=>'lastvisit >= <{$daystart}>', 'sort'=>'dayvisit', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['dayvote'] = array('caption'=>'日推荐榜', 'description'=>'', 'where'=>'lastvote >= <{$daystart}>', 'sort'=>'dayvote', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['postdate'] = array('caption'=>'最新入库', 'description'=>'', 'where'=>'', 'sort'=>'postdate', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['lastupdate'] = array('caption'=>'最近更新', 'description'=>'', 'where'=>'', 'sort'=>'lastupdate', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['goodnum'] = array('caption'=>'总收藏榜', 'description'=>'', 'where'=>'', 'sort'=>'goodnum', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['daysize'] = array('caption'=>'日字数榜', 'description'=>'', 'where'=>'', 'sort'=>'daysize', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weeksize'] = array('caption'=>'周字数榜', 'description'=>'', 'where'=>'', 'sort'=>'weeksize', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthsize'] = array('caption'=>'月字数榜', 'description'=>'', 'where'=>'', 'sort'=>'monthsize', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['size'] = array('caption'=>'总字数榜', 'description'=>'', 'where'=>'', 'sort'=>'size', 'order'=>'DESC', 'default'=>0, 'publish' => '1');
$jieqiTop['article']['toptime'] = array('caption'=>'本站推荐', 'description'=>'', 'where'=>'', 'sort'=>'toptime', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['signtime'] = array('caption'=>'最新签约', 'description'=>'', 'where'=>'', 'sort'=>'signtime', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['viptime'] = array('caption'=>'VIP最近更新', 'description'=>'', 'where'=>'', 'sort'=>'viptime', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weekflower'] = array('caption'=>'周鲜花榜', 'description'=>'', 'where'=>'lastflower >= <{$weekstart}>', 'sort'=>'weekflower', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthflower'] = array('caption'=>'月鲜花榜', 'description'=>'', 'where'=>'lastflower >= <{$monthstart}>', 'sort'=>'monthflower', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['allflower'] = array('caption'=>'总鲜花榜', 'description'=>'', 'where'=>'', 'sort'=>'allflower', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weekegg'] = array('caption'=>'周鸡蛋榜', 'description'=>'', 'where'=>'lastegg >= <{$weekstart}>', 'sort'=>'weekegg', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthegg'] = array('caption'=>'月鸡蛋榜', 'description'=>'', 'where'=>'lastegg >= <{$monthstart}>', 'sort'=>'monthegg', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['allegg'] = array('caption'=>'总鸡蛋榜', 'description'=>'', 'where'=>'', 'sort'=>'allegg', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['dayvipvote'] = array('caption'=>'日月票榜', 'description'=>'', 'where'=>'lastvipvote >= <{$daystart}>', 'sort'=>'dayvipvote', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weekvipvote'] = array('caption'=>'周月票榜', 'description'=>'', 'where'=>'lastvipvote >= <{$weekstart}>', 'sort'=>'weekvipvote', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthvipvote'] = array('caption'=>'本月月票榜', 'description'=>'', 'where'=>'lastvipvote >= <{$monthstart}>', 'sort'=>'monthvipvote', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['allvipvote'] = array('caption'=>'总月票榜', 'description'=>'', 'where'=>'', 'sort'=>'allvipvote', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['daydown'] = array('caption'=>'日下载量', 'description'=>'', 'where'=>'lastdown >= <{$daystart}>', 'sort'=>'daydown', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weekdown'] = array('caption'=>'周下载量', 'description'=>'', 'where'=>'lastdown >= <{$weekstart}>', 'sort'=>'weekdown', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthdown'] = array('caption'=>'月下载量', 'description'=>'', 'where'=>'lastdown >= <{$monthstart}>', 'sort'=>'monthdown', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['alldown'] = array('caption'=>'总下载量', 'description'=>'', 'where'=>'', 'sort'=>'alldown', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['daysale'] = array('caption'=>'日销售量', 'description'=>'', 'where'=>'lastsale >= <{$daystart}>', 'sort'=>'daysale', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['weeksale'] = array('caption'=>'周销售量', 'description'=>'', 'where'=>'lastsale >= <{$weekstart}>', 'sort'=>'weeksale', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['monthsale'] = array('caption'=>'月销售量', 'description'=>'', 'where'=>'lastsale >= <{$monthstart}>', 'sort'=>'monthsale', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['allsale'] = array('caption'=>'总销售量', 'description'=>'', 'where'=>'', 'sort'=>'allsale', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['articleid'] = array('caption'=>'小说ID', 'description'=>'', 'where'=>'', 'sort'=>'articleid', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['reviewsnum'] = array('caption'=>'评论数量', 'description'=>'', 'where'=>'', 'sort'=>'reviewsnum', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['ratenum'] = array('caption'=>'评分', 'description'=>'', 'where'=>'', 'sort'=>'ratenum', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['ratesum'] = array('caption'=>'评分总人数', 'description'=>'', 'where'=>'', 'sort'=>'ratesum', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['sumegold'] = array('caption'=>'虚拟币收入', 'description'=>'', 'where'=>'', 'sort'=>'sumegold', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['sumtip'] = array('caption'=>'打赏', 'description'=>'', 'where'=>'', 'sort'=>'sumtip', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['sumhurry'] = array('caption'=>'催更', 'description'=>'', 'where'=>'', 'sort'=>'sumhurry', 'order'=>'DESC', 'default'=>0, 'publish' => '0');
$jieqiTop['article']['sumgift'] = array('caption'=>'礼物', 'description'=>'', 'where'=>'', 'sort'=>'sumgift', 'order'=>'DESC', 'default'=>0, 'publish' => '0');

?>