<?php
$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'排行榜', 'module'=>'article', 'filename'=>'block_toplist', 'classname'=>'BlockArticleToplist', 'side'=>0, 'title'=>'排行榜', 'vars'=>'', 'template'=>'block_toplist.html', 'contenttype'=>0, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'分类阅读', 'module'=>'article', 'filename'=>'block_sort', 'classname'=>'BlockArticleSort', 'side'=>0, 'title'=>'分类阅读', 'vars'=>'', 'template'=>'block_sort.html', 'contenttype'=>0, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'本站推荐', 'module'=>'article', 'filename'=>'block_articlelist', 'classname'=>'BlockArticleArticlelist', 'side'=>0, 'title'=>'本站推荐', 'vars'=>'toptime,10,0,0,0,0', 'template'=>'block_articlelist.html', 'contenttype'=>4, 'custom'=>0, 'publish'=>3, 'hasvars'=>1);

$jieqiBlocks[]=array('bid'=>0, 'blockname'=>'小说搜索', 'module'=>'article', 'filename'=>'block_search', 'classname'=>'BlockArticleSearch', 'side'=>0, 'title'=>'作品搜索', 'vars'=>'', 'template'=>'', 'contenttype'=>0, 'custom'=>0, 'publish'=>3, 'hasvars'=>0);
?>