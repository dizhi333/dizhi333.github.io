<?php

$jieqiAdminmenu["badge"][] = array("layer" => 0, "caption" => "参数设置", "command" => JIEQI_URL . "/admin/configs.php?mod=badge", "target" => 0, "publish" => 1);
$jieqiAdminmenu["badge"][] = array("layer" => 0, "caption" => "权限设置", "command" => JIEQI_URL . "/admin/power.php?mod=badge", "target" => 0, "publish" => 1);
$jieqiAdminmenu["badge"][] = array("layer" => 0, "caption" => "徽章管理", "command" => $GLOBALS["jieqiModules"]["badge"]["url"] . "/admin/badgelist.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["badge"][] = array("layer" => 0, "caption" => "授予记录", "command" => $GLOBALS["jieqiModules"]["badge"]["url"] . "/admin/badgeaward.php", "target" => 0, "publish" => 1);

?>
