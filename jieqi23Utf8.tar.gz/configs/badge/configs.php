<?php

$jieqiConfigs["badge"] = array("imagedir" => "image", "sysimgtype" => ".png", "imagetype" => ".gif .jpg .jpeg .png", "maximagesize" => "30", "defaultmaxnum" => "0", "userbadgenum" => 5, "pagenum" => 50, "awardpnum" => 50);

?>
