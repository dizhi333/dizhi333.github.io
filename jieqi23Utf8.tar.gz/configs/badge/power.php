<?php

$jieqiPower["badge"]["managesystem"]["caption"] = "管理系统徽章";
$jieqiPower["badge"]["managesystem"]["groups"] = "";
$jieqiPower["badge"]["managesystem"]["description"] = "可以修改系统默认的徽章";
$jieqiPower["badge"]["managemodule"]["caption"] = "管理模块徽章";
$jieqiPower["badge"]["managemodule"]["groups"] = "";
$jieqiPower["badge"]["managemodule"]["description"] = "可以增加、修改和删除模块相关徽章";
$jieqiPower["badge"]["managecustom"]["caption"] = "管理自定义徽章";
$jieqiPower["badge"]["managecustom"]["groups"] = "";
$jieqiPower["badge"]["managecustom"]["description"] = "可以增加、修改和删除自定义类型徽章";
$jieqiPower["badge"]["awardview"]["caption"] = "查看徽章授予记录";
$jieqiPower["badge"]["awardview"]["groups"] = "";
$jieqiPower["badge"]["awardview"]["description"] = "";

?>
