<?php

$jieqiType["badge"]["1"] = array("btypeid" => "1", "title" => "等级徽章", "sysflag" => "1");
$jieqiType["badge"]["2"] = array("btypeid" => "2", "title" => "头衔徽章", "sysflag" => "1");
$jieqiType["badge"]["3"] = array("btypeid" => "3", "title" => "vip徽章", "sysflag" => "1");
$jieqiType["badge"]["1010"] = array("btypeid" => "1010", "title" => "荣誉徽章", "sysflag" => "2");
$jieqiType["badge"]["2010"] = array("btypeid" => "2010", "title" => "圈子徽章", "sysflag" => "3");
$jieqiType["badge"]["3010"] = array("btypeid" => "3010", "title" => "活动徽章", "sysflag" => "2");

?>
