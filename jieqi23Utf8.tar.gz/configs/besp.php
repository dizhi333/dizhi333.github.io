<?php

$jieqiBesp[1] = array("caption" => "1级包月", "egold" => 500);
$jieqiBesp[2] = array("caption" => "2级包月", "egold" => 500);
$jieqiBesp[3] = array("caption" => "3级包月", "egold" => 500);
$jieqiBesp[4] = array("caption" => "4级包月", "egold" => 500);

?>
