<?php

$jieqiBlockfiles = array();
$jieqiBlockfiles[] = array("module" => "system", "filename" => "blocks", "caption" => "电脑站-网站首页", "description" => "");
$jieqiBlockfiles[] = array("module" => "article", "filename" => "indexblocks", "caption" => "手机站-网站首页", "description" => "");
$jieqiBlockfiles[] = array("module" => "article", "filename" => "groupblocks", "caption" => "手机站-分类频道", "description" => "");

?>
