<?php

$jieqiBlocks[1] = array("bid" => 0, "blockname" => "用户登录", "module" => "system", "filename" => "block_login", "classname" => "BlockSystemLogin", "side" => -1, "title" => "用户登录", "vars" => "", "template" => "", "contenttype" => 4, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[2] = array("bid" => 1, "blockname" => "本站公告", "module" => "system", "filename" => "", "classname" => "BlockSystemCustom", "side" => -1, "title" => "本站公告", "vars" => "", "template" => "", "contenttype" => 1, "custom" => 1, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[3] = array("bid" => 0, "blockname" => "小说搜索", "module" => "article", "filename" => "block_search", "classname" => "BlockArticleSearch", "side" => -1, "title" => "小说搜索", "vars" => "", "template" => "", "contenttype" => 0, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[4] = array("bid" => 0, "blockname" => "点击排行", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => 0, "title" => "点击排行", "vars" => "allvisit,10,0,0,0,0", "template" => "block_articlelist.html", "contenttype" => 4, "custom" => 0, "publish" => 3, "hasvars" => 1);
$jieqiBlocks[5] = array("bid" => 0, "blockname" => "最近更新", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => 5, "title" => "最近更新", "vars" => "lastupdate,10,0,0,0,0", "template" => "block_lastupdate.html", "contenttype" => 4, "custom" => 0, "publish" => 3, "hasvars" => 1);
$jieqiBlocks[6] = array("bid" => 0, "blockname" => "推荐排行", "module" => "article", "filename" => "block_articlelist", "classname" => "BlockArticleArticlelist", "side" => 0, "title" => "推荐排行", "vars" => "allvote,10,0,0,0,0", "template" => "block_articlelist.html", "contenttype" => 4, "custom" => 0, "publish" => 3, "hasvars" => 1);

?>
