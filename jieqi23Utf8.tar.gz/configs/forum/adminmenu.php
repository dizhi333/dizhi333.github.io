<?php

$jieqiAdminmenu["forum"][] = array("layer" => 0, "caption" => "参数设置", "command" => JIEQI_URL . "/admin/configs.php?mod=forum", "target" => 0, "publish" => 1);
$jieqiAdminmenu["forum"][] = array("layer" => 0, "caption" => "权限管理", "command" => JIEQI_URL . "/admin/power.php?mod=forum", "target" => 0, "publish" => 1);
$jieqiAdminmenu["forum"][] = array("layer" => 0, "caption" => "网站管理", "command" => $GLOBALS["jieqiModules"]["forum"]["url"] . "/admin/forumlist.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["forum"][] = array("layer" => 0, "caption" => "批量删帖", "command" => $GLOBALS["jieqiModules"]["forum"]["url"] . "/admin/forumdels.php", "target" => 0, "publish" => 1);

?>
