<?php

$jieqiConfigs["forum"] = array("topicnum" => 30, "postnum" => 10, "quotelength" => 200, "searchtype" => "0", "minsearchlen" => 4, "maxsearchres" => 300, "minsearchtime" => 30, "textwatermark" => "", "scoretopic" => 2, "scorereply" => 1, "scoregoodtopic" => 5, "attachdir" => "attachment", "attachurl" => "", "attachtype" => "gif jpg jpeg png bmp swf zip rar txt", "maxattachnum" => 5, "maximagesize" => 1000, "maxfilesize" => 1000, "attachwater" => "0", "attachwimage" => "watermark.gif", "attachwtrans" => 30, "attachwquality" => 90);

?>
