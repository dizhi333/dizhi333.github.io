<?php

$jieqiForumForumcat["0"]["catid"] = "1";
$jieqiForumForumcat["0"]["cattitle"] = "默认分类";
$jieqiForumForumcat["0"]["catorder"] = "1";

?>
