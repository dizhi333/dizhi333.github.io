<?php

$jieqiForumForums["0"] = array("forumid" => "1", "catid" => "1", "forumname" => "公告专栏", "forumorder" => "1");

?>
