<?php

$jieqiPower["forum"] = array(
				s => array("caption" => "管理参数设置", "groups" => false, "description" => ""),
				s => array("caption" => "管理权限设置", "groups" => false, "description" => ""),
				s => array(
					s => "管理网站",
					s => array("10"),
					s => ""
		)
	);

?>
