<?php
require(dirname(__FILE__)."/define.php");
function getdomain($url) 
{
	$host = strtolower ( $url );
	if (strpos ( $host, '/' ) !== false) 
	{
		$parse = @parse_url ( $host );
		$host = $parse ['host'];
	}
	$topleveldomaindb = array ('com', 'shop', 'online', 'cn.com', 'cn', 'art', 'xin', 'top', 'vip', 'edu', 'gov', 'int', 'mil', 'net', 'org', 'biz', 'info', 'pro', 'name', 'museum', 'coop', 'aero', 'xxx', 'idv', 'mobi', 'cc', 'me', 'xyz' );
	$str = '';
	foreach ( $topleveldomaindb as $v ) 
	{
		$str .= ($str ? '|' : '') . $v;
	}
	$matchstr = "[^\.]+\.(?:(" . $str . ")|\w{2}|((" . $str . ")\.\w{2}))$";
	if (preg_match ( "/" . $matchstr . "/ies", $host, $matchs )) 
	{
		$domain = $matchs ['0'];
	}
	else 
	{
		$domain = $host;
	}
	return $domain;
}
$str = constant("JIEQI_URL");
$salt = "test";
$anleye_domain = crypt(sha1(md5(sha1(base64_encode(getdomain ( $str ))))), $salt);
?>