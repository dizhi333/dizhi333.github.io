<?php

$jieqiGroups["1"] = "游客";
$jieqiGroups["2"] = "系统管理员";
$jieqiGroups["3"] = "普通会员";
$jieqiGroups["4"] = "vip【1月到期】";
$jieqiGroups["5"] = "荣誉会员";
$jieqiGroups["6"] = "专栏作家";
$jieqiGroups["7"] = "驻站作家";
$jieqiGroups["8"] = "初级版主";
$jieqiGroups["9"] = "中级版主";
$jieqiGroups["10"] = "高级版主";

?>
