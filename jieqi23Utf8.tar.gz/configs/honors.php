<?php

$jieqiHonors["1"] = array(
				s => "新手上路",
				s => array("新手上路"),
				s => "-9999999",
				s => "30"
	);
$jieqiHonors["2"] = array(
				s => "普通会员",
				s => array("普通会员"),
				s => "50",
				s => "200"
	);
$jieqiHonors["3"] = array(
				s => "中级会员",
				s => array("中级会员"),
				s => "200",
				s => "500"
	);
$jieqiHonors["4"] = array(
				s => "高级会员",
				s => array("高级会员"),
				s => "500",
				s => "1000"
	);
$jieqiHonors["5"] = array(
				s => "金牌会员",
				s => array("金牌会员"),
				s => "1000",
				s => "2222222"
	);
$jieqiHonors["6"] = array(
				s => "本站元老",
				s => array("本站元老"),
				s => "1233",
				s => "123333"
	);

?>
