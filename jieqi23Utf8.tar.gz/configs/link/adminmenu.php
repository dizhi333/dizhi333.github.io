<?php

$jieqiAdminmenu["link"][] = array("layer" => 0, "caption" => "友情链接管理", "command" => $GLOBALS["jieqiModules"]["link"]["url"] . "/admin/link.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["link"][] = array("layer" => 0, "caption" => "添加链接", "command" => $GLOBALS["jieqiModules"]["link"]["url"] . "/admin/addlink.php", "target" => 0, "publish" => 1);

?>
