<?php

$jieqiLsort[1] = array("caption" => "后台登录", "logtitle" => "登录网站后台", "loglevel" => 1, "targetname" => "登录");
$jieqiLsort[2] = array("caption" => "参数设置", "logtitle" => "修改参数设置", "loglevel" => 3, "targetname" => "参数");
$jieqiLsort[3] = array("caption" => "权限设置", "logtitle" => "修改权限设置", "loglevel" => 3, "targetname" => "权限");
$jieqiLsort[4] = array("caption" => "权利设置", "logtitle" => "修改权利设置", "loglevel" => 3, "targetname" => "权利");
$jieqiLsort[101] = array("caption" => "系统错误", "logtitle" => "系统错误", "loglevel" => 4, "targetname" => "系统");

?>
