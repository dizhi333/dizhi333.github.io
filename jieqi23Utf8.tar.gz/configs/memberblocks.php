<?php

$jieqiBlocks[0] = array("bid" => 0, "blockname" => "成员分类", "module" => "system", "filename" => "block_grouplist", "classname" => "BlockSystemGrouplist", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "成员分类", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);
$jieqiBlocks[1] = array("bid" => 0, "blockname" => "排 行 榜", "module" => "system", "filename" => "block_topuser", "classname" => "BlockSystemTopuser", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "排 行 榜", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);
$jieqiBlocks[2] = array("bid" => 0, "blockname" => "成员搜索", "module" => "system", "filename" => "block_searchuser", "classname" => "BlockSystemSearchuser", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "成员搜索", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);

?>
