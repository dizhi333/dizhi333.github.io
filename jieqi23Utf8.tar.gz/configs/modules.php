<?php
$jieqiModules['system'] = array('caption'=>'系统功能', 'dir'=>'', 'path'=>'', 'url'=>'', 'theme'=>'', 'publish'=>'1');
$jieqiModules['article'] = array('caption'=>'小说连载', 'dir'=>'', 'path'=>'', 'url'=>'/modules/article', 'theme'=>'', 'publish'=>'1');
$jieqiModules['obook'] = array('caption'=>'在线电子书', 'dir'=>'', 'path'=>'', 'url'=>'/modules/obook', 'theme'=>'', 'publish'=>'1');
$jieqiModules['forum'] = array('caption'=>'交流论坛', 'dir'=>'', 'path'=>'', 'url'=>'/modules/forum', 'theme'=>'', 'publish'=>'1');
$jieqiModules['pay'] = array('caption'=>'在线支付', 'dir'=>'', 'path'=>'', 'url'=>'/modules/pay', 'theme'=>'', 'publish'=>'1');
$jieqiModules['link'] = array('caption'=>'友情链接', 'dir'=>'', 'path'=>'', 'url'=>'/modules/link', 'theme'=>'', 'publish'=>'1');
$jieqiModules['news'] = array('caption'=>'新闻发布', 'dir'=>'', 'path'=>'', 'url'=>'/modules/news', 'theme'=>'', 'publish'=>'1');
$jieqiModules['badge'] = array('caption'=>'用户徽章', 'dir'=>'', 'path'=>'', 'url'=>'/modules/badge', 'theme'=>'', 'publish'=>'1');
?>