<?php

$jieqiAdminmenu["news"][0] = array("layer" => 0, "caption" => "参数设置", "command" => JIEQI_URL . "/admin/configs.php?mod=news", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][1] = array("layer" => 0, "caption" => "权限管理", "command" => JIEQI_URL . "/admin/power.php?mod=news", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][2] = array("layer" => 0, "caption" => "栏目管理", "command" => $GLOBALS["jieqiModules"]["news"]["url"] . "/admin/category.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][3] = array("layer" => 0, "caption" => "新闻发布", "command" => $GLOBALS["jieqiModules"]["news"]["url"] . "/admin/newsadd.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][4] = array("layer" => 0, "caption" => "待审新闻", "command" => $GLOBALS["jieqiModules"]["news"]["url"] . "/admin/newslist.php?audit=2", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][5] = array("layer" => 0, "caption" => "已审新闻", "command" => $GLOBALS["jieqiModules"]["news"]["url"] . "/admin/newslist.php?audit=1", "target" => 0, "publish" => 1);
$jieqiAdminmenu["news"][6] = array("layer" => 0, "caption" => "附件管理", "command" => $GLOBALS["jieqiModules"]["news"]["url"] . "/admin/attachment.php", "target" => 0, "publish" => 1);

?>
