<?php

$jieqiConfigs["news"]["newsmanagepnum"] = "10";
$jieqiConfigs["news"]["newsmanageword"] = "40";
$jieqiConfigs["news"]["attachmanagepnum"] = "10";
$jieqiConfigs["news"]["newslistpnum"] = "10";
$jieqiConfigs["news"]["newslistword"] = "40";
$jieqiConfigs["news"]["relatenewsenable"] = "1";
$jieqiConfigs["news"]["relatenewslistpnum"] = "5";
$jieqiConfigs["news"]["relatenewslistword"] = "40";
$jieqiConfigs["news"]["maxkeyword"] = "3";
$jieqiConfigs["news"]["newslistcache"] = "10";
$jieqiConfigs["news"]["minclicktime"] = "3600";
$jieqiConfigs["news"]["htmlextendname"] = ".html";
$jieqiConfigs["news"]["htmlfilesenable"] = "0";
$jieqiConfigs["news"]["htmlfilespath"] = "html";
$jieqiConfigs["news"]["imagedir"] = "image";
$jieqiConfigs["news"]["imagetype"] = "gif jpg jpeg png bmp";
$jieqiConfigs["news"]["maximagesize"] = "200";

?>
