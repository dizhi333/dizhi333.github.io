<?php

$jieqiBlocks[] = array("bid" => 17, "blockname" => "最新新闻列表", "module" => "news", "filename" => "block_newsupdatelist", "classname" => "BlockNewsUpdateList", "side" => 6, "title" => "最新新闻", "vars" => "10,16", "template" => "block_newsupdatelist.html", "contenttype" => 1, "custom" => 0, "publish" => 3, "hasvars" => 1);

?>
