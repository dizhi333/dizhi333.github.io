<?php

$jieqiPower["news"]["adminconfig"]["caption"] = "管理参数设置";
$jieqiPower["news"]["adminconfig"]["groups"] = "";
$jieqiPower["news"]["adminconfig"]["description"] = "";
$jieqiPower["news"]["adminpower"]["caption"] = "管理权限设置";
$jieqiPower["news"]["adminpower"]["groups"] = "";
$jieqiPower["news"]["adminpower"]["description"] = "";
$jieqiPower["news"]["managecategory"]["caption"] = "管理新闻栏目";
$jieqiPower["news"]["managecategory"]["groups"] = "";
$jieqiPower["news"]["managecategory"]["description"] = "";
$jieqiPower["news"]["newslist"]["caption"] = "查看新闻列表";
$jieqiPower["news"]["newslist"]["groups"] = "";
$jieqiPower["news"]["newslist"]["description"] = "";
$jieqiPower["news"]["newsaddback"]["caption"] = "新闻后台发布";
$jieqiPower["news"]["newsaddback"]["groups"] = "";
$jieqiPower["news"]["newsaddback"]["description"] = "";
$jieqiPower["news"]["newsaddfront"]["caption"] = "新闻前台发布";
$jieqiPower["news"]["newsaddfront"]["groups"] = "";
$jieqiPower["news"]["newsaddfront"]["description"] = "";
$jieqiPower["news"]["newsneedaudit"]["caption"] = "新闻需要审核";
$jieqiPower["news"]["newsneedaudit"]["groups"] = "";
$jieqiPower["news"]["newsneedaudit"]["description"] = "";
$jieqiPower["news"]["newsedit"]["caption"] = "新闻编辑";
$jieqiPower["news"]["newsedit"]["groups"] = "";
$jieqiPower["news"]["newsedit"]["description"] = "";
$jieqiPower["news"]["newsdel"]["caption"] = "新闻删除";
$jieqiPower["news"]["newsdel"]["groups"] = "";
$jieqiPower["news"]["newsdel"]["description"] = "";
$jieqiPower["news"]["newsaudit"]["caption"] = "新闻审核";
$jieqiPower["news"]["newsaudit"]["groups"] = "";
$jieqiPower["news"]["newsaudit"]["description"] = "";
$jieqiPower["news"]["newsputop"]["caption"] = "新闻置顶";
$jieqiPower["news"]["newsputop"]["groups"] = "";
$jieqiPower["news"]["newsputop"]["description"] = "";
$jieqiPower["news"]["newshtml"]["caption"] = "管理新闻静态化";
$jieqiPower["news"]["newshtml"]["groups"] = "";
$jieqiPower["news"]["newshtml"]["description"] = "";
$jieqiPower["news"]["manageattach"]["caption"] = "管理附件";
$jieqiPower["news"]["manageattach"]["groups"] = "";
$jieqiPower["news"]["manageattach"]["description"] = "";
$jieqiPower["news"]["attachadd"]["caption"] = "上传附件";
$jieqiPower["news"]["attachadd"]["groups"] = "";
$jieqiPower["news"]["attachadd"]["description"] = "";

?>
