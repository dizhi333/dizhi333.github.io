<?php

$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "参数设置", "command" => JIEQI_URL . "/admin/configs.php?mod=obook", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "权限设置", "command" => JIEQI_URL . "/admin/power.php?mod=obook", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "全部电子书", "command" => $GLOBALS["jieqiModules"]["obook"]["url"] . "/admin/obooklist.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "销售统计", "command" => $GLOBALS["jieqiModules"]["obook"]["url"] . "/admin/salestat.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "订阅记录", "command" => $GLOBALS["jieqiModules"]["obook"]["url"] . "/admin/buylog.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "打赏记录", "command" => $GLOBALS["jieqiModules"]["article"]["url"] . "/admin/actlog.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "催更记录", "command" => $GLOBALS["jieqiModules"]["article"]["url"] . "/admin/articlehurry.php", "target" => 1, "publish" => 1);
$jieqiAdminmenu["obook"][] = array("layer" => 0, "caption" => "销售月报", "command" => $GLOBALS["jieqiModules"]["obook"]["url"] . "/admin/mreport.php", "target" => 0, "publish" => 1);

?>
