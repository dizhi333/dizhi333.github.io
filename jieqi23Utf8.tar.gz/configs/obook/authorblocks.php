<?php

$jieqiBlocks[] = array("bid" => 0, "blockname" => "作家工具箱", "module" => "article", "filename" => "block_writerbox", "classname" => "BlockArticleWriterbox", "side" => 0, "title" => "作家工具箱", "vars" => "", "template" => "", "contenttype" => 0, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[] = array("bid" => 0, "blockname" => "我的小说", "module" => "article", "filename" => "block_uarticles", "classname" => "BlockArticleUarticles", "side" => 0, "title" => "我的小说", "vars" => "postdate,10,0,self,0", "template" => "block_myarticles.html", "contenttype" => 4, "custom" => 0, "publish" => 3, "hasvars" => 1);

?>
