<?php

$jieqiConfigs["obook"] = array("staticurl" => "", "dynamicurl" => "", "topcachenum" => 10, "obkstartx" => 20, "obkstarty" => 50, "obklinewidth" => 80, "obkfontsize" => 14, "obkfontjt" => "C:/Windows/Fonts/simsun.ttc", "obkfontft" => "C:/Windows/Fonts/simsun.ttc", "obkcharconvert" => "1", "obkimagetype" => "png", "jpegquality" => 90, "obkimagecolor" => "#ffffff", "obktextcolor" => "#000000", "obkangle" => 0, "obkshadowcolor" => "#000000", "obkshadowdeep" => 0, "obkwatertext" => "0", "obkwaterformat" => "", "obkwatercolor" => "#ff6600", "obkwatersize" => 16, "obkwaterangle" => 45, "obkwaterpct" => 30, "obookwater" => "0", "obookwimage" => "watermark.gif", "obookwtrans" => 30, "obookreadhead" => "", "obookreadfoot" => "", "wordsperegold" => 333, "priceround" => "0");

?>
