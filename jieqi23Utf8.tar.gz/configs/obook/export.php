<?php

$jieqiExport["obook"]["time"] = array("caption" => "统计月份", "width" => 10, "display" => 1);
$jieqiExport["obook"]["obookid"] = array("caption" => "作品ID", "width" => 10, "display" => 1);
$jieqiExport["obook"]["obookname"] = array("caption" => "作品名称", "width" => 30, "display" => 1);
$jieqiExport["obook"]["author"] = array("caption" => "作者名", "width" => 20, "display" => 1);
$jieqiExport["obook"]["poster"] = array("caption" => "发表者", "width" => 20, "display" => 1);
$jieqiExport["obook"]["allsale"] = array("caption" => "总订阅", "width" => 10, "display" => 1);
$jieqiExport["obook"]["divided"] = array("caption" => "分成百分比", "width" => 15, "display" => 1);
$jieqiExport["obook"]["wwwsale"] = array("caption" => "网站订阅分成", "width" => 15, "display" => 1);
$jieqiExport["obook"]["intosale"] = array("caption" => "作者订阅分成", "width" => 15, "display" => 1);
$jieqiExport["obook"]["sumtip"] = array("caption" => "总打赏", "width" => 10, "display" => 1);
$jieqiExport["obook"]["sumgift"] = array("caption" => "总礼物", "width" => 10, "display" => 1);
$jieqiExport["obook"]["sumhurry"] = array("caption" => "总崔更", "width" => 10, "display" => 1);
$jieqiExport["obook"]["sumemoney"] = array("caption" => "作者总收入", "width" => 15, "display" => 1);
$jieqiExport["obook"]["banktype"] = array("caption" => "收款银行", "width" => 15, "display" => 1);
$jieqiExport["obook"]["bankcard"] = array("caption" => "收款账号", "width" => 20, "display" => 1);
$jieqiExport["obook"]["bankuser"] = array("caption" => "收款人", "width" => 15, "display" => 1);

?>
