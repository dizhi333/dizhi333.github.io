<?php

$jieqiBlocks[] = array("bid" => 0, "blockname" => "分类阅读", "module" => "article", "filename" => "block_sort", "classname" => "BlockArticleSort", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "分类阅读", "vars" => "", "template" => "", "contenttype" => JIEQI_CONTENT_TXT, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[] = array("bid" => 0, "blockname" => "排 行 榜", "module" => "article", "filename" => "block_toplist", "classname" => "BlockArticleToplist", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "排 行 榜", "vars" => "", "template" => "", "contenttype" => JIEQI_CONTENT_TXT, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[] = array("bid" => 0, "blockname" => "小说搜索", "module" => "article", "filename" => "block_search", "classname" => "BlockArticleSearch", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "小说搜索", "vars" => "", "template" => "", "contenttype" => JIEQI_CONTENT_TXT, "custom" => 0, "publish" => 3, "hasvars" => 0);

?>
