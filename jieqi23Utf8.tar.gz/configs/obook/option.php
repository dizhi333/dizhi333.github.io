<?php

$jieqiOption["obook"]["display"] = array(
				s => 0,
				s => 0,
				s => array("销售中", "待审核", "已下架")
	);
$jieqiOption["obook"]["paidcurrency"] = array(
				s => 0,
				s => 0,
				s => array("人民币", "美元")
	);
$jieqiOption["obook"]["paidtype"] = array(
				s => 0,
				s => 0,
				s => array("稿酬", "奖励")
	);

?>
