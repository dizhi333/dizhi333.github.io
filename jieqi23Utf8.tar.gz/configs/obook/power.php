<?php

$jieqiPower["obook"] = array(
				s => array(
					s => "发布电子书",
					s => array("9", "10"),
					s => "只能以自己名义发布电子书"
		),
				s => array(
					s => "转载电子书",
					s => array("9", "10"),
					s => "可以以他人名义名义发布"
		),
				s => array(
					s => "管理电子书",
					s => array("9", "10"),
					s => "管理所有电子书"
		),
				s => array(
					s => "发布电子书不需要审查",
					s => array("9", "10"),
					s => ""
		),
				s => array(
					s => "查看购买记录",
					s => array("9", "10"),
					s => ""
		),
				s => array(
					s => "允许自定电子书价格",
					s => array("9", "10"),
					s => ""
		),
				s => array(
					s => "免费阅读电子书",
					s => array("9", "10"),
					s => ""
		)
	);

?>
