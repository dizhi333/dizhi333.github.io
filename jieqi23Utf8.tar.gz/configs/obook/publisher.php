<?php

$jieqiPublisher[0] = array("name" => "本站出版", "password" => "");
$jieqiPublisher[1] = array("name" => "他站出版", "password" => "");

?>
