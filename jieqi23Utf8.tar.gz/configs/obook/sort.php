<?php

$jieqiSort["obook"][1] = array("code" => "xuanhuan", "caption" => "玄幻魔法");
$jieqiSort["obook"][2] = array("code" => "wuxia", "caption" => "武侠修真");
$jieqiSort["obook"][3] = array("code" => "dushi", "caption" => "都市言情");
$jieqiSort["obook"][4] = array("code" => "lishi", "caption" => "历史军事");
$jieqiSort["obook"][5] = array("code" => "chuanyue", "caption" => "穿越架空");
$jieqiSort["obook"][6] = array("code" => "youxi", "caption" => "游戏竞技");
$jieqiSort["obook"][7] = array("code" => "kehuan", "caption" => "科幻灵异");
$jieqiSort["obook"][8] = array("code" => "tongren", "caption" => "同人动漫");
$jieqiSort["obook"][9] = array("code" => "wenxue", "caption" => "社会文学");
$jieqiSort["obook"][10] = array("code" => "zonghe", "caption" => "综合其他");

?>
