<?php

$jieqiOption["system"]["display"] = array(
				s => 0,
				s => 0,
				s => array("显示", "待审", "隐藏")
	);
$jieqiOption["system"]["gender"] = array(
				s => 0,
				s => 0,
				s => array("未知", "男", "女")
	);
$jieqiOption["system"]["sex"] = array(
				s => 0,
				s => 0,
				s => array("未知", "男", "女")
	);

?>
