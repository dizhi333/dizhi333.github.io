<?php

$jieqiPayset["99bill"]["payid"] = "";
$jieqiPayset["99bill"]["paykey"] = "";
$jieqiPayset["99bill"]["payurl"] = "https://www.99bill.com/gateway/recvMerchantInfoAction.htm";
$jieqiPayset["99bill"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/99billreturn.php";
$jieqiPayset["99bill"]["payrate"] = 100;
$jieqiPayset["99bill"]["paycustom"] = 0;
$jieqiPayset["99bill"]["paylimit"] = array("1000" => "10", "2000" => "20", "5000" => "50", "10000" => "100", "20000" => "200", "50000" => "500");
$jieqiPayset["99bill"]["moneytype"] = "0";
$jieqiPayset["99bill"]["paysilver"] = "0";
$jieqiPayset["99bill"]["inputCharset"] = "2";
$jieqiPayset["99bill"]["version"] = "v2.0";
$jieqiPayset["99bill"]["language"] = "1";
$jieqiPayset["99bill"]["signType"] = "1";
$jieqiPayset["99bill"]["payType"] = "00";
$jieqiPayset["99bill"]["fullAmountFlag"] = "0";
$jieqiPayset["99bill"]["ext1"] = "";
$jieqiPayset["99bill"]["ext2"] = "";
$jieqiPayset["99bill"]["addvars"] = array();

?>
