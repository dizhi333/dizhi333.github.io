<?php

$jieqiPayset["99card"]["payid"] = "123456";
$jieqiPayset["99card"]["paykey"] = "000000";
$jieqiPayset["99card"]["payurl"] = "https://www.99bill.com/szxgateway/recvMerchantInfoAction.htm";
$jieqiPayset["99card"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/99cardreturn.php";
$jieqiPayset["99card"]["payrate"] = 100;
$jieqiPayset["99card"]["paycustom"] = 0;
$jieqiPayset["99card"]["paylimit"] = array("1000" => "10", "1500" => "15", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100", "30000" => "300", "50000" => "500");
$jieqiPayset["99card"]["moneytype"] = "0";
$jieqiPayset["99card"]["paysilver"] = "0";
$jieqiPayset["99card"]["inputCharset"] = "2";
$jieqiPayset["99card"]["version"] = "v2.0";
$jieqiPayset["99card"]["language"] = "1";
$jieqiPayset["99card"]["signType"] = "1";
$jieqiPayset["99card"]["payType"] = "42";
$jieqiPayset["99card"]["fullAmountFlag"] = "0";
$jieqiPayset["99card"]["ext1"] = "";
$jieqiPayset["99card"]["ext2"] = "";
$jieqiPayset["99card"]["bossType"] = "9";
$jieqiPayset["99card"]["addvars"] = array();

?>
