<?php

$jieqiAdminmenu["pay"][] = array("layer" => 0, "caption" => "全部充值记录", "command" => $GLOBALS["jieqiModules"]["pay"]["url"] . "/admin/paylog.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["pay"][] = array("layer" => 0, "caption" => "已成功充值", "command" => $GLOBALS["jieqiModules"]["pay"]["url"] . "/admin/paylog.php?payflag=success", "target" => 0, "publish" => 1);
$jieqiAdminmenu["pay"][] = array("layer" => 0, "caption" => "未成功充值", "command" => $GLOBALS["jieqiModules"]["pay"]["url"] . "/admin/paylog.php?payflag=failure", "target" => 0, "publish" => 1);
$jieqiAdminmenu["pay"][] = array("layer" => 0, "caption" => "充值卡生成", "command" => $GLOBALS["jieqiModules"]["pay"]["url"] . "/admin/makepaycard.php", "target" => 0, "publish" => 1);
$jieqiAdminmenu["pay"][] = array("layer" => 0, "caption" => "充值卡查询", "command" => $GLOBALS["jieqiModules"]["pay"]["url"] . "/admin/showpaycard.php", "target" => 0, "publish" => 1);

?>
