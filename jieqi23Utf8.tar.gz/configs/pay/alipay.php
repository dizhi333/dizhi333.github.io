<?php

$jieqiPayset["alipay"]["payid"] = "2088621544110673";
$jieqiPayset["alipay"]["paykey"] = "lhicei37t2hr35814qdt9hnt8o10hsm4";
$jieqiPayset["alipay"]["payurl"] = "https://mapi.alipay.com/gateway.do";
$jieqiPayset["alipay"]["payreturn"] = "http://goread.net/modules/pay/alipayreturn.php";
$jieqiPayset["alipay"]["payrate"] = 100;
$jieqiPayset["alipay"]["paycustom"] = 0;
$jieqiPayset["alipay"]["paylimit"] = array("1000" => "10", "2000" => "20", "5000" => "50", "10000" => "100", "20000" => "200", "50000" => "500");
$jieqiPayset["alipay"]["moneytype"] = "0";
$jieqiPayset["alipay"]["paysilver"] = "0";
$jieqiPayset["alipay"]["service"] = "create_direct_pay_by_user";
$jieqiPayset["alipay"]["agent"] = "";
$jieqiPayset["alipay"]["_input_charset"] = "GBK";
$jieqiPayset["alipay"]["subject"] = JIEQI_EGOLD_NAME;
$jieqiPayset["alipay"]["payment_type"] = "1";
$jieqiPayset["alipay"]["show_url"] = JIEQI_LOCAL_URL;
$jieqiPayset["alipay"]["seller_email"] = " hongyanrock@qq.com";
$jieqiPayset["alipay"]["sign_type"] = "MD5";
$jieqiPayset["alipay"]["notify_url"] = "http://www.goread.net/modules/pay/alipayreturn.php";
$jieqiPayset["alipay"]["notifycheck"] = "http://notify.alipay.com/trade/notify_query.do";
$jieqiPayset["alipay"]["addvars"] = array();
echo "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";

?>
