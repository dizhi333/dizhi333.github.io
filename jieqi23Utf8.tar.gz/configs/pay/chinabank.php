<?php

$jieqiPayset["chinabank"]["payid"] = "12345678";
$jieqiPayset["chinabank"]["paykey"] = "xxxxxxxx";
$jieqiPayset["chinabank"]["foreignpayid"] = "12345678";
$jieqiPayset["chinabank"]["foreignpaykey"] = "xxxxxxxx";
$jieqiPayset["chinabank"]["payurl"] = "https://pay3.chinabank.com.cn/PayGate";
$jieqiPayset["chinabank"]["payreturn"] = "http://www.domain.com/modules/pay/chinabankreturn.php";
$jieqiPayset["chinabank"]["paycheck"] = "http://www.domain.com/modules/pay/chinabankcheck.php";
$jieqiPayset["chinabank"]["paylimit"] = array("1000" => "10", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["chinabank"]["moneytype"] = "0";
$jieqiPayset["chinabank"]["paysilver"] = "0";
$jieqiPayset["chinabank"]["style"] = "0";
$jieqiPayset["chinabank"]["remark1"] = "0";
$jieqiPayset["chinabank"]["remark2"] = "0";
$jieqiPayset["chinabank"]["addvars"] = array();

?>
