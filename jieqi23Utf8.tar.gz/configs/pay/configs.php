<?php

$jieqiConfigs["pay"]["paylogpnum"] = "50";
$jieqiConfigs["pay"]["egoldtransrate"] = "100";
$jieqiConfigs["pay"]["creditransrate"] = "10";
$jieqiConfigs["pay"]["scoretransrate"] = "0";
$jieqiConfigs["pay"]["payclub"] = "3000";

?>
