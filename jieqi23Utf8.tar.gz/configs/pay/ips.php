<?php

$jieqiPayset["ips"]["payid"] = "123456";
$jieqiPayset["ips"]["paykey"] = "123456";
$jieqiPayset["ips"]["payurl"] = "http://pay.ips.com.cn/ipayment.aspx";
$jieqiPayset["ips"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/ipsreturn.php";
$jieqiPayset["ips"]["payrate"] = 100;
$jieqiPayset["ips"]["paycustom"] = 0;
$jieqiPayset["ips"]["paylimit"] = array("1000" => "10", "2000" => "20", "5000" => "50", "10000" => "100", "20000" => "200", "50000" => "500");
$jieqiPayset["ips"]["moneytype"] = "0";
$jieqiPayset["ips"]["paysilver"] = "0";
$jieqiPayset["ips"]["Currency_Type"] = "RMB";
$jieqiPayset["ips"]["Gateway_Type"] = "01";
$jieqiPayset["ips"]["Lang"] = "GB";
$jieqiPayset["ips"]["FailUrl"] = "";
$jieqiPayset["ips"]["RetEncodeType"] = "17";
$jieqiPayset["ips"]["OrderEncodeType"] = "5";
$jieqiPayset["ips"]["Rettype"] = "0";
$jieqiPayset["ips"]["Attach"] = "";
$jieqiPayset["ips"]["addvars"] = array();

?>
