<?php

$jieqiOption["pay"]["payflag"] = array(
				s => 0,
				s => 0,
				s => array("未确认", "支付成功", "手工确认")
	);

?>
