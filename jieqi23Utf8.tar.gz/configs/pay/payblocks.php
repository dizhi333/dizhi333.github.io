<?php

$jieqiBlocks[] = array("bid" => 0, "blockname" => "充值方式", "module" => "pay", "filename" => "block_paylist", "classname" => "BlockSystemCustom", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "充值方式", "vars" => "", "template" => "", "contenttype" => 4, "custom" => 1, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[] = array("bid" => 0, "blockname" => "用户设置", "module" => "system", "filename" => "block_userset", "classname" => "BlockSystemUserset", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "用户设置", "vars" => "", "template" => "", "contenttype" => JIEQI_CONTENT_TXT, "custom" => 0, "publish" => 3, "hasvars" => 0);
$jieqiBlocks[] = array("bid" => 0, "blockname" => "工具箱", "module" => "system", "filename" => "block_userbox", "classname" => "BlockSystemUserbox", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "工具箱", "vars" => "", "template" => "", "contenttype" => JIEQI_CONTENT_TXT, "custom" => 0, "publish" => 3, "hasvars" => 0);

?>
