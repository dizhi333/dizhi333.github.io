<?php

$jieqiPayset["paycard"]["payid"] = "";
$jieqiPayset["paycard"]["paykey"] = "";
$jieqiPayset["paycard"]["payurl"] = "";
$jieqiPayset["paycard"]["payreturn"] = "";
$jieqiPayset["paycard"]["paylimit"] = array("70" => "1", "150" => "2");
$jieqiPayset["paycard"]["moneytype"] = "0";
$jieqiPayset["paycard"]["paysilver"] = "0";
$jieqiPayset["paycard"]["addvars"] = array();

?>
