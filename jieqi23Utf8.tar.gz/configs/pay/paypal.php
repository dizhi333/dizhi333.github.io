<?php

$jieqiPayset["paypal"]["payid"] = "123456";
$jieqiPayset["paypal"]["paykey"] = "000000";
$jieqiPayset["paypal"]["payurl"] = "https://www.paypal.com/cgi-bin/webscr";
$jieqiPayset["paypal"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/paypalreturn.php";
$jieqiPayset["paypal"]["paynotify"] = JIEQI_LOCAL_URL . "/modules/pay/paypalnotify.php";
$jieqiPayset["paypal"]["payrate"] = 600;
$jieqiPayset["paypal"]["paycustom"] = 0;
$jieqiPayset["paypal"]["paylimit"] = array("6000" => "10", "12000" => "20", "30000" => "50", "60000" => "100");
$jieqiPayset["paypal"]["moneytype"] = "1";
$jieqiPayset["paypal"]["paysilver"] = "0";
$jieqiPayset["paypal"]["cmd"] = "_xclick";
$jieqiPayset["yeepay"]["item_name"] = JIEQI_EGOLD_NAME;
$jieqiPayset["paypal"]["currency_code"] = "USD";
$jieqiPayset["paypal"]["rm"] = "1";
$jieqiPayset["paypal"]["cancel_return"] = JIEQI_LOCAL_URL . "/modules/pay/paypal.php";
$jieqiPayset["paypal"]["no_shipping"] = "1";
$jieqiPayset["paypal"]["no_note"] = "1";
$jieqiPayset["paypal"]["image_url"] = "";
$jieqiPayset["paypal"]["addvars"] = array();

?>
