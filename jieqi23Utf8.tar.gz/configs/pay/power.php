<?php

$jieqiPower["pay"]["adminpaylog"]["caption"] = "管理在线支付";
$jieqiPower["pay"]["adminpaylog"]["groups"]["0"] = "2";
$jieqiPower["pay"]["adminpaylog"]["description"] = "";
$jieqiPower["pay"]["adminmessage"]["caption"] = "管理短消息";
$jieqiPower["pay"]["adminmessage"]["groups"]["0"] = "2";
$jieqiPower["pay"]["adminmessage"]["description"] = "";
$jieqiPower["pay"]["adminuserlog"]["caption"] = "管理用户日志";
$jieqiPower["pay"]["adminuserlog"]["groups"]["0"] = "2";
$jieqiPower["pay"]["adminuserlog"]["description"] = "";

?>
