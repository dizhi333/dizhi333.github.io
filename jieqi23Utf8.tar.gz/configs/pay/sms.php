<?php

$jieqiPayset["sms"]["payid"] = "12345678";
$jieqiPayset["sms"]["paykey"] = "xxxxxxxx";
$jieqiPayset["sms"]["payurl"] = "http://218.206.80.238/qyhzapi/sendsms.jsp";
$jieqiPayset["sms"]["payreturn"] = "http://www.domain.com/modules/pay/smsreturn.php";
$jieqiPayset["sms"]["paylimit"] = array("1000" => "10", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["sms"]["moneytype"] = "0";
$jieqiPayset["sms"]["paysilver"] = "0";
$jieqiPayset["sms"]["mydest"] = "0";
$jieqiPayset["sms"]["emoney"] = "100";
$jieqiPayset["sms"]["egold"] = "100";
$jieqiPayset["sms"]["ptype"] = "1";
$jieqiPayset["sms"]["sid"] = "1315";
$jieqiPayset["sms"]["mtype"] = "1";
$jieqiPayset["sms"]["fmt"] = "1";
$jieqiPayset["sms"]["uflag"] = "0";
$jieqiPayset["sms"]["startmsg"] = "NA";
$jieqiPayset["sms"]["daymsg"] = "10";
$jieqiPayset["sms"]["message"] = "ID：<{\$userid}>，用户名：<{\$username}>，<{\$egold}> 点虚拟币已经入帐，请登陆并查收！(资费1元/条，交易序号：<{\$serialno}>)";
$jieqiPayset["sms"]["addvars"] = array();

?>
