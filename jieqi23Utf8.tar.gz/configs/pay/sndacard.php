<?php

$jieqiPayset["sndacard"]["payid"] = "123456";
$jieqiPayset["sndacard"]["paykey"] = "******";
$jieqiPayset["sndacard"]["payurl"] = "http://61.172.247.108/PayNet/CardPay.aspx";
$jieqiPayset["sndacard"]["payreturn"] = "http://www.domain.com/modules/pay/sndacardreturn.php";
$jieqiPayset["sndacard"]["paylimit"] = array("1000" => "10", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["sndacard"]["moneytype"] = "0";
$jieqiPayset["sndacard"]["paysilver"] = "0";
$jieqiPayset["sndacard"]["bizcode"] = "03";
$jieqiPayset["sndacard"]["callbacktype"] = "01";
$jieqiPayset["sndacard"]["ex1"] = "";
$jieqiPayset["sndacard"]["ex2"] = "";
$jieqiPayset["sndacard"]["signurl"] = "http://localhost:8080/shandasign.jsp";
$jieqiPayset["sndacard"]["verifyurl"] = "http://localhost:8080/shandaverify.jsp";
$jieqiPayset["sndacard"]["checkstr"] = "cwjsignwithshanda";
$jieqiPayset["sndacard"]["showurl"] = "http://www.domain.com/modules/pay/sndacardshow.php";
$jieqiPayset["sndacard"]["addvars"] = array();

?>
