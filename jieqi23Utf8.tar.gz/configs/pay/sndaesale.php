<?php

$jieqiPayset["sndaesale"]["payid"] = "123456";
$jieqiPayset["sndaesale"]["paykey"] = "******";
$jieqiPayset["sndaesale"]["payurl"] = "http://61.172.247.108/PayNet/EsalesPay.aspx";
$jieqiPayset["sndaesale"]["payreturn"] = "http://www.domain.com/modules/pay/sndaesalereturn.php";
$jieqiPayset["sndaesale"]["paylimit"] = array("1000" => "10", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["sndaesale"]["moneytype"] = "0";
$jieqiPayset["sndaesale"]["paysilver"] = "0";
$jieqiPayset["sndaesale"]["bizcode"] = "01";
$jieqiPayset["sndaesale"]["callbacktype"] = "01";
$jieqiPayset["sndaesale"]["ex1"] = "";
$jieqiPayset["sndaesale"]["ex2"] = "";
$jieqiPayset["sndaesale"]["signurl"] = "http://localhost:8080/shandasign.jsp";
$jieqiPayset["sndaesale"]["verifyurl"] = "http://localhost:8080/shandaverify.jsp";
$jieqiPayset["sndaesale"]["checkstr"] = "cwjsignwithshanda";
$jieqiPayset["sndacard"]["showurl"] = "http://www.domain.com/modules/pay/sndaesaleshow.php";
$jieqiPayset["sndaesale"]["addvars"] = array();

?>
