<?php

$jieqiPayset["sndagame"]["payid"] = "123456";
$jieqiPayset["sndagame"]["paykey"] = "******";
$jieqiPayset["sndagame"]["payurl"] = "http://pay.15173.com/Pay_gate.aspx";
$jieqiPayset["sndagame"]["payreturn"] = "http://www6.2100book.com/modules/pay/15173return.php";
$jieqiPayset["sndagame"]["paynotify"] = "http://www6.2100book.com/modules/pay/15173notify.php";
$jieqiPayset["sndagame"]["paylimit"] = array("380" => "5", "780" => "10", "2420" => "30", "3660" => "45", "4070" => "50", "8150" => "100", "81800" => "1000");
$jieqiPayset["sndagame"]["payscore"] = array("380" => "50", "780" => "100", "2420" => "300", "3660" => "450", "4070" => "500", "8150" => "1000", "81800" => "10000");
$jieqiPayset["sndagame"]["moneytype"] = "0";
$jieqiPayset["sndagame"]["paytype"] = "c";
$jieqiPayset["sndagame"]["paysilver"] = "0";
$jieqiPayset["sndagame"]["currency"] = "1";
$jieqiPayset["sndagame"]["pemail"] = "";
$jieqiPayset["sndagame"]["merchant_param"] = "";
$jieqiPayset["sndagame"]["isSupportDES"] = "2";
$jieqiPayset["sndagame"]["pid_sndagameaccount"] = "";
$jieqiPayset["sndagame"]["addvars"] = array();

?>
