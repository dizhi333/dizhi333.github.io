<?php

$jieqiPayset["tenpay"]["payid"] = "123456";
$jieqiPayset["tenpay"]["paykey"] = "******";
$jieqiPayset["tenpay"]["payurl"] = "https://www.tenpay.com/cgi-bin/v1.0/pay_gate.cgi";
$jieqiPayset["tenpay"]["payreturn"] = "http://www.domain.com/modules/pay/tenpayreturn.php";
$jieqiPayset["tenpay"]["paylimit"] = array("1000" => "10", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["tenpay"]["moneytype"] = "0";
$jieqiPayset["tenpay"]["paysilver"] = "0";
$jieqiPayset["tenpay"]["payresult"] = "http://www.domain.com/modules/pay/tenpayresult.php?payid=%s&egold=%s&buyid=%s&buyname=%s";
$jieqiPayset["tenpay"]["cmdno"] = "1";
$jieqiPayset["tenpay"]["bank_type"] = "0";
$jieqiPayset["tenpay"]["fee_type"] = "1";
$jieqiPayset["tenpay"]["attach"] = "";
$jieqiPayset["tenpay"]["addvars"] = array();

?>
