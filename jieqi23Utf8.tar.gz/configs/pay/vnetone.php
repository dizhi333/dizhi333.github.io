<?php

$jieqiPayset["vnetone"]["payid"] = "123456";
$jieqiPayset["vnetone"]["paykey"] = "******";
$jieqiPayset["vnetone"]["payurl"] = "http://s2.vnetone.com/Default.aspx";
$jieqiPayset["vnetone"]["payreturn"] = "http://www.yingxj.com/jie/jieqicms/modules/pay/vnetonereturn.php";
$jieqiPayset["vnetone"]["paylimit"] = array("200" => "2", "500" => "5", "1000" => "10", "1500" => "15", "2000" => "20", "3000" => "30", "5000" => "50", "10000" => "100");
$jieqiPayset["vnetone"]["moneytype"] = "0";
$jieqiPayset["vnetone"]["paysilver"] = "0";
$jieqiPayset["vnetone"]["errreturn"] = "http://www.yingxj.com/jie/jieqicms/modules/pay/vnetonereturn.php";
$jieqiPayset["vnetone"]["version"] = "vpay1001";
$jieqiPayset["vnetone"]["agentself"] = "";
$jieqiPayset["vnetone"]["addvars"] = array();

?>
