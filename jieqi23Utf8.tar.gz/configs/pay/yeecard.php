<?php

$jieqiPayset["yeecard"]["payid"] = "123456";
$jieqiPayset["yeecard"]["paykey"] = "000000";
$jieqiPayset["yeecard"]["payurl"] = "https://www.yeepay.com/app-merchant-proxy/command.action";
$jieqiPayset["yeecard"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/yeecardreturn.php";

if (in_array($_REQUEST["cardtype"], array("SZX", "UNICOM", "TELECOM"))) {
	$jieqiPayset["yeecard"]["payrate"] = 85;
}
else {
	$jieqiPayset["yeecard"]["payrate"] = 75;
}

$jieqiPayset["yeecard"]["paycustom"] = 1;
$jieqiPayset["yeecard"]["paylimit"] = array();
$jieqiPayset["yeecard"]["moneytype"] = "0";
$jieqiPayset["yeecard"]["paysilver"] = "0";
$jieqiPayset["yeecard"]["messageType"] = "ChargeCardDirect";
$jieqiPayset["yeecard"]["verifyAmt"] = "true";
$jieqiPayset["yeecard"]["productId"] = JIEQI_EGOLD_NAME;
$jieqiPayset["yeecard"]["productDesc"] = JIEQI_EGOLD_NAME;
$jieqiPayset["yeecard"]["productCat"] = "";
$jieqiPayset["yeecard"]["sMctProperties"] = "";
$jieqiPayset["yeecard"]["frpId"] = "";
$jieqiPayset["yeecard"]["needResponse"] = "1";
$jieqiPayset["yeecard"]["pz_userId"] = "";
$jieqiPayset["yeecard"]["pz1_userRegTime"] = "";
$jieqiPayset["yeecard"]["addvars"] = array();

?>
