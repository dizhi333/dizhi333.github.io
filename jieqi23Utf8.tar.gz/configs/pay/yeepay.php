<?php

$jieqiPayset["yeepay"]["payid"] = "";
$jieqiPayset["yeepay"]["paykey"] = "";
$jieqiPayset["yeepay"]["payurl"] = "https://www.yeepay.com/app-merchant-proxy/node";
$jieqiPayset["yeepay"]["payreturn"] = JIEQI_LOCAL_URL . "/modules/pay/yeepayreturn.php";
$jieqiPayset["yeepay"]["payrate"] = 100;
$jieqiPayset["yeepay"]["paycustom"] = 0;
$jieqiPayset["yeepay"]["paylimit"] = array("1000" => "10", "2000" => "20", "5000" => "50", "10000" => "100", "20000" => "200", "50000" => "500");
$jieqiPayset["yeepay"]["moneytype"] = "0";
$jieqiPayset["yeepay"]["paysilver"] = "0";
$jieqiPayset["yeepay"]["addressFlag"] = "0";
$jieqiPayset["yeepay"]["messageType"] = "Buy";
$jieqiPayset["yeepay"]["cur"] = "CNY";
$jieqiPayset["yeepay"]["productId"] = JIEQI_EGOLD_NAME;
$jieqiPayset["yeepay"]["productDesc"] = JIEQI_EGOLD_NAME;
$jieqiPayset["yeepay"]["productCat"] = "";
$jieqiPayset["yeepay"]["sMctProperties"] = "";
$jieqiPayset["yeepay"]["frpId"] = "";
$jieqiPayset["yeepay"]["needResponse"] = "0";
$jieqiPayset["yeepay"]["addvars"] = array();

?>
