<?php

$jieqiPayset["zhifuka"]["payid"] = "123456";
$jieqiPayset["zhifuka"]["paykey"] = "******";
$jieqiPayset["zhifuka"]["payurl"] = "http://202.75.218.94/gateway/zfgateway.asp";
$jieqiPayset["zhifuka"]["payreturn"] = "http://www.domain.com/modules/pay/zhifukareturn.php";
$jieqiPayset["zhifuka"]["cardegold"] = array(
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100),
				s => array(1 => 100)
	);
$jieqiPayset["zhifuka"]["moneytype"] = "0";
$jieqiPayset["zhifuka"]["paysilver"] = "0";
$jieqiPayset["zhifuka"]["addvars"] = array();

?>
