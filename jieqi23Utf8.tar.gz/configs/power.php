<?php

$jieqiPower["system"] = array(
				s => array(
					s => "进入管理面板",
					s => array("8", "9", "10"),
					s => ""
		),
				s => array("caption" => "管理参数设置", "groups" => false, "description" => ""),
				s => array("caption" => "管理权限设置", "groups" => false, "description" => ""),
				s => array("caption" => "管理用户组", "groups" => false, "description" => ""),
				s => array(
					s => "管理用户",
					s => array("10"),
					s => ""
		),
				s => array(
					s => "删除用户",
					s => array("10"),
					s => ""
		),
				s => array(
					s => "管理区块",
					s => array("10"),
					s => ""
		),
				s => array("caption" => "管理在线支付", "groups" => false, "description" => ""),
				s => array(
					s => "管理短消息",
					s => array("9", "10"),
					s => ""
		),
				s => array(
					s => "管理用户日志",
					s => array("8", "9", "10"),
					s => ""
		),
				s => array(
					s => "查看用户列表",
					s => array("3", "4", "5", "6", "7", "8", "9", "10"),
					s => ""
		),
				s => array(
					s => "查看在线用户",
					s => array("8", "9", "10"),
					s => ""
		),
				s => array(
					s => "管理用户等级",
					s => array("10"),
					s => "指修改用户组权限（注意：只有系统管理员才能设置系统管理员）"
		),
				s => array("caption" => "管理用户VIP信息", "groups" => false, "description" => "修改VIP状态，虚拟货币等"),
				s => array(
					s => "向其他会员发送短信",
					s => array("3", "4", "5", "6", "7", "8", "9", "10"),
					s => ""
		),
				s => array(
					s => "拥有个人会客室",
					s => array("1", "3", "4", "5", "6", "7", "8", "9", "10"),
					s => ""
		),
				s => array(
					s => "允许在会客室发帖",
					s => array("3", "4", "5", "6", "7", "8", "9", "10"),
					s => ""
		),
				s => array(
					s => "管理所有会客室",
					s => array("9", "10"),
					s => ""
		),
				s => array(
					s => "管理用户报告",
					s => array("8", "9", "10"),
					s => ""
		)
	);

?>
