<?php

$jieqiRsort[1] = array(
				s => "网站建议",
				s => array(1 => "网站功能", 2 => "页面美工", 3 => "操作流程")
	);
$jieqiRsort[2] = array(
				s => "错误回报",
				s => array(1 => "链接错误", 2 => "内容错误", 3 => "图像错误")
	);
$jieqiRsort[3] = array(
				s => "会员投诉",
				s => array(1 => "投诉本站服务", 2 => "投诉其他会员")
	);
$jieqiRsort[4] = array(
				s => "功能申请",
				s => array(1 => "申请版主", 2 => "删除账号")
	);

?>
