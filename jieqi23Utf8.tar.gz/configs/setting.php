<?php

$jieqiSetting = array();
$jieqiSetting["siteid"] = "1";
$jieqiSetting["siteip"] = "127.0.0.3";
$jieqiSetting["getkey"] = "N3Ur6C6pZlNMxTeS3T2dbBWMWx996xcV";
$jieqiSetting["articlelist"] = "http://www.iwodu.com/apis/demo/articlelist.php";
$jieqiSetting["articleinfo"] = "http://www.iwodu.com/apis/demo/articleinfo.php";
$jieqiSetting["articlechapter"] = "http://www.iwodu.com/apis/demo/articlechapter.php";
$jieqiSetting["chaptercontent"] = "http://www.iwodu.com/apis/demo/chaptercontent.php";
$jieqiSetting["articlecount"] = "http://www.iwodu.com/apis/demo/articlecount.php";
$jieqiSetting["uptime"] = "";
$jieqiSetting["articlesort"] = array("玄幻魔法" => 1, "武侠修真" => 2, "都市言情" => 3, "历史军事" => 4, "穿越架空" => 5, "游戏竞技" => 6, "科幻灵异" => 7, "同人动漫" => 8, "社会文学" => 9, "综合其他" => 10, "default" => 10);
$jieqiSetting["apiserver"] = "http://book.jieqi.com";
$jieqiSetting["payserver"] = "http://book.jieqi.com/modules/pay";

?>
