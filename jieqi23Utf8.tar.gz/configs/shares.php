<?php

$jieqiShares = array();
$jieqiShares[1] = array("apiid" => 1, "apikey" => "N3Ur6C6pZlNMxTeS3T2dbBWMWx996xcV", "caption" => "本站测试", "pagerows" => 100, "sharemode" => 1);
$jieqiShares[2] = array("apiid" => 2, "apikey" => "h49s734bca43htoc62gd", "caption" => "360文学", "pagerows" => 500, "sharemode" => 4);
$jieqiShares[3] = array("apiid" => 3, "apikey" => "h49s734bca43htoc62gd", "caption" => "百度阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[4] = array("apiid" => 4, "apikey" => "h49s734bca43htoc62gd", "caption" => "掌阅书城", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[5] = array("apiid" => 5, "apikey" => "h49s734bca43htoc62gd", "caption" => "多看阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[6] = array("apiid" => 6, "apikey" => "h49s734bca43htoc62gd", "caption" => "网易云阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[7] = array("apiid" => 7, "apikey" => "h49s734bca43htoc62gd", "caption" => "凤凰读书", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[8] = array("apiid" => 8, "apikey" => "h49s734bca43htoc62gd", "caption" => "畅读书城", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[9] = array("apiid" => 9, "apikey" => "h49s734bca43htoc62gd", "caption" => "安卓读书", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[10] = array("apiid" => 10, "apikey" => "h49s734bca43htoc62gd", "caption" => "苏宁阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[11] = array("apiid" => 11, "apikey" => "h49s734bca43htoc62gd", "caption" => "开卷有益", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[12] = array("apiid" => 12, "apikey" => "h49s734bca43htoc62gd", "caption" => "乐读小说", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[13] = array("apiid" => 13, "apikey" => "h49s734bca43htoc62gd", "caption" => "爱阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[14] = array("apiid" => 14, "apikey" => "h49s734bca43htoc62gd", "caption" => "QQ阅读", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[15] = array("apiid" => 15, "apikey" => "h49s734bca43htoc62gd", "caption" => "书旗小说", "pagerows" => 100, "sharemode" => 4);
$jieqiShares[16] = array("apiid" => 16, "apikey" => "h49s734bca43htoc62gd", "caption" => "2345", "pagerows" => 100, "sharemode" => 4);

?>
