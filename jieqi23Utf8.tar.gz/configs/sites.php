<?php

$jieqiSites = array();
$jieqiSites[1002] = array("name" => "凤鸣轩", "url" => "http://www.fmx.cn");

?>
