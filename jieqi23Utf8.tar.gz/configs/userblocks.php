<?php

$jieqiBlocks[0] = array("bid" => 0, "blockname" => "用户设置", "module" => "system", "filename" => "block_userset", "classname" => "BlockSystemUserset", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "用户设置", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);
$jieqiBlocks[1] = array("bid" => 0, "blockname" => "短消息", "module" => "system", "filename" => "block_message", "classname" => "BlockSystemMessage", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "短消息", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);
$jieqiBlocks[2] = array("bid" => 0, "blockname" => "工具箱", "module" => "system", "filename" => "block_userbox", "classname" => "BlockSystemUserbox", "side" => JIEQI_SIDEBLOCK_LEFT, "title" => "工具箱", "contenttype" => JIEQI_CONTENT_TXT, "showtype" => 15, "custom" => 0, "publish" => 3);

?>
