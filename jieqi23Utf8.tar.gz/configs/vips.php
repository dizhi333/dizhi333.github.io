<?php

$jieqiVips["11"] = array("caption" => "vip0", "minegold" => "0", "maxegold" => "100", "extraegold" => "0", "extradiv" => "10");
$jieqiVips["1"] = array("caption" => "VIP1", "minegold" => "100", "maxegold" => "1000", "extraegold" => "10", "extradiv" => "9.5");
$jieqiVips["2"] = array("caption" => "vip2", "minegold" => "1000", "maxegold" => "5000", "extraegold" => "1", "extradiv" => "9");
$jieqiVips["3"] = array("caption" => "vip3", "minegold" => "5000", "maxegold" => "10000", "extraegold" => "2", "extradiv" => "8.88");
$jieqiVips["4"] = array("caption" => "vip4", "minegold" => "10000", "maxegold" => "100000", "extraegold" => "3", "extradiv" => "8.5");
$jieqiVips["5"] = array("caption" => "vip5", "minegold" => "100000", "maxegold" => "200000", "extraegold" => "4", "extradiv" => "8");
$jieqiVips["6"] = array("caption" => "vip6", "minegold" => "200000", "maxegold" => "500000", "extraegold" => "5", "extradiv" => "7.8");
$jieqiVips["7"] = array("caption" => "vip7", "minegold" => "500000", "maxegold" => "880000", "extraegold" => "6", "extradiv" => "7.5");
$jieqiVips["8"] = array("caption" => "vip8", "minegold" => "880000", "maxegold" => "1000000", "extraegold" => "10", "extradiv" => "7");
$jieqiVips["9"] = array("caption" => "vip9", "minegold" => "1000000", "maxegold" => "5000000", "extraegold" => "20", "extradiv" => "6.8");
$jieqiVips["10"] = array("caption" => "vip10", "minegold" => "5000000", "maxegold" => "9999999", "extraegold" => "30", "extradiv" => "6.5");

?>
