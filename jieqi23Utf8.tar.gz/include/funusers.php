<?php

function jieqi_system_usersvars($users, $format = "s")
{
	global $jieqiModules;
	global $jieqiConfigs;
	global $jieqiLang;
	global $jieqiOption;
	global $jieqiHonors;

	if (!isset($jieqiHonors)) {
		jieqi_getconfigs("system", "honors");
	}

	$ret = jieqi_query_rowvars($users, $format, "system");

	if (strlen($ret["name"]) == 0) {
		$ret["name"] = $ret["uname"];
	}

	$ret["setting"] = (is_object($users) ? jieqi_funtoarray("jieqi_htmlstr", unserialize($users->getVar("setting", "n"))) : jieqi_funtoarray("jieqi_htmlstr", unserialize($users["setting"])));
	$ret["group"] = $users->getGroup();
	$ret["viptype"] = $users->getViptype();
	$honorid = jieqi_gethonorid($users->getVar("score"), $jieqiHonors);
	$ret["honorid"] = $honorid;
	$ret["honor"] = $jieqiHonors[$honorid]["name"][intval($users->getVar("workid", "n"))];
	if ((0 < $ret["overtime"]) && (JIEQI_NOW_TIME < $ret["overtime"])) {
		$ret["monthly"] = 1;
	}
	else {
		$ret["monthly"] = 0;
	}

	$ret["url_avatar"] = jieqi_geturl("system", "avatar", $users->getVar("uid", "n"), "s", $users->getVar("avatar", "n"));
	return $ret;
}


?>
